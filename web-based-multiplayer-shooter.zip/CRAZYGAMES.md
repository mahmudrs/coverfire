# Publishing COVERFIRE on CrazyGames

This repository contains two builds of the same game:

| Build | Location | Includes | Use it for |
| --- | --- | --- | --- |
| Hosted build | Next.js app (this repo) | Online 1v1 + 2v2 squads (quick match + invite links), 7 arenas, power-up pickups, bot difficulty, solo practice, PostgreSQL leaderboard | Your own web deployment / iframe embed |
| Arcade build | `public/crazygames/` | Self-contained offline solo arena (power-ups included), CrazyGames SDK lifecycle + ads | Uploading to CrazyGames |

CrazyGames hosts an HTML5 build as static files, so the uploaded arcade build is the **solo arena** (the AI opponent runs entirely in the browser). Online 1v1 needs the Next.js server, so keep it on your own host and use it as the "play online" destination or embed.

## 1. Rebuild the arcade package

```bash
node scripts/build-crazygames.mjs
```

Output:

```
public/crazygames/index.html        ~12 kB
public/crazygames/game.js           ~24 kB  (minified engine + renderer + game)
public/crazygames/fonts/*.woff2     ~140 kB  (self-hosted Barlow Condensed + DM Sans)
public/crazygames/build-manifest.json
```

Total upload size is roughly 180 kB.

A ready-to-upload zip is already built at `public/coverfire-crazygames.zip` (regenerate anytime with the commands below). It contains only `index.html`, `game.js` and `fonts/` — 9 files, ~233 kB total, `index.html` at the root:

```bash
node scripts/build-crazygames.mjs
cd public/crazygames && zip -r ../coverfire-crazygames.zip index.html game.js fonts
```

No build step, no external fonts, no third-party requests at runtime apart from the CrazyGames SDK itself — the bundle is safe to upload as-is.

## 2. What is already wired for CrazyGames

- **Progress save via the CrazyGames Data module** — `SDK.data.getItem` / `SDK.data.setItem` hold the career profile (matches, wins, kills, deaths, best kills, callsign, play time). Data is mirrored to `localStorage`, and both copies are merged by keeping the highest totals, so a guest save is never lost when a CrazyGames account signs in.
- **Linked backend account** — `SDK.user.getUserToken()` is sent to `POST /api/account`. The server verifies the JWT signature with `CRAZYGAMES_SECRET` (set this in production; otherwise the token is decoded but marked unverified and rejected if malformed/expired) and upserts one `player_accounts` row per CrazyGames user (`platform = crazygames`, `platform_user_id = cg:<userId>`). Progress is stored in `player_saves` and merged with any local/CrazyGames copy. Off-platform builds fall back to an anonymous per-browser account (`platform = local`).
- **Platform mute** — `SDK.game.settings.muteAudio` is read at runtime and `SDK.game.addSettingsChangeListener` keeps it in sync. The platform mute always wins over the in-game audio toggle: the toggle becomes disabled, sound effects stop, and the button explains that CrazyGames muted audio. Ads also mute the game. Locally you can test with `?muteAudio=true`.
- **Instant Multiplayer / party lobbies** — the hosted online build checks `SDK.game.isInstantMultiplayer`. Party leaders are taken straight into a newly created joinable 1v1 room. `SDK.game.inviteParams.roomId` routes invited players into the correct room on a cold launch, while `addJoinRoomListener` handles friends joining while the game is already open. Rooms call `updateRoom({ roomId, isJoinable: true, inviteParams: { roomId } })` in the lobby and `isJoinable: false` once full, then `leftRoom()` on exit. Copy Invite uses `SDK.game.inviteLink({ roomId })` on-platform and the normal `/room/CODE` URL everywhere else. The static solo arcade bundle remains offline and should not be submitted with the multiplayer party option; use the hosted online build for Instant Multiplayer.
- **Self-hosted fonts** — no Google Fonts or other third-party requests; the site and the zip both ship the woff2 files.
- **Platform compliance baked in:** no custom fullscreen button or key (fullscreen is provided by CrazyGames — custom ones are prohibited), fixed-timestep simulation so physics are identical on 60/144/165 Hz displays, mandatory `user-select: none` CSS, iOS audio resume on touchend, storage access wrapped so sandboxed iframes never crash, zero external requests except the SDK itself, and all-relative asset paths.
- **SDK v3** (`https://sdk.crazygames.com/crazygames-sdk-v3.js`) is loaded on the arcade page and dynamically on the Next.js pages when the game is hosted on `*.crazygames.*` or embedded in an iframe.
- `SDK.game.loadingStart()` / `loadingStop()` around boot.
- `SDK.game.gameplayStart()` when a match begins and `gameplayStop()` when it ends.
- `SDK.game.happytime()` when the player wins.
- `SDK.game.requestAd("midgame")` before every rematch. Audio is muted for the duration and the promise always resolves (so a blocked or unavailable ad never hangs the game).
- `SDK.user.getUser()` prefills the callsign; `reportGameCompletedPercentage` is available for completion tracking.
- Audio is **off by default**; nothing autoplays.
- Keyboard + mouse + touch (dual virtual sticks) are all supported, and the layout is responsive down to 360 px.
- **Mobile support (portal checkbox: Yes)** — floating dual sticks with live knobs, 46 px action buttons (dash / reload / weapon swap / invite), rotate-to-landscape hint, safe-area insets, no pinch-zoom or pull-to-refresh interference, and all HUD overlays are touch-transparent so fingers always reach the arena.

All SDK calls are wrapped in `try/catch` and degrade to no-ops on a normal host, so local development works without the SDK.

## 3. Submission checklist

1. Build/zip the arcade package (step 1) and upload it in the CrazyGames developer portal.
2. **Orientation:** landscape. The arena is 5:3 and letterboxes safely.
3. **Cover images (Option B / online 1v1 set, ready to upload):** all three are pre-sized to the exact portal dimensions with the top-left label zone kept clear —
   - `public/covers/cover-landscape-1920x1080.jpg` — Landscape 16:9 (1920×1080)
   - `public/covers/cover-portrait-800x1200.jpg` — Portrait 2:3 (800×1200)
   - `public/covers/cover-square-800x800.jpg` — Square 1:1 (800×800)
   (`public/crazygames-cover.jpg` remains the 1200×630 social/OG image used by the site metadata.)
4. **Screenshots:** capture the lobby overlay, an active firefight with the health/ammo bars visible, and the victory screen.
5. **Description:** "COVERFIRE is a fast, 60fps top-down arena shooter. Slide between concrete cover and breakable crates, swap between a sidearm, SMG and shotgun, and land five eliminations to win. Play online 1v1 against a friend anywhere, or take on the training bot."
6. **Tags:** shooter, action, arena, 1v1, multiplayer, top-down, gun, quick-play.
7. **Portal progress-save option:** tick **Progress Save → CrazyGames SDK Data module** when submitting so the platform enables cloud data for logged-in players.
8. **Environment:** set `CRAZYGAMES_SECRET` (Developer Portal → your game → user token secret) on the hosted backend to enforce JWT verification for account linking.
7. **Controls:** WASD or arrow keys to move, mouse aim, click fire, Shift dash, R reload, 1–3 or mouse wheel to swap weapons. Touch: left half drag to move, right half drag to aim and fire. No restricted keys are used and no Ctrl/Cmd combos are bound. Note: the arcade upload has no custom fullscreen button or key — fullscreen is provided by the CrazyGames platform itself, as required (the F shortcut exists only in the self-hosted builds).
8. **Onboarding:** first-time players get a two-step in-game coach (move, then aim + fire) that advances on real input and is skippable; it shows once per device. The start screen states the goal (first to 5 eliminations) with one clearly labeled PLAY NOW button and no delays.
8. **Privacy:** a policy is published at `/privacy` (required when you store callsigns/leaderboard data).

## 4. Hosted / iframe options

- `/` — landing page with quick match, private invite link, and solo practice.
- `/play` — solo arena, full site chrome.
- `/embed` — chrome-free arena intended for iframe embedding.
- `/room/[CODE]` — the shareable online 1v1 link.

No `X-Frame-Options` or restrictive CSP is set, so the game can be embedded in a portal iframe.

## 5. Portal QA checklist — what to select

The portal shows a mix of manual answers and automatic detections. Fill it in like this for the solo arcade zip:

- **Initial download size <50MB** — Yes (automatic; the zip is ~210 kB).
- **Complies to Gameplay requirements** — Yes (loading + gameplay start/stop, happytime on wins, midgame ads before rematch).
- **Runs on all CrazyGames domains** — Yes (no hardcoded domains; only the official SDK CDN is loaded).
- **Browser checks** — Yes.
- **No external ads** — Yes (only CrazyGames SDK ads).
- **Does not offer external login options** — Yes (CrazyGames account only, no Google/Facebook/OAuth).
- **In-game mention of Terms & Conditions and/or Privacy Policy** — Yes (the PRIVACY button in the toolbar opens an in-game policy overlay).
- **The game supports mobile devices** — Yes (touch dual-stick controls, responsive down to 360 px, viewport meta set).
- **The game is an online multiplayer game** — only tick this if you submit the hosted online build. The static solo zip has no networking, so leave it unticked; the whole "Multiplayer requirements" section then stays out of scope.
- **Chat / disableChat** — N/A (the game has no chat, so there is nothing to moderate or mute).

If you do submit the hosted online build as a multiplayer game (Min lobby 2 / Max lobby 2):

- **Game updates multiplayer room / Room join listener / InviteLink used** — these flip from "Not detected" automatically once the crawler sees `updateRoom`, `addJoinRoomListener` and `inviteLink` in the uploaded JS. They live in the hosted build today; a static solo zip will never trigger them.
- **Game uses Invite Button correctly (deprecated)** — N/A/Yes: the game uses the current `inviteLink` API, not the deprecated invite button.
- **IsInstantMultiplayer supported for party leader** — Yes (party leaders auto-create a joinable 1v1 lobby; test with `?crazygames` plus the mocked flag).
- **Friend invitation flows work as expected** — Yes (native `inviteLink`, `inviteParams.roomId` routing on cold launch, join-room listener while in game).
- **Game retains friends in a lobby at end of round** — Yes (PLAY AGAIN resets the same room, both players stay).
- **Chat functionality / disableChat** — N/A (no chat in the game).

## 6. Local test of the SDK path

The SDK only initialises on a CrazyGames hostname, inside an iframe, or when `?crazygames` is present:

```
http://localhost:3000/crazygames/index.html?crazygames
```

Open DevTools and check `window.CrazyGames` after load. Ads resolve immediately off-platform, so the rematch flow stays playable.
