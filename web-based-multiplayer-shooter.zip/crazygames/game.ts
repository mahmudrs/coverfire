import {
  WEAPONS,
  advanceGame,
  applyPlayerInput,
  createPlayer,
  createRoomState,
  resetMatch,
  type PublicRoom,
  type RoomState,
  type WeaponKey,
} from "../src/lib/game";
import { createAudioContext } from "../src/lib/browser";
import { CosmeticFX, drawArena } from "../src/lib/render";
import { gameplayStart, gameplayStop, getDataItem, initSdk, isAdActive, platformIsMuted, ready, requestAd, setDataItem, watchPlatformMute } from "./sdk";

const STEP = 1000 / 60;
const ARENA_RATIO = 720 / 1200;
const WEAPON_ORDER: WeaponKey[] = ["pistol", "smg", "shotgun"];

function el<T extends HTMLElement>(id: string): T {
  const node = document.getElementById(id);
  if (!node) throw new Error(`Missing element #${id}`);
  return node as T;
}

const dom = {
  canvas: el<HTMLCanvasElement>("arena"),
  start: el<HTMLDivElement>("start"),
  startCard: el<HTMLDivElement>("start-card"),
  startButton: el<HTMLButtonElement>("start-button"),
  end: el<HTMLDivElement>("end"),
  endCard: el<HTMLDivElement>("end-card"),
  resultTitle: el<HTMLHeadingElement>("result-title"),
  resultCopy: el<HTMLParagraphElement>("result-copy"),
  resultScore: el<HTMLDivElement>("result-score"),
  againButton: el<HTMLButtonElement>("again-button"),
  healthValue: el<HTMLElement>("health-value"),
  healthFill: el<HTMLElement>("health-fill"),
  healthBlock: el<HTMLElement>("health-block"),
  ammoValue: el<HTMLElement>("ammo-value"),
  ammoFill: el<HTMLElement>("ammo-fill"),
  ammoTicks: el<HTMLElement>("ammo-ticks"),
  ammoBlock: el<HTMLElement>("ammo-block"),
  ammoName: el<HTMLElement>("ammo-name"),
  botHealthValue: el<HTMLElement>("bot-health-value"),
  botHealthFill: el<HTMLElement>("bot-health-fill"),
  botHealthBlock: el<HTMLElement>("bot-health-block"),
  botHealthName: el<HTMLElement>("bot-health-name"),
  careerMatches: el<HTMLElement>("career-matches"),
  careerWins: el<HTMLElement>("career-wins"),
  careerBest: el<HTMLElement>("career-best"),
  careerName: el<HTMLElement>("career-name"),
  ammoState: el<HTMLElement>("ammo-state"),
  kills: el<HTMLElement>("kills"),
  botKills: el<HTMLElement>("bot-kills"),
  pips: el<HTMLElement>("pips"),
  botPips: el<HTMLElement>("bot-pips"),
  callsign: el<HTMLInputElement>("callsign"),
  coach: el<HTMLDivElement>("coach"),
  coachStep1: el<HTMLDivElement>("coach-step-1"),
  coachStep2: el<HTMLDivElement>("coach-step-2"),
  coachSkip: el<HTMLButtonElement>("coach-skip"),
  privacyButton: el<HTMLButtonElement>("privacy-button"),
  privacy: el<HTMLDivElement>("privacy"),
  privacyClose: el<HTMLButtonElement>("privacy-close"),
  weaponButtons: Array.from(document.querySelectorAll<HTMLButtonElement>("[data-weapon]")),
};

let state: RoomState;
let clock = 0;
let seq = 0;
let started = false;
const keys = new Set<string>();
let mouseDown = false;
let aimX = 760;
let aimY = 360;
let pointerInside = false;
let weapon: WeaponKey = "pistol";
let touchMove: { id: number; sx: number; sy: number; mx: number; my: number } | null = null;
let touchAim: { id: number; sx: number; sy: number; angle: number | null } | null = null;

type Profile = { matches: number; wins: number; kills: number; bestKills: number; callsign: string; updatedAt: number };
const PROFILE_KEY = "coverfire.arcade.v1";
let profile: Profile = { matches: 0, wins: 0, kills: 0, bestKills: 0, callsign: "ROOKIE", updatedAt: 0 };
let muted = false;
let audio: AudioContext | null = null;
let lastShotSeen = 0;

const clampStats = (value: unknown) => {
  const number = Math.round(Number(value));
  return Number.isFinite(number) ? Math.max(0, Math.min(10_000_000, number)) : 0;
};

function normalizeProfile(raw: unknown, fallback = "ROOKIE"): Profile {
  const source = (raw && typeof raw === "object" ? raw : {}) as Record<string, unknown>;
  const callsign = typeof source.callsign === "string" ? source.callsign.replace(/[^a-zA-Z0-9 _-]/g, "").trim().slice(0, 16).toUpperCase() : "";
  return {
    matches: clampStats(source.matches),
    wins: clampStats(source.wins),
    kills: clampStats(source.kills),
    bestKills: clampStats(source.bestKills),
    callsign: callsign || fallback.slice(0, 16).toUpperCase(),
    updatedAt: clampStats(source.updatedAt),
  };
}

function mergeProfiles(a: Profile, b: Profile): Profile {
  const newer = a.updatedAt >= b.updatedAt ? a : b;
  return {
    matches: Math.max(a.matches, b.matches),
    wins: Math.max(a.wins, b.wins),
    kills: Math.max(a.kills, b.kills),
    bestKills: Math.max(a.bestKills, b.bestKills),
    callsign: newer.callsign,
    updatedAt: Math.max(a.updatedAt, b.updatedAt),
  };
}

function readLocalProfile(): Profile | null {
  try {
    const raw = localStorage.getItem(PROFILE_KEY);
    return raw ? normalizeProfile(JSON.parse(raw)) : null;
  } catch {
    return null;
  }
}

async function loadProfile(): Promise<Profile> {
  const local = readLocalProfile();
  let cloud: Profile | null = null;
  try {
    const raw = getDataItem(PROFILE_KEY);
    cloud = raw ? normalizeProfile(JSON.parse(raw)) : null;
  } catch {
    cloud = null;
  }
  profile = local && cloud ? mergeProfiles(local, cloud) : local ?? cloud ?? normalizeProfile(null, storedName() || "ROOKIE");
  paintCareer();
  return profile;
}

function paintCareer() {
  dom.careerMatches.textContent = String(profile.matches);
  dom.careerWins.textContent = String(profile.wins);
  dom.careerBest.textContent = String(profile.bestKills);
  dom.careerName.textContent = profile.callsign;
}

function saveProfile(next: Profile) {
  profile = next;
  try {
    localStorage.setItem(PROFILE_KEY, JSON.stringify(next));
    localStorage.setItem("coverfire:name", next.callsign);
  } catch {
    /* Storage can be blocked. */
  }
  setDataItem(PROFILE_KEY, JSON.stringify(next));
  paintCareer();
}

function playShot() {
  if (muted || isAdActive()) return;
  try {
    audio ??= createAudioContext();
    if (!audio) return;
    if (audio.state === "suspended") void audio.resume().catch(() => undefined);
    const start = audio.currentTime;
    const oscillator = audio.createOscillator();
    const gain = audio.createGain();
    oscillator.type = "square";
    oscillator.frequency.setValueAtTime(150, start);
    oscillator.frequency.exponentialRampToValueAtTime(40, start + 0.1);
    gain.gain.setValueAtTime(0.03, start);
    gain.gain.exponentialRampToValueAtTime(0.0001, start + 0.11);
    oscillator.connect(gain).connect(audio.destination);
    oscillator.start(start);
    oscillator.stop(start + 0.12);
  } catch {
    /* Audio is optional. */
  }
}

function storedName() {
  try {
    return (localStorage.getItem("coverfire:name") || "").slice(0, 16);
  } catch {
    return "";
  }
}

function currentName() {
  return (dom.callsign.value || "ROOKIE").replace(/[^a-zA-Z0-9 _-]/g, "").trim().slice(0, 16).toUpperCase() || "ROOKIE";
}

function buildMatch(name: string) {
  const now = Date.now();
  clock = now;
  seq = 0;
  const room = createRoomState("CG", now, "practice");
  const human = createPlayer("alpha", "", name, now);
  const bot = createPlayer("bravo", "", "TRAINING BOT", now);
  bot.isBot = true;
  bot.weapon = "smg";
  room.players = [human, bot];
  room.phase = "playing";
  room.startedAt = now;
  state = room;
  weapon = "pistol";
  keys.clear();
  mouseDown = false;
  touchMove = null;
  touchAim = null;
  lastShotSeen = 0;
  updateWeaponButtons();
}

function moveVector() {
  // WASD + arrow keys.
  let mx = Number(keys.has("d") || keys.has("arrowright")) - Number(keys.has("a") || keys.has("arrowleft"));
  let my = Number(keys.has("s") || keys.has("arrowdown")) - Number(keys.has("w") || keys.has("arrowup"));
  if (touchMove) { mx += touchMove.mx; my += touchMove.my; }
  const length = Math.hypot(mx, my);
  return length > 1 ? { mx: mx / length, my: my / length } : { mx, my };
}

function resize() {
  const bounds = dom.canvas.getBoundingClientRect();
  const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
  const width = Math.max(320, Math.round(bounds.width * dpr));
  const height = Math.round(width * ARENA_RATIO);
  if (dom.canvas.width !== width || dom.canvas.height !== height) {
    dom.canvas.width = width;
    dom.canvas.height = height;
  }
}

function updateWeaponButtons() {
  for (const button of dom.weaponButtons) button.classList.toggle("active", button.dataset.weapon === weapon);
}

function setWeapon(next: WeaponKey) {
  weapon = next;
  updateWeaponButtons();
}

function step() {
  if (!started || !state) return;
  clock += STEP;
  const human = state.players.find((player) => player.id === "alpha");
  if (!human) return;
  const { mx, my } = moveVector();
  const aim = touchAim ? touchAim.angle ?? human.aim : pointerInside ? Math.atan2(aimY - human.y, aimX - human.x) : human.aim;
  applyPlayerInput(state, human, {
    mx,
    my,
    aim,
    shoot: mouseDown || touchAim !== null,
    dash: keys.has("shift") || keys.has(" "),
    reload: keys.has("r"),
    weapon,
  }, clock, ++seq);
  advanceGame(state, clock);
}

let lastHealth = -1;
let lastBotHealth = -1;
let lastAmmo = -1;
let lastMag = -1;
let lastReload = -1;

function paintHud() {
  if (!state) return;
  const human = state.players.find((player) => player.id === "alpha");
  const bot = state.players.find((player) => player.id === "bravo");
  if (!human || !bot) return;
  const stats = WEAPONS[human.weapon];
  const reloading = human.reloadEndsAt > 0;
  const reloadProgress = reloading ? Math.max(0, Math.min(100, (1 - (human.reloadEndsAt - clock) / stats.reload) * 100)) : 0;
  const hp = Math.max(0, Math.round(human.hp));
  const ammo = human.ammo[human.weapon];

  if (hp !== lastHealth) {
    lastHealth = hp;
    dom.healthValue.textContent = String(hp);
    dom.healthFill.style.width = `${hp}%`;
    dom.healthBlock.classList.toggle("critical", hp < 30);
  }
  if (ammo !== lastAmmo || stats.mag !== lastMag) {
    lastAmmo = ammo;
    lastMag = stats.mag;
    dom.ammoValue.innerHTML = `${ammo}<em>/${stats.mag}</em>`;
    dom.ammoFill.style.width = `${(ammo / stats.mag) * 100}%`;
    dom.ammoTicks.style.setProperty("--segments", String(stats.mag));
    dom.ammoBlock.classList.toggle("low", ammo > 0 && ammo <= Math.ceil(stats.mag * 0.25));
    dom.ammoBlock.classList.toggle("empty", ammo === 0);
    dom.ammoName.textContent = stats.name;
    dom.ammoState.textContent = ammo === 0 ? "PRESS R TO RELOAD" : "";
  }
  if (Math.round(reloadProgress) !== lastReload) {
    lastReload = Math.round(reloadProgress);
    dom.ammoBlock.classList.toggle("reloading", reloading);
    dom.ammoState.textContent = reloading ? `RELOADING ${Math.round(reloadProgress)}%` : ammo === 0 ? "PRESS R TO RELOAD" : "";
  }
  if (human.lastShotAt !== lastShotSeen) {
    lastShotSeen = human.lastShotAt;
    playShot();
  }
  if (Math.round(bot.hp) !== lastBotHealth) {
    lastBotHealth = Math.round(bot.hp);
    dom.botHealthValue.textContent = String(lastBotHealth);
    dom.botHealthFill.style.width = `${Math.max(0, lastBotHealth)}%`;
    dom.botHealthBlock.classList.toggle("critical", lastBotHealth < 30);
  }
  dom.botHealthName.textContent = bot.name;
  dom.kills.textContent = String(human.kills);
  dom.botKills.textContent = String(bot.kills);
  dom.pips.innerHTML = Array.from({ length: 5 }, (_, index) => `<i class="${index < human.kills ? "on" : ""}"></i>`).join("");
  dom.botPips.innerHTML = Array.from({ length: 5 }, (_, index) => `<i class="${index < bot.kills ? "on" : ""}"></i>`).join("");
}

function finishMatch(humanWon: boolean) {
  started = false;
  gameplayStop(humanWon);
  const human = state.players.find((player) => player.id === "alpha");
  const bot = state.players.find((player) => player.id === "bravo");
  dom.resultTitle.innerHTML = humanWon ? "VICTORY<span> IS YOURS.</span>" : "NOT THIS<span> TIME.</span>";
  dom.resultCopy.textContent = humanWon ? "Clean shooting. The training bot never stood a chance." : "The bot got the better of you. Use the crates, then run it back.";
  dom.resultScore.innerHTML = `<span>${human?.name ?? "YOU"}<strong>${human?.kills ?? 0}</strong></span><b>—</b><span><strong>${bot?.kills ?? 0}</strong>${bot?.name ?? "BOT"}</span>`;
  saveProfile({
    ...profile,
    callsign: human?.name ?? profile.callsign,
    matches: profile.matches + 1,
    wins: profile.wins + (humanWon ? 1 : 0),
    kills: profile.kills + (human?.kills ?? 0),
    bestKills: Math.max(profile.bestKills, human?.kills ?? 0),
    updatedAt: Date.now(),
  });
  dom.end.classList.add("show");
  dom.endCard.classList.add("pop");
}

function draw() {
  if (!state) return;
  const human = state.players.find((player) => player.id === "alpha");
  if (!human) return;
  const scale = dom.canvas.width / 1200;
  const ctx = dom.canvas.getContext("2d");
  if (!ctx) return;
  ctx.setTransform(scale, 0, 0, scale, 0, 0);
  const reticle = touchAim
    ? { x: human.x + Math.cos(human.aim) * 190, y: human.y + Math.sin(human.aim) * 190 }
    : pointerInside ? { x: aimX, y: aimY } : null;
  if (human.hp === 100 && human.kills === 0 && human.deaths === 0 && human.lastShotAt === 0) {
    feel.hp = 100; feel.deaths = 0; feel.shot = 0; feel.kills = 0; trauma = 0;
  }
  if (human.hp < feel.hp) trauma = Math.min(1, trauma + 0.45);
  if (human.deaths > feel.deaths) trauma = Math.min(1, trauma + 0.7);
  if (human.lastShotAt !== feel.shot) { trauma = Math.min(1, trauma + 0.1); feel.shot = human.lastShotAt; }
  if (human.kills > feel.kills) { trauma = Math.min(1, trauma + 0.2); feel.kills = human.kills; }
  feel.hp = human.hp;
  feel.deaths = human.deaths;
  trauma = Math.max(0, trauma - 0.025);
  const snapshot = state as unknown as PublicRoom;
  fx.update(snapshot, clock);
  drawArena(ctx, snapshot, { now: clock, localId: "alpha", reticle, shake: trauma, localHp: human.hp });
  fx.draw(ctx);
}

const feel = { hp: 100, deaths: 0, shot: 0, kills: 0 };
let trauma = 0;
const fx = new CosmeticFX();

const COACH_KEY = "coverfire.coach.v1";
const COACH_MOVE_KEYS = ["w", "a", "s", "d", "arrowup", "arrowdown", "arrowleft", "arrowright"];
let coachStep = 0; // 0 = done/hidden, 1 = move, 2 = fire
let coachShotAtStart = 0;

function paintCoach() {
  dom.coachStep1.classList.toggle("hidden", coachStep !== 1);
  dom.coachStep2.classList.toggle("hidden", coachStep !== 2);
}

function coachDone() {
  coachStep = 0;
  dom.coach.classList.remove("show");
  try { localStorage.setItem(COACH_KEY, "done"); } catch { /* Storage can be blocked. */ }
}

function maybeStartCoach() {
  let done = true;
  try { done = localStorage.getItem(COACH_KEY) === "done"; } catch { done = true; }
  if (done) return;
  coachStep = 1;
  paintCoach();
  dom.coach.classList.add("show");
}

function updateCoach() {
  if (coachStep === 0 || !started) return;
  const human = state.players.find((player) => player.id === "alpha");
  if (coachStep === 1 && (touchMove !== null || COACH_MOVE_KEYS.some((key) => keys.has(key)))) {
    coachStep = 2;
    coachShotAtStart = human?.lastShotAt ?? 0;
    paintCoach();
  } else if (coachStep === 2 && (mouseDown || touchAim !== null || (human && human.lastShotAt !== coachShotAtStart))) {
    coachDone();
  }
}

let lastFrame = 0;
let accumulator = 0;

function loop(time: number) {
  // Fixed-timestep simulation so physics run identically on 60 Hz, 144 Hz and
  // 165 Hz displays (required by the CrazyGames gameplay guidelines).
  if (!lastFrame) lastFrame = time;
  accumulator += Math.min(100, Math.max(0, time - lastFrame));
  lastFrame = time;
  let steps = 0;
  while (accumulator >= STEP && steps < 4) {
    step();
    accumulator -= STEP;
    steps++;
  }
  if (accumulator > STEP * 4) accumulator = 0;
  if (started && state.phase === "finished") finishMatch(state.winner === "alpha");
  updateCoach();
  paintHud();
  draw();
  requestAnimationFrame(loop);
}

function startMatch() {
  const name = currentName();
  dom.callsign.value = name;
  try { localStorage.setItem("coverfire:name", name); } catch { /* ignore */ }
  saveProfile({ ...profile, callsign: name, updatedAt: Date.now() });
  buildMatch(name);
  dom.start.classList.remove("show");
  dom.end.classList.remove("show");
  dom.endCard.classList.remove("pop");
  started = true;
  gameplayStart();
  maybeStartCoach();
  return name;
}

async function restart() {
  await requestAd();
  startMatch();
}

function pointOf(event: PointerEvent) {
  const bounds = dom.canvas.getBoundingClientRect();
  return { x: ((event.clientX - bounds.left) / bounds.width) * 1200, y: ((event.clientY - bounds.top) / bounds.height) * 720 };
}

const stickMove = document.getElementById("stick-move");
const stickMoveKnob = stickMove?.querySelector("span") ?? null;
const stickAim = document.getElementById("stick-aim");
const stickAimKnob = stickAim?.querySelector("span") ?? null;

function placeStick(stick: HTMLElement | null, knob: HTMLElement | null, wx: number, wy: number, kx: number, ky: number) {
  const frame = dom.canvas.closest(".frame") as HTMLElement | null;
  if (!frame || !stick) return;
  const fr = frame.getBoundingClientRect();
  const cr = dom.canvas.getBoundingClientRect();
  const baseX = (wx / 1200) * cr.width + (cr.left - fr.left);
  const baseY = (wy / 720) * cr.height + (cr.top - fr.top);
  stick.classList.add("on");
  stick.style.left = `${baseX}px`;
  stick.style.top = `${baseY}px`;
  if (knob) {
    const len = Math.hypot(kx, ky);
    const reach = 34;
    const scale = len > 0 ? Math.min(len, 1) * reach : 0;
    knob.style.transform = `translate(${len > 0 ? (kx / len) * scale : 0}px, ${len > 0 ? (ky / len) * scale : 0}px)`;
  }
}

function paintSticks(current?: { x: number; y: number }) {
  if (touchMove) {
    placeStick(stickMove, stickMoveKnob, touchMove.sx, touchMove.sy, touchMove.mx, touchMove.my);
  } else {
    stickMove?.classList.remove("on");
  }
  if (touchAim && current) {
    placeStick(stickAim, stickAimKnob, touchAim.sx, touchAim.sy, (current.x - touchAim.sx) / 88, (current.y - touchAim.sy) / 88);
  } else if (!touchAim) {
    stickAim?.classList.remove("on");
  }
}

function hideSticks() {
  stickMove?.classList.remove("on");
  stickAim?.classList.remove("on");
}

dom.canvas.addEventListener("pointerdown", (event) => {
  event.preventDefault();
  dom.canvas.setPointerCapture(event.pointerId);
  const point = pointOf(event);
  if (event.pointerType === "touch") {
    if (point.x < 552 && !touchMove) touchMove = { id: event.pointerId, sx: point.x, sy: point.y, mx: 0, my: 0 };
    else if (!touchAim) touchAim = { id: event.pointerId, sx: point.x, sy: point.y, angle: null };
  } else {
    aimX = point.x; aimY = point.y; pointerInside = true;
    if (event.button === 0) mouseDown = true;
  }
  paintSticks();
});

dom.canvas.addEventListener("pointermove", (event) => {
  const point = pointOf(event);
  if (event.pointerType !== "touch") { aimX = point.x; aimY = point.y; pointerInside = true; return; }
  if (touchMove?.id === event.pointerId) {
    const dx = (point.x - touchMove.sx) / 88;
    const dy = (point.y - touchMove.sy) / 88;
    const length = Math.hypot(dx, dy);
    touchMove.mx = length > 1 ? dx / length : dx;
    touchMove.my = length > 1 ? dy / length : dy;
  }
  if (touchAim?.id === event.pointerId) {
    const dx = point.x - touchAim.sx;
    const dy = point.y - touchAim.sy;
    if (Math.hypot(dx, dy) > 14) touchAim.angle = Math.atan2(dy, dx);
  }
  if (event.pointerType === "touch") paintSticks(point);
});

function endPointer(event: PointerEvent) {
  if (touchMove?.id === event.pointerId) touchMove = null;
  if (touchAim?.id === event.pointerId) touchAim = null;
  if (event.pointerType !== "touch") mouseDown = false;
  if (event.pointerType === "touch") paintSticks();
}
dom.canvas.addEventListener("pointerup", endPointer);
dom.canvas.addEventListener("pointercancel", endPointer);
dom.canvas.addEventListener("pointerleave", () => { pointerInside = false; mouseDown = false; });
dom.canvas.addEventListener("contextmenu", (event) => event.preventDefault());

window.addEventListener("keydown", (event) => {
  if (event.target instanceof HTMLInputElement) return;
  const key = event.key.toLowerCase();
  if (!["w", "a", "s", "d", "arrowup", "arrowdown", "arrowleft", "arrowright", "shift", " ", "r", "1", "2", "3"].includes(key)) return;
  event.preventDefault();
  keys.add(key);
  if (key === "1") setWeapon("pistol");
  if (key === "2") setWeapon("smg");
  if (key === "3") setWeapon("shotgun");
});
window.addEventListener("keyup", (event) => keys.delete(event.key.toLowerCase()));
window.addEventListener("blur", () => { keys.clear(); mouseDown = false; touchMove = null; touchAim = null; hideSticks(); });

// iOS suspends AudioContext when the app is backgrounded and only allows
// resume inside a user gesture — required by the CrazyGames mobile guidelines.
function unlockAudio() {
  try {
    if (audio && audio.state === "suspended") void audio.resume().catch(() => undefined);
  } catch {
    /* Audio is optional. */
  }
}
document.addEventListener("touchend", unlockAudio);
document.addEventListener("click", unlockAudio);

for (const button of dom.weaponButtons) {
  button.addEventListener("click", () => {
    const next = button.dataset.weapon as WeaponKey | undefined;
    if (next && WEAPON_ORDER.includes(next)) setWeapon(next);
  });
}

// Mouse wheel cycles weapons (throttled so trackpads don't spin through all three).
let lastWheelSwitch = 0;
dom.canvas.addEventListener("wheel", (event) => {
  event.preventDefault();
  const nowMs = performance.now();
  if (nowMs - lastWheelSwitch < 120) return;
  lastWheelSwitch = nowMs;
  setWeapon(WEAPON_ORDER[(WEAPON_ORDER.indexOf(weapon) + (event.deltaY > 0 ? 1 : 2)) % 3]);
}, { passive: false });

dom.coachSkip.addEventListener("click", () => coachDone());
dom.privacyButton.addEventListener("click", () => dom.privacy.classList.add("show"));
dom.privacyClose.addEventListener("click", () => dom.privacy.classList.remove("show"));
dom.privacy.addEventListener("click", (event) => {
  if (event.target === dom.privacy) dom.privacy.classList.remove("show");
});
dom.startButton.addEventListener("click", () => {
  startMatch();
});
dom.againButton.addEventListener("click", () => void restart());
dom.callsign.addEventListener("keydown", (event) => {
  if (event.key === "Enter") {
    event.preventDefault();
    startMatch();
  }
});

window.addEventListener("resize", resize);
resize();
new ResizeObserver(resize).observe(dom.canvas);

const rotateTip = document.getElementById("rotate-tip");
const rotateDismiss = document.getElementById("rotate-dismiss");
try {
  if (localStorage.getItem("coverfire.rotateDismissed") === "1") rotateTip?.remove();
} catch { /* Storage can be blocked. */ }
rotateDismiss?.addEventListener("click", () => {
  try { localStorage.setItem("coverfire.rotateDismissed", "1"); } catch { /* ignore */ }
  rotateTip?.remove();
});

void (async () => {
  const account = await initSdk();
  muted = platformIsMuted();
  watchPlatformMute((next) => { muted = next; });
  await loadProfile();
  const saved = storedName();
  if (saved) dom.callsign.value = saved;
  else if (account) dom.callsign.value = account;
  else if (profile.callsign && profile.callsign !== "ROOKIE") dom.callsign.value = profile.callsign;
  paintCareer();
  ready();
  buildMatch(currentName() || "ROOKIE");
  started = false;
  dom.start.classList.add("show");
  requestAnimationFrame(loop);
})();
