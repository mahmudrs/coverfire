type CgSdk = {
  init: () => Promise<void>;
  data?: {
    getItem?: (key: string) => string | null;
    setItem?: (key: string, value: string) => void;
    removeItem?: (key: string) => void;
  };
  game: {
    settings?: { muteAudio?: boolean; disableChat?: boolean };
    addSettingsChangeListener?: (listener: (settings: { muteAudio?: boolean }) => void) => void;
    removeSettingsChangeListener?: (listener: (settings: { muteAudio?: boolean }) => void) => void;
    loadingStart?: () => void;
    loadingStop?: () => void;
    gameplayStart?: () => void;
    gameplayStop?: () => void;
    happytime?: () => void;
    requestAd?: (type: string, callbacks?: { adStarted?: () => void; adFinished?: () => void; adError?: () => void }) => void;
  };
  user?: { isUserAccountAvailable?: boolean; getUser?: () => Promise<{ username?: string } | null | undefined> };
};

type SdkWindow = Window & { CrazyGames?: { SDK?: CgSdk } };

function sdkWindow() {
  return window as unknown as SdkWindow;
}

let sdk: CgSdk | null = null;
let loaded = false;
let adRequested = false;
let adPlaying = false;
let userPromise: Promise<string | null> | null = null;

export function sdkHosted() {
  const host = window.location.hostname;
  return host.includes("crazygames") || new URLSearchParams(window.location.search).has("crazygames") || window.self !== window.top;
}

export async function initSdk(): Promise<string | null> {
  if (loaded) return userPromise;
  loaded = true;
  if (!sdkHosted()) return null;
  if (!sdkWindow().CrazyGames?.SDK) {
    await new Promise<void>((resolve) => {
      const script = document.createElement("script");
      script.src = "https://sdk.crazygames.com/crazygames-sdk-v3.js";
      script.async = true;
      script.onload = () => resolve();
      script.onerror = () => resolve();
      document.head.appendChild(script);
      window.setTimeout(resolve, 6000);
    });
  }
  const candidate = sdkWindow().CrazyGames?.SDK;
  if (!candidate) return null;
  try {
    await candidate.init();
    sdk = candidate;
    candidate.game.loadingStart?.();
  } catch {
    sdk = null;
    return null;
  }
  userPromise = readUser();
  return userPromise;
}

async function readUser(): Promise<string | null> {
  if (!sdk?.user?.isUserAccountAvailable || !sdk.user.getUser) return null;
  try {
    const user = await sdk.user.getUser();
    return user?.username ? String(user.username).slice(0, 16).toUpperCase() : null;
  } catch {
    return null;
  }
}

export function ready() {
  sdk?.game.loadingStop?.();
}

export function gameplayStart() {
  try { sdk?.game.gameplayStart?.(); } catch { /* optional */ }
}

export function gameplayStop(happy: boolean) {
  try {
    sdk?.game.gameplayStop?.();
    if (happy) sdk?.game.happytime?.();
  } catch { /* optional */ }
}

export function requestAd(): Promise<void> {
  const request = sdk?.game.requestAd;
  if (!sdk || !request || adRequested) return Promise.resolve();
  adRequested = true;
  return new Promise<void>((resolve) => {
    let done = false;
    const finish = () => {
      if (done) return;
      done = true;
      adRequested = false;
      adPlaying = false;
      resolve();
    };
    try {
      // adPlaying flips the mute flag so game audio never overlaps ad audio,
      // and only while the ad is actually on screen. adError (e.g. unfilled
      // or adblock) resolves immediately and the game simply continues.
      request("midgame", {
        adStarted: () => { adPlaying = true; },
        adFinished: finish,
        adError: finish,
      });
    } catch {
      finish();
      return;
    }
    window.setTimeout(finish, 45_000);
  });
}

/** True only while a video ad is actually on screen. */
export function isAdActive(): boolean {
  return adPlaying;
}

export function getDataItem(key: string): string | null {
  try {
    return sdk?.data?.getItem?.(key) ?? null;
  } catch {
    return null;
  }
}

export function setDataItem(key: string, value: string) {
  try {
    sdk?.data?.setItem?.(key, value);
  } catch {
    /* Cloud data is best-effort. */
  }
}

function wantsLocalMute(): boolean {
  return new URLSearchParams(window.location.search).get("muteAudio") === "true";
}

export function platformIsMuted(): boolean {
  if (wantsLocalMute()) return true;
  try {
    return Boolean(sdk?.game?.settings?.muteAudio);
  } catch {
    return wantsLocalMute();
  }
}

/** Honors the CrazyGames mute toggle for as long as the game runs. */
export function watchPlatformMute(listener: (muted: boolean) => void): () => void {
  listener(platformIsMuted());
  const handler = (settings: { muteAudio?: boolean }) => listener(Boolean(settings?.muteAudio) || wantsLocalMute());
  try {
    sdk?.game?.addSettingsChangeListener?.(handler);
  } catch {
    /* Listener is optional off-platform. */
  }
  return () => {
    try {
      sdk?.game?.removeSettingsChangeListener?.(handler);
    } catch {
      /* Best-effort. */
    }
  };
}
