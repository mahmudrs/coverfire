import { copyFile, mkdir, readFile, readdir, stat, writeFile } from "node:fs/promises";
import { build } from "esbuild";

const outDir = "public/crazygames";
const bundlePath = `${outDir}/game.js`;

await mkdir(outDir, { recursive: true });

const result = await build({
  entryPoints: ["crazygames/game.ts"],
  bundle: true,
  minify: true,
  format: "iife",
  target: ["es2019"],
  outfile: bundlePath,
  alias: { "@/lib/game": "./src/lib/game.ts", "@/lib/render": "./src/lib/render.ts" },
  legalComments: "none",
  metafile: true,
});

await copyFile("crazygames/index.html", `${outDir}/index.html`);
await mkdir(`${outDir}/fonts`, { recursive: true });
const fontSources = (await readdir("public/fonts")).filter((file) => file.endsWith(".woff2"));
for (const file of fontSources) await copyFile(`public/fonts/${file}`, `${outDir}/fonts/${file}`);

const [bundle, html] = await Promise.all([stat(bundlePath), readFile(`${outDir}/index.html`, "utf8")]);
const bundleKb = (bundle.size / 1024).toFixed(1);

// A tiny manifest is handy when uploading the folder to a game portal.
const manifest = {
  name: "COVERFIRE",
  version: `1.0.${Date.now().toString(36)}`,
  entry: "index.html",
  files: ["index.html", "game.js", ...fontSources.map((file) => `fonts/${file}`)],
  bundleKb: Number(bundleKb),
  builtAt: new Date().toISOString(),
  totalKb: 0,
};
const fontBytes = (await Promise.all(fontSources.map(async (file) => (await stat(`${outDir}/fonts/${file}`)).size))).reduce((total, size) => total + size, 0);
manifest.totalKb = Number(((bundle.size + Buffer.byteLength(html) + fontBytes) / 1024).toFixed(1));
await writeFile(`${outDir}/build-manifest.json`, `${JSON.stringify(manifest, null, 2)}\n`);

console.log(`CrazyGames build ready in ${outDir}/`);
console.log(`  index.html  ${(Buffer.byteLength(html) / 1024).toFixed(1)} kB`);
console.log(`  game.js     ${bundleKb} kB (minified, engine + renderer + game)`);
console.log(`  inputs      ${Object.keys(result.metafile.inputs).length} modules`);
