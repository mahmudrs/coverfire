import { resolveIdentity, syncAccount } from "@/lib/account-server";
import { normalizeProgress } from "@/lib/progress";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function noStore(data: unknown, status = 200) {
  return Response.json(data, { status, headers: { "Cache-Control": "no-store" } });
}

export async function POST(request: Request) {
  try {
    const body = await request.json().catch(() => ({}));
    const action = typeof body?.action === "string" ? body.action : "session";
    const identity = resolveIdentity({ token: body?.token, localId: body?.localId, username: body?.username });
    if (!identity) {
      return noStore({ error: "Could not identify this player. Sign in to CrazyGames or allow local storage.", account: null }, 401);
    }

    if (action !== "session" && action !== "save") return noStore({ error: "Unknown account action." }, 400);

    const clientProgress = body?.save && typeof body.save === "object" ? normalizeProgress(body.save, identity.username) : null;

    if (action === "save" && !clientProgress) return noStore({ error: "Missing save payload." }, 400);

    const { account, save, merged } = await syncAccount(identity, clientProgress);
    return noStore({
      account: { id: account.id, platform: account.platform, username: account.username, verified: account.verified },
      save,
      merged,
      syncedAt: Date.now(),
    });
  } catch (error) {
    console.error("Account sync failed", error);
    return noStore({ error: "Cloud save is unavailable right now.", account: null }, 500);
  }
}
