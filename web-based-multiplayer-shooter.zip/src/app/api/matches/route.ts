import { desc, sql } from "drizzle-orm";
import { db } from "@/db";
import { matchResults } from "@/db/schema";
import { cleanName } from "@/lib/game";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const MAX_KILLS = 99;

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const callsign = cleanName(body?.callsign, "ROOKIE");
    const kills = Math.max(0, Math.min(MAX_KILLS, Math.round(Number(body?.kills) || 0)));
    const deaths = Math.max(0, Math.min(999, Math.round(Number(body?.deaths) || 0)));
    const durationMs = Math.max(0, Math.min(3_600_000, Math.round(Number(body?.durationMs) || 0)));
    const won = body?.won === true;
    const [row] = await db.insert(matchResults).values({ callsign, kills, deaths, won, durationMs }).returning({ id: matchResults.id });
    return Response.json({ ok: true, id: row.id }, { status: 201, headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("Match result failed", error);
    return Response.json({ error: "Could not record that match." }, { status: 500 });
  }
}

export async function GET() {
  try {
    const leaderboard = await db
      .select({
        callsign: matchResults.callsign,
        bestKills: sql<number>`max(${matchResults.kills})::int`,
        wins: sql<number>`count(*) filter (where ${matchResults.won})::int`,
        matches: sql<number>`count(*)::int`,
      })
      .from(matchResults)
      .groupBy(matchResults.callsign)
      .orderBy(desc(sql`max(${matchResults.kills})`), desc(sql`count(*) filter (where ${matchResults.won})`), desc(sql`count(*)`))
      .limit(8);

    const recent = await db
      .select({
        callsign: matchResults.callsign,
        kills: matchResults.kills,
        deaths: matchResults.deaths,
        won: matchResults.won,
        createdAt: matchResults.createdAt,
      })
      .from(matchResults)
      .orderBy(desc(matchResults.createdAt))
      .limit(6);

    return Response.json({ leaderboard, recent }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("Leaderboard failed", error);
    return Response.json({ leaderboard: [], recent: [] }, { status: 500 });
  }
}
