import { MAPS, cleanName, type MatchMode, type PlayerInput, type WeaponKey } from "@/lib/game";
import { createOnlineRoom, joinOnlineRoom, leaveOnline, quickMatch, rematchOnline, roomStats, syncOnline } from "@/lib/room-store";

function modeOf(value: unknown): MatchMode {
  return value === "squad" ? "squad" : "duel";
}

function mapOf(value: unknown): string {
  return typeof value === "string" && MAPS.some((map) => map.id === value) ? value : "foundry";
}

function skillOf(value: unknown): 0 | 1 | 2 {
  return value === 0 || value === 2 ? value : 1;
}

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const CODE_PATTERN = /^[A-HJ-NP-Z2-9]{6}$/;
const WEAPON_KEYS: WeaponKey[] = ["pistol", "smg", "shotgun"];

function noStore(data: unknown, status = 200) {
  return Response.json(data, { status, headers: { "Cache-Control": "no-store" } });
}

function tokenOf(value: unknown) {
  return typeof value === "string" && value.length > 0 && value.length <= 80 ? value : "";
}

function codeOf(value: unknown) {
  return typeof value === "string" ? value.trim().toUpperCase() : "";
}

function inputOf(value: unknown) {
  const raw = (value && typeof value === "object" ? value : {}) as Record<string, unknown>;
  const number = (key: string) => (typeof raw[key] === "number" && Number.isFinite(raw[key]) ? (raw[key] as number) : 0);
  return {
    mx: Math.max(-1, Math.min(1, number("mx"))),
    my: Math.max(-1, Math.min(1, number("my"))),
    aim: number("aim"),
    shoot: raw.shoot === true,
    reload: raw.reload === true,
    dash: raw.dash === true,
    weapon: WEAPON_KEYS.includes(raw.weapon as WeaponKey) ? (raw.weapon as WeaponKey) : undefined,
    name: typeof raw.name === "string" ? cleanName(raw.name, "ROOKIE") : undefined,
  } satisfies Partial<PlayerInput> & { weapon?: WeaponKey; name?: string };
}

export async function POST(request: Request) {
  try {
    const body = await request.json().catch(() => ({}));
    const action = typeof body?.action === "string" ? body.action : "";
    const name = cleanName(body?.name, "ROOKIE");

    if (action === "create") {
      return noStore(await createOnlineRoom(name, modeOf(body?.mode), mapOf(body?.mapId), skillOf(body?.botSkill)), 201);
    }

    if (action === "quick") {
      return noStore(await quickMatch(name, modeOf(body?.mode), mapOf(body?.mapId), skillOf(body?.botSkill)));
    }

    if (action === "join" || action === "sync" || action === "rematch" || action === "leave") {
      const code = codeOf(body?.roomId);
      if (!CODE_PATTERN.test(code)) return noStore({ error: "Invalid match code." }, 400);
      const token = tokenOf(body?.token);

      if (action === "join") {
        const result = await joinOnlineRoom(code, token, name);
        return noStore(result, result.ok ? 200 : result.status);
      }

      if (action === "sync") {
        if (!token) return noStore({ error: "Player session missing." }, 401);
        const seq = typeof body?.seq === "number" && Number.isSafeInteger(body.seq) ? body.seq : 0;
        const result = await syncOnline(code, token, seq, inputOf(body?.input));
        return noStore(result, result.ok ? 200 : result.status);
      }

      if (action === "rematch") {
        if (!token) return noStore({ error: "Player session missing." }, 401);
        const result = await rematchOnline(code, token);
        return noStore(result, result.ok ? 200 : result.status);
      }

      return noStore(await leaveOnline(code, token));
    }

    return noStore({ error: "Unknown online action." }, 400);
  } catch (error) {
    console.error("Online action failed", error);
    return noStore({ error: "The arena hit a snag. Please try again." }, 500);
  }
}

export async function GET() {
  return noStore({ ...roomStats(), serverTime: Date.now() });
}
