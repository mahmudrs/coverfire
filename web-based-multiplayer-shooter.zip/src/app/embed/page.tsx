import type { Metadata } from "next";
import { SoloGame } from "@/components/solo-game";

export const metadata: Metadata = {
  title: "COVERFIRE — Arcade Embed",
  description: "Coverfire arcade build. Instant solo arena against the training bot.",
  robots: { index: false, follow: false },
};

export default function EmbedPage() {
  return <SoloGame embed />;
}
