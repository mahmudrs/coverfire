import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "COVERFIRE — Online 1v1 Arena Shooter",
  description: "Take cover. Open fire. A fast 60fps top-down arena shooter with online 1v1 duels, destructible cover, and three guns. Play instantly in your browser — no download.",
  applicationName: "COVERFIRE",
  keywords: ["online shooter", "1v1", "browser game", "top down shooter", "multiplayer", "arena", "cover shooter"],
  openGraph: {
    title: "COVERFIRE — Take Cover. Open Fire.",
    description: "Online 1v1 arena shooter with real cover, destructible crates, and three guns. 60fps in your browser.",
    type: "website",
    images: [{ url: "/crazygames-cover.jpg", width: 1200, height: 630, alt: "Coverfire arena shooter key art" }],
  },
  twitter: {
    card: "summary_large_image",
    title: "COVERFIRE — Online 1v1 Arena Shooter",
    description: "Fast 60fps top-down duels. Take cover, pick your gun, first to five wins.",
    images: ["/crazygames-cover.jpg"],
  },
  robots: { index: true, follow: true },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  viewportFit: "cover",
  themeColor: "#111a1b",
  colorScheme: "dark",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
