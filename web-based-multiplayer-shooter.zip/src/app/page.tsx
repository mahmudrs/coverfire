"use client";

import { useEffect, useRef, useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import { ArrowDownRight, ArrowRight, ArrowUpRight, Bot, Crosshair, Gamepad2, Link2, LoaderCircle, Maximize2, MousePointer2, Radio, Shield, ShieldCheck, Swords, Trophy, Users, Wifi, Zap } from "lucide-react";
import { ArenaPreview } from "@/components/arena-preview";
import { localStore, sessionStore } from "@/lib/browser";
import { getSdkInviteRoom, getSdkUserName, isInstantMultiplayer, subscribeSdkRoomJoin } from "@/lib/crazygames";
import { MAPS } from "@/lib/game";
import { useProgress } from "@/lib/progress-client";
import { rankOf, winRateOf } from "@/lib/progress";

type LeaderRow = { callsign: string; bestKills: number; wins: number; matches: number };
type Mode = "solo" | "online" | "squad";

export default function HomePage() {
  const router = useRouter();
  const [name, setName] = useState("PLAYER ONE");
  const [mode, setMode] = useState<Mode>("online");
  const [mapId, setMapId] = useState("foundry");
  const [skill, setSkill] = useState<0 | 1 | 2>(1);
  const [busy, setBusy] = useState<"solo" | "quick" | "create" | null>(null);
  const [error, setError] = useState("");
  const [board, setBoard] = useState<LeaderRow[] | null>(null);
  const [stats, setStats] = useState<{ live: number; waiting: number } | null>(null);
  const { progress, account, status: saveStatus } = useProgress();
  const [partyNotice, setPartyNotice] = useState("");
  const partyLaunchRef = useRef<Promise<string | null> | null>(null);

  useEffect(() => {
    let active = true;
    let unsubscribe: (() => void) | null = null;

    async function createPartyLobby(): Promise<string | null> {
      const savedName = localStore?.get("coverfire:name");
      const accountName = savedName ? null : await getSdkUserName();
      const callsign = (savedName || accountName || "PARTY LEADER").slice(0, 16).toUpperCase();
      const response = await fetch("/api/online", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "create", name: callsign }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Could not create the party lobby.");
      sessionStore?.set(`coverfire:online:${data.roomId}`, data.token);
      return data.roomId as string;
    }

    (async () => {
      // A friend accepting an invite always wins over creating a fresh party room.
      const invitedRoom = await getSdkInviteRoom();
      if (!active) return;
      if (invitedRoom) {
        setMode("online");
        setPartyNotice("JOINING PARTY LOBBY...");
        router.replace(`/room/${invitedRoom}`);
        return;
      }

      unsubscribe = await subscribeSdkRoomJoin((roomId) => {
        if (active) router.push(`/room/${roomId}`);
      });
      if (!(await isInstantMultiplayer()) || !active) return;

      setMode("online");
      // Instant launch should open one lobby, not trap the player in a create/exit loop.
      if (sessionStore?.get("coverfire:partyAutoCreated") === "1") return;
      sessionStore?.set("coverfire:partyAutoCreated", "1");
      setPartyNotice("CREATING PARTY LOBBY...");
      try {
        // Sharing the promise also makes React StrictMode's double effect safe.
        partyLaunchRef.current ??= createPartyLobby();
        const roomId = await partyLaunchRef.current;
        if (active && roomId) router.replace(`/room/${roomId}`);
      } catch (caught) {
        sessionStore?.del("coverfire:partyAutoCreated");
        if (active) {
          setPartyNotice("");
          setError(caught instanceof Error ? caught.message : "Could not create the party lobby.");
        }
      }
    })();

    return () => { active = false; unsubscribe?.(); };
  }, [router]);

  useEffect(() => {
    const saved = localStore?.get("coverfire:name");
    if (saved) setName(saved);
    else void getSdkUserName().then((account) => {
      if (!account) return;
      setName(account);
      localStore?.set("coverfire:name", account);
    });
    fetch("/api/matches", { cache: "no-store" })
      .then((response) => response.json())
      .then((data) => setBoard(Array.isArray(data.leaderboard) ? data.leaderboard : []))
      .catch(() => setBoard([]));
    let active = true;
    const loadStats = () => {
      fetch("/api/online", { cache: "no-store" })
        .then((response) => response.json())
        .then((data) => { if (active) setStats({ live: Number(data.live) || 0, waiting: Number(data.waiting) || 0 }); })
        .catch(() => undefined);
    };
    loadStats();
    const interval = window.setInterval(loadStats, 8000);
    return () => { active = false; window.clearInterval(interval); };
  }, []);

  useEffect(() => {
    if (progress.callsign && progress.callsign !== "ROOKIE") {
      setName((previous) => (previous === "PLAYER ONE" || previous === "ROOKIE" ? progress.callsign : previous));
    }
  }, [progress.callsign]);

  function callsign() {
    return name.replace(/[^a-zA-Z0-9 _-]/g, "").trim().slice(0, 16).toUpperCase() || "ROOKIE";
  }

  function deploySolo(): void {
    if (busy) return;
    setBusy("solo");
    localStore?.set("coverfire:name", callsign());
    localStore?.set("coverfire:botSkill", String(skill));
    router.push("/play");
  }

  async function deployOnline(action: "quick" | "create") {
    if (busy) return;
    setBusy(action);
    setError("");
    try {
      const onlineMode = mode === "squad" ? "squad" : "duel";
      const response = await fetch("/api/online", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action, name: callsign(), mode: onlineMode, mapId, botSkill: skill }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Could not start an online match.");
      localStore?.set("coverfire:name", callsign());
      sessionStore?.set(`coverfire:online:${data.roomId}`, data.token);
      router.push(`/room/${data.roomId}`);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Could not start an online match.");
      setBusy(null);
    }
  }

  function submit(event?: FormEvent) {
    event?.preventDefault();
    if (mode === "solo") deploySolo();
    else void deployOnline("quick");
  }

  return (
    <div className="site-shell" id="top">
      <header className="site-header page-container">
        <a className="brand" href="#top" aria-label="Coverfire home">
          <span className="brand-icon"><Crosshair size={27} strokeWidth={2.2} /></span>
          <span className="brand-type"><strong>COVER<span>FIRE</span><i>.</i></strong><small>ONLINE ARENA</small></span>
        </a>
        <nav className="site-nav" aria-label="Main navigation">
          <a href="#the-game">THE GAME</a>
          <a href="#controls">CONTROLS</a>
          <a href="#scores">SCOREBOARD</a>
        </nav>
        <a className="header-cta" href="#play"><span className="live-dot" /> PLAY ONLINE <ArrowUpRight size={15} /></a>
      </header>

      <main>
        <section className="hero page-container" id="the-game">
          <div className="hero-copy">
            <div className="eyebrow"><span className="eyebrow-line" /> ONLINE 1V1 TACTICAL SHOOTER <span className="eyebrow-index">// 001</span></div>
            <h1>TAKE <span>COVER.</span><br />OPEN <span>FIRE.</span></h1>
            <p className="hero-description">A fast, 60fps, top-down shooter. Jump into a live one-versus-one, squad up for 2v2 team fights across three arenas, or warm up against the training bot. Same guns. No downloads.</p>

            <form className="launch-panel" id="play" onSubmit={submit}>
              <div className="launch-header"><span><span className="launch-header-icon"><Gamepad2 size={17} /></span> CHOOSE YOUR MATCH</span><span className="live-stats"><span className="live-dot" />{stats ? `${stats.live} LIVE · ${stats.waiting} QUEUED` : "LIVE ARENA"}</span></div>
              <div className="mode-picker" role="group" aria-label="Choose how to play">
                <button type="button" className={`mode-choice ${mode === "online" ? "selected" : ""}`} aria-pressed={mode === "online"} onClick={() => setMode("online")}>
                  <span className="mode-choice-icon"><Users size={21} /></span>
                  <span className="mode-choice-copy"><small>ONLINE</small><strong>1V1 DUEL</strong><em>QUICK MATCH OR INVITE</em></span>
                  <span className="mode-radio" />
                </button>
                <button type="button" className={`mode-choice ${mode === "squad" ? "selected" : ""}`} aria-pressed={mode === "squad"} onClick={() => setMode("squad")}>
                  <span className="mode-choice-icon"><Users size={21} /></span>
                  <span className="mode-choice-copy"><small>ONLINE</small><strong>2V2 SQUAD</strong><em>BOTS FILL EMPTY SLOTS</em></span>
                  <span className="mode-radio" />
                </button>
                <button type="button" className={`mode-choice ${mode === "solo" ? "selected" : ""}`} aria-pressed={mode === "solo"} onClick={() => setMode("solo")}>
                  <span className="mode-choice-icon"><Bot size={21} /></span>
                  <span className="mode-choice-copy"><small>SOLO</small><strong>PRACTICE</strong><em>INSTANT VS BOT</em></span>
                  <span className="mode-radio" />
                </button>
              </div>
              {mode !== "solo" ? (
                <div className="map-picker" role="group" aria-label="Choose an arena">
                  <span className="picker-label">ARENA</span>
                  {MAPS.map((map) => (
                    <button key={map.id} type="button" className={`map-choice ${mapId === map.id ? "selected" : ""}`} aria-pressed={mapId === map.id} onClick={() => setMapId(map.id)}>{map.name}</button>
                  ))}
                </div>
              ) : null}
              {mode !== "online" ? (
                <div className="map-picker" role="group" aria-label="Bot difficulty">
                  <span className="picker-label">BOTS</span>
                  {(["RECRUIT", "SOLDIER", "VETERAN"] as const).map((label, index) => (
                    <button key={label} type="button" className={`map-choice ${skill === index ? "selected" : ""}`} aria-pressed={skill === index} onClick={() => setSkill(index as 0 | 1 | 2)}>{label}</button>
                  ))}
                </div>
              ) : null}
              <label htmlFor="callsign" className="field-label">YOUR CALLSIGN</label>
              <div className="launch-fields">
                <div className="input-wrap"><span className="input-prefix">&gt;_</span><input id="callsign" value={name} maxLength={16} onChange={(event) => setName(event.target.value.toUpperCase())} aria-label="Your callsign" placeholder="YOUR NAME" autoComplete="off" spellCheck={false} /></div>
                <button className="primary-button" type="submit" disabled={busy !== null}>{busy === "quick" ? "FINDING RIVAL..." : busy === "solo" ? "LOADING..." : mode === "squad" ? "FIND SQUAD" : "QUICK MATCH"}{busy ? <LoaderCircle size={19} className="loading-spinner" /> : <ArrowUpRight size={20} strokeWidth={2.5} />}</button>
              </div>
              {mode !== "solo" ? <button className="secondary-launch" type="button" onClick={() => void deployOnline("create")} disabled={busy !== null}>{busy === "create" ? <LoaderCircle size={15} className="loading-spinner" /> : <Link2 size={15} />} {mode === "squad" ? "CREATE A SQUAD + INVITE LINK" : "CREATE A PRIVATE MATCH + INVITE LINK"}</button> : null}
              {partyNotice ? <p className="party-notice" role="status"><LoaderCircle size={14} className="loading-spinner" />{partyNotice}</p> : null}
              {error ? <p className="form-error" role="alert">{error}</p> : null}
              <div className="launch-foot">{mode === "solo" ? <><span><Zap size={13} /> STARTS INSTANTLY</span><span><Gamepad2 size={13} /> 60 FPS LOCAL SIMULATION</span></> : mode === "squad" ? <><span><Users size={13} /> 2V2 TEAM FIGHT</span><span><Link2 size={13} /> SHARE A LINK TO PLAY</span></> : <><span><Wifi size={13} /> REAL OPPONENTS</span><span><Link2 size={13} /> SHARE A LINK TO PLAY</span></>}</div>
            </form>
            <div className="career-strip">
              <div className="career-head">
                <span><Trophy size={13} /> CAREER PROFILE · {progress.callsign}</span>
                <span className={`career-badge ${saveStatus}`}>{account ? `${account.platform.toUpperCase()} LINKED` : saveStatus === "synced" ? "CLOUD SAVED" : saveStatus === "loading" ? "SYNCING" : "LOCAL SAVE"}</span>
              </div>
              <div className="career-grid">
                <div><strong>{progress.matches}</strong><span>MATCHES</span></div>
                <div><strong>{progress.wins}</strong><span>WINS</span></div>
                <div><strong>{progress.bestKills}</strong><span>BEST KILLS</span></div>
                <div><strong>{winRateOf(progress)}%</strong><span>WIN RATE</span></div>
                <div><strong>{rankOf(progress).label}</strong><span>RANK</span></div>
              </div>
              <p className="career-note">Progress saves to the CrazyGames Data module and your linked game account, so it follows you across devices.</p>
            </div>
            <div className="hero-trust"><div className="trust-avatars"><span>01</span><span>02</span></div><p><strong>QUICK MATCH OR PRIVATE LINK.</strong><br />No downloads. No sign-ups. Just play.</p></div>
          </div>

          <div className="hero-visual">
            <div className="visual-heading"><span><span className="pulse-dot" /> LIVE ARENA PREVIEW</span><span>MAP 01 — THE FOUNDRY</span></div>
            <div className="preview-shell">
              <div className="preview-top-hud"><div className="preview-hud-player alpha"><span className="preview-hud-avatar">01</span><span>YOU<small>BLUE TEAM</small></span></div><div className="preview-hud-score"><strong>03</strong><span>FIRST TO 5<br />KILLS</span><strong>02</strong></div><div className="preview-hud-player bravo"><span>RIVAL<small>RED TEAM</small></span><span className="preview-hud-avatar">02</span></div></div>
              <ArenaPreview />
              <div className="preview-bottom-hud"><span><span className="preview-health-icon">+</span> 100 HP</span><span className="preview-weapon"><Crosshair size={12} /> VECT-9 <b>24 / 30</b></span></div>
              <span className="preview-frame-corner corner-tl" /><span className="preview-frame-corner corner-tr" /><span className="preview-frame-corner corner-bl" /><span className="preview-frame-corner corner-br" />
            </div>
            <div className="visual-footer"><span><Radio size={15} /> REAL-TIME ONLINE 1V1</span><span>MOVE / AIM / SURVIVE <ArrowDownRight size={16} /></span></div>
          </div>
        </section>

        <div className="marquee-band"><div className="page-container marquee-inner"><span><span className="marquee-star">✳</span> ONLINE 1V1</span><span><span className="marquee-star">✳</span> QUICK MATCH</span><span><span className="marquee-star">✳</span> REAL COVER</span><span><span className="marquee-star">✳</span> THREE GUNS</span><span><span className="marquee-star">✳</span> FIRST TO FIVE</span></div></div>

        <section className="briefing-section page-container" id="how-it-works">
          <div className="section-heading"><div><div className="section-kicker">// 02 — THE BRIEFING</div><h2>THE RULES ARE<br /><span>VERY SIMPLE.</span></h2></div><p>One arena, two players, plenty of cover. Queue up against a rival or send a private link. The server keeps the fight honest.</p></div>
          <div className="feature-grid">
            <article className="feature-card"><div className="feature-top"><span>01 / CONNECT</span><Users size={24} /></div><div className="feature-icon"><Wifi size={29} strokeWidth={1.8} /></div><h3>FIND A RIVAL.</h3><p>Hit quick match to be paired with the next player in the queue, or create a private room and share one link.</p><span className="feature-bottom">OPEN A SECOND TAB TO TEST <ArrowUpRight size={15} /></span></article>
            <article className="feature-card"><div className="feature-top"><span>02 / SURVIVE</span><Shield size={24} /></div><div className="feature-icon"><ShieldCheck size={29} strokeWidth={1.8} /></div><h3>USE YOUR COVER.</h3><p>Concrete blocks stop bullets. Wooden crates take damage and break. Move, dash, and peek before you fire.</p><span className="feature-bottom">STAY OUT OF THE OPEN <ArrowUpRight size={15} /></span></article>
            <article className="feature-card"><div className="feature-top"><span>03 / DOMINATE</span><Crosshair size={24} /></div><div className="feature-icon"><Swords size={29} strokeWidth={1.8} /></div><h3>WIN THE DUEL.</h3><p>Switch between a sidearm, a rapid-fire SMG, and a shotgun. First player to five eliminations takes the match.</p><span className="feature-bottom">FIRST TO 5 WINS <ArrowUpRight size={15} /></span></article>
          </div>
        </section>

        <section className="controls-section" id="controls"><div className="page-container controls-layout"><div className="controls-copy"><div className="section-kicker">// 03 — FIELD MANUAL</div><h2>KNOW YOUR<br /><span>CONTROLS.</span></h2><p>Simple to learn. Hard to master. Movement is predicted locally, so WASD and firing stay instant even online.</p><a href="#play" className="text-link">READY TO DROP IN? <ArrowRight size={18} /></a></div><div className="controls-grid"><div className="control-row"><span className="control-icon"><Gamepad2 size={21} /></span><span>MOVE AROUND</span><div className="key-group"><kbd>W</kbd><kbd>A</kbd><kbd>S</kbd><kbd>D</kbd></div></div><div className="control-row"><span className="control-icon"><MousePointer2 size={21} /></span><span>AIM & FIRE</span><div className="key-group"><kbd>MOUSE</kbd><kbd>CLICK</kbd></div></div><div className="control-row"><span className="control-icon"><Zap size={21} /></span><span>DASH TO SAFETY</span><div className="key-group"><kbd>SHIFT</kbd></div></div><div className="control-row"><span className="control-icon"><Crosshair size={21} /></span><span>RELOAD / SWITCH</span><div className="key-group"><kbd>R</kbd><kbd>1</kbd><kbd>2</kbd><kbd>3</kbd><kbd>WHEEL</kbd></div></div><div className="control-row"><span className="control-icon"><Maximize2 size={21} /></span><span>FULLSCREEN</span><div className="key-group"><kbd>F</kbd></div></div></div></div></section>

        <section className="briefing-section page-container scoreboard-section" id="scores">
          <div className="section-heading"><div><div className="section-kicker">// 04 — RECORDS</div><h2>CLIMB THE<br /><span>SCOREBOARD.</span></h2></div><p>Solo and online matches both feed the board. Your best kill count and total victories live here.</p></div>
          <div className="leaderboard">
            <div className="leaderboard-head"><span className="lb-rank">#</span><span>CALLSIGN</span><span>BEST KILLS</span><span>WINS</span><span>MATCHES</span></div>
            {board === null ? <div className="leaderboard-empty"><span className="loading-spinner" /> LOADING RECORDS...</div> : board.length === 0 ? <div className="leaderboard-empty"><Trophy size={22} /><span>No records yet. Your first duel claims rank 01.</span><a href="#play" className="text-link">BE THE FIRST <ArrowRight size={16} /></a></div> : board.map((row, index) => <div className={`leaderboard-row ${index === 0 ? "top" : ""}`} key={row.callsign}><span className="lb-rank">{String(index + 1).padStart(2, "0")}</span><span className="lb-name">{index === 0 ? <Trophy size={15} /> : null}{row.callsign}</span><span className="lb-kills">{row.bestKills}</span><span>{row.wins}</span><span>{row.matches}</span></div>)}
          </div>
        </section>
      </main>

      <footer className="site-footer page-container"><a className="footer-brand" href="#top"><Crosshair size={19} /> COVER<span>FIRE.</span></a><span>REAL-TIME 1V1 · 60 FPS ARENA.</span><span><a href="/privacy" className="footer-legal">PRIVACY</a> © 2026 COVERFIRE <ArrowUpRight size={14} /></span></footer>
    </div>
  );
}
