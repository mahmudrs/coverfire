import type { Metadata } from "next";
import { SoloGame } from "@/components/solo-game";

export const metadata: Metadata = {
  title: "Solo Practice | COVERFIRE",
  description: "Drop straight into the Coverfire arena against a training bot. 60fps, instant WASD movement, cover and three guns.",
};

export default function PlayPage() {
  return <SoloGame />;
}
