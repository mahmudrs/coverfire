import type { Metadata } from "next";
import Link from "next/link";
import { ArrowLeft, Crosshair } from "lucide-react";

export const metadata: Metadata = {
  title: "Privacy Policy | COVERFIRE",
  description: "How Coverfire handles player data, leaderboards, and third-party game platform services.",
};

export default function PrivacyPage() {
  return (
    <div className="site-shell legal-shell">
      <header className="site-header page-container">
        <Link className="brand" href="/" aria-label="Coverfire home">
          <span className="brand-icon"><Crosshair size={27} strokeWidth={2.2} /></span>
          <span className="brand-type"><strong>COVER<span>FIRE</span><i>.</i></strong><small>ONLINE ARENA</small></span>
        </Link>
        <Link className="header-cta" href="/"><ArrowLeft size={15} /> BACK TO ARENA</Link>
      </header>
      <main className="page-container legal-page">
        <div className="section-kicker">// LEGAL</div>
        <h1>PRIVACY<br /><span>POLICY.</span></h1>
        <p className="legal-updated">Last updated: 2026</p>

        <h2>What we collect</h2>
        <p>Coverfire is playable without an account. We store the callsign you type, together with match statistics (kills, deaths, wins, match duration) so the public scoreboard can display results. Online match rooms store the callsign, in-match position, and a randomly generated session token that lives only in your browser tab.</p>

        <h2>What we do not collect</h2>
        <p>We do not request your name, email address, password, payment details, precise location, or contacts. We do not sell or rent player data.</p>

        <h2>Game accounts and progress</h2>
        <p>Your career profile (callsign, matches, wins, kills, best kill count, selected weapon, play time) is saved in three places: the CrazyGames Data module when the game runs on CrazyGames, the browser&apos;s local storage, and a game account on this backend. When CrazyGames provides a user token, we verify or decode it and create one backend account per CrazyGames user, so the same profile follows that user across devices. Without a CrazyGames account, an anonymous per-browser account identifier is used instead. No email address or password is ever collected.</p>
        <p>The backend stores only that account identifier, the display name, timestamps, and the progress payload. Progress is combined by keeping the highest totals, so signing in on another device never erases earned stats.</p>

        <h2>Local storage</h2>
        <p>Your callsign and a mirror of your progress are saved in your browser&apos;s local storage so they persist between visits. Online match tokens and input counters are stored in session storage and are removed when the tab closes. Clearing site data removes all of it.</p>

        <h2>Game platform services</h2>
        <p>When Coverfire is played on a game platform such as CrazyGames, that platform may load its own SDK to provide accounts, advertising, and analytics. Those services are governed by the platform&apos;s privacy policy. We only use the SDK to show optional mid-game advertisements between matches and, if available, to suggest a display name.</p>

        <h2>Data retention</h2>
        <p>Scoreboard entries are kept until they are removed during maintenance. Online match rooms are deleted automatically after they are inactive. Request removal of a callsign entry by contacting the site operator with the callsign in question.</p>

        <h2>Children</h2>
        <p>The game is a stylised, non-graphic arena shooter and is not directed at children under 13. Do not submit personal information through the callsign field.</p>

        <h2>Contact</h2>
        <p>Questions about this policy can be sent to the operator of the site hosting the game.</p>

        <Link className="primary-button legal-back" href="/">BACK TO THE ARENA</Link>
      </main>
    </div>
  );
}
