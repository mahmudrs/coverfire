import type { Metadata } from "next";
import { OnlineGame } from "@/components/online-game";

type Props = { params: Promise<{ id: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { id } = await params;
  return {
    title: `Online 1v1 · ${id.toUpperCase()} | COVERFIRE`,
    description: "Join a live one-versus-one Coverfire match. Open the link, take cover, and play instantly in your browser.",
  };
}

export default async function RoomPage({ params }: Props) {
  const { id } = await params;
  return <OnlineGame roomCode={id.toUpperCase()} />;
}
