"use client";

import { useEffect, useRef } from "react";
import { createPlayer, createRoomState, toPublicRoom } from "@/lib/game";
import { drawArena } from "@/lib/render";

export function ArenaPreview() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext("2d");
    if (!canvas || !ctx) return;
    const room = createRoomState("PREVIEW");
    room.phase = "playing";
    room.players = [createPlayer("alpha", "demo-a", "YOU"), createPlayer("bravo", "demo-b", "RIVAL")];
    room.players[0].x = 280;
    room.players[0].y = 341;
    room.players[0].aim = -.32;
    room.players[0].weapon = "smg";
    room.players[1].x = 925;
    room.players[1].y = 364;
    room.players[1].aim = Math.PI - .2;
    room.players[1].weapon = "shotgun";
    room.players[1].hp = 67;
    let animation = 0;
    const render = () => {
      const now = Date.now();
      const t = now / 1000;
      room.players[0].y = 338 + Math.sin(t * 1.2) * 7;
      room.players[1].y = 361 + Math.sin(t * 1.45) * 7;
      const travel = (t * 300) % 450;
      const counter = (t * 210) % 430;
      room.projectiles = [
        { id: 1, owner: "alpha", x: 315 + travel, y: 313 - travel * .2, vx: 1000, vy: -180, damage: 11, expiresAt: now + 200 },
        { id: 2, owner: "alpha", x: 340 + ((travel + 130) % 450), y: 302 - ((travel + 130) % 450) * .14, vx: 1000, vy: -140, damage: 11, expiresAt: now + 200 },
        { id: 3, owner: "bravo", x: 886 - counter, y: 351 + counter * .18, vx: -900, vy: 160, damage: 12, expiresAt: now + 200 },
      ];
      room.effects = [
        { id: 5, type: "spark", x: 531, y: 278, at: now - ((now % 600) / 600) * 350 },
        { id: 6, type: "muzzle", x: 308, y: room.players[0].y - 9, at: now - (now % 290) },
      ];
      ctx.setTransform(2, 0, 0, 2, 0, 0);
      drawArena(ctx, toPublicRoom(room), { now });
      animation = requestAnimationFrame(render);
    };
    animation = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animation);
  }, []);

  return <canvas ref={canvasRef} width={2400} height={1440} className="arena-preview-canvas" aria-label="Animated preview of the top-down solo arena" role="img" />;
}
