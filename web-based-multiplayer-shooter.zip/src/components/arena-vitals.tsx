"use client";

import type { CSSProperties } from "react";
import { Crosshair, Heart } from "lucide-react";

type Props = {
  hp: number;
  ammo: number;
  mag: number;
  weaponName: string;
  reloadProgress: number;
  selfName: string;
  opponentName: string;
  opponentHp: number;
};

export function ArenaVitals({ hp, ammo, mag, weaponName, reloadProgress, selfName, opponentName, opponentHp }: Props) {
  const health = Math.max(0, Math.min(100, hp));
  const rivalHealth = Math.max(0, Math.min(100, opponentHp));
  const rounds = Math.max(0, Math.min(mag, ammo));
  const lowAmmo = rounds > 0 && rounds <= Math.max(1, Math.ceil(mag * 0.25));
  const empty = rounds === 0;
  const reloading = reloadProgress > 0;

  return (
    <div className="arena-vitals" aria-hidden="true">
      <div className={`vital-block vitals-health self ${health < 30 ? "critical" : ""}`}>
        <div className="vital-head">
          <Heart size={12} />
          <span>{selfName || "YOU"}</span>
          <strong>{Math.round(health)}</strong>
        </div>
        <div className="vital-bar health-vital" style={{ "--segments": "10" } as CSSProperties}>
          <span className="vital-fill" style={{ width: `${health}%` }} />
          <i className="vital-ticks" />
        </div>
      </div>

      <div className={`vital-block vitals-ammo ${empty ? "empty" : lowAmmo ? "low" : ""} ${reloading ? "reloading" : ""}`}>
        <div className="vital-head">
          <Crosshair size={12} />
          <span>{weaponName}</span>
          <strong>{rounds}<em>/{mag}</em></strong>
        </div>
        <div className="vital-bar ammo-vital" style={{ "--segments": String(mag) } as CSSProperties}>
          <span className="vital-fill" style={{ width: `${(rounds / mag) * 100}%` }} />
          <i className="vital-ticks" />
          {reloading ? <b className="vital-reload" style={{ width: `${reloadProgress}%` }} /> : null}
        </div>
        {reloading ? <span className="vital-state">RELOADING</span> : empty ? <span className="vital-state">PRESS R TO RELOAD</span> : null}
      </div>

      <div className={`vital-block vitals-health rival ${rivalHealth < 30 ? "critical" : ""}`}>
        <div className="vital-head">
          <Heart size={12} />
          <span>{opponentName || "RIVAL"}</span>
          <strong>{Math.round(rivalHealth)}</strong>
        </div>
        <div className="vital-bar health-vital" style={{ "--segments": "10" } as CSSProperties}>
          <span className="vital-fill" style={{ width: `${rivalHealth}%` }} />
          <i className="vital-ticks" />
        </div>
      </div>
    </div>
  );
}
