"use client";

import { useCallback, useEffect, useRef, useState, type CSSProperties, type PointerEvent as ReactPointerEvent } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowLeft, ArrowRight, Check, Cloud, CloudOff, Copy, Crosshair, Gamepad2, Heart, Link2, LoaderCircle, Maximize2, Minimize2, Play, RotateCcw, Shield, ShieldCheck, Target, Trophy, Users, Volume2, VolumeX, WifiOff, Zap } from "lucide-react";
import { ARENA_HEIGHT, ARENA_WIDTH, TEAM_WIN_SCORE, WEAPONS, WIN_SCORE, getMap, isPlayerInCover, mapCover, moveWithCollisions, teamScores, type PlayerSide, type PublicRoom, type WeaponKey } from "@/lib/game";
import { CosmeticFX, drawArena } from "@/lib/render";
import { ArenaVitals } from "@/components/arena-vitals";
import { useTouchSticks } from "@/components/touch-sticks";
import { getSdkInviteLink, leaveSdkRoom, requestMidgameAd, subscribeSdkRoomJoin, updateSdkRoom, useGameSdk, useSdkMute } from "@/lib/crazygames";
import { createAudioContext, localStore, randomId, sessionStore } from "@/lib/browser";
import { isFullscreenActive, toggleFullscreen } from "@/lib/fullscreen";
import { useProgress } from "@/lib/progress-client";

type Connection = "online" | "reconnecting";

type TouchMove = { id: number; startX: number; startY: number; mx: number; my: number };
type TouchAim = { id: number; startX: number; startY: number; angle: number | null };

type Controls = {
  keys: Set<string>;
  aimX: number;
  aimY: number;
  pointerInside: boolean;
  mouseDown: boolean;
  touchMove: TouchMove | null;
  touchAim: TouchAim | null;
  weapon: WeaponKey;
};

type OnlineHud = {
  phase: "waiting" | "playing" | "finished";
  hp: number;
  kills: number;
  deaths: number;
  opponentKills: number;
  opponentHp: number;
  selfName: string;
  opponentName: string;
  alphaName: string;
  bravoName: string;
  alphaKills: number;
  bravoKills: number;
  ammo: number;
  weapon: WeaponKey;
  reloadProgress: number;
  dashIn: number;
  inCover: boolean;
  winner: PlayerSide | null;
  winnerTeam: 0 | 1 | null;
  selfTeam: 0 | 1;
  isSquad: boolean;
  target: number;
  mapName: string;
  teamKills: [number, number];
  roster: { id: PlayerSide; name: string; hp: number; team: 0 | 1; self: boolean; bot: boolean }[];
  elapsed: number;
  connection: Connection;
  opponentOnline: boolean;
  fps: number;
};

const KEY_CODES = new Set(["w", "a", "s", "d", "arrowup", "arrowdown", "arrowleft", "arrowright", "shift", " ", "r", "1", "2", "3"]);

function freshControls(): Controls {
  return { keys: new Set(), aimX: 760, aimY: 360, pointerInside: false, mouseDown: false, touchMove: null, touchAim: null, weapon: "pistol" };
}

function moveVector(controls: Controls) {
  // WASD + arrow keys.
  let mx = Number(controls.keys.has("d") || controls.keys.has("arrowright")) - Number(controls.keys.has("a") || controls.keys.has("arrowleft"));
  let my = Number(controls.keys.has("s") || controls.keys.has("arrowdown")) - Number(controls.keys.has("w") || controls.keys.has("arrowup"));
  if (controls.touchMove) { mx += controls.touchMove.mx; my += controls.touchMove.my; }
  const length = Math.hypot(mx, my);
  return length > 1 ? { mx: mx / length, my: my / length } : { mx, my };
}

function shooterName() {
  if (typeof window === "undefined") return "ROOKIE";
  return (localStore?.get("coverfire:name") || "ROOKIE").replace(/[^a-zA-Z0-9 _-]/g, "").trim().slice(0, 16).toUpperCase() || "ROOKIE";
}

function initialHud(): OnlineHud {
  return {
    phase: "waiting", hp: 100, kills: 0, deaths: 0, opponentKills: 0, opponentHp: 100, selfName: "YOU", opponentName: "WAITING...",
    alphaName: "YOU", bravoName: "WAITING...", alphaKills: 0, bravoKills: 0,
    ammo: WEAPONS.pistol.mag, weapon: "pistol", reloadProgress: 0, dashIn: 0, inCover: false, winner: null,
    winnerTeam: null, selfTeam: 0, isSquad: false, target: 5, mapName: "THE FOUNDRY", teamKills: [0, 0], roster: [], elapsed: 0,
    connection: "online", opponentOnline: false, fps: 60,
  };
}

function deriveHud(state: PublicRoom, playerId: PlayerSide, connection: Connection, fps: number): OnlineHud {
  const self = state.players.find((player) => player.id === playerId);
  const opponent = state.players.find((player) => player.id !== playerId);
  const alpha = state.players.find((player) => player.id === "alpha");
  const bravo = state.players.find((player) => player.id === "bravo");
  const now = Date.now();
  const weapon = WEAPONS[self?.weapon ?? "pistol"];
  const reloadProgress = self?.reloadEndsAt ? Math.max(0, Math.min(100, (1 - (self.reloadEndsAt - now) / weapon.reload) * 100)) : 0;
  const isSquad = state.mode === "squad";
  const scores = teamScores(state);
  const winnerTeam = state.winner ? state.players.find((player) => player.id === state.winner)?.team ?? null : null;
  return {
    phase: state.phase,
    hp: self?.hp ?? 100,
    kills: self?.kills ?? 0,
    deaths: self?.deaths ?? 0,
    opponentKills: opponent?.kills ?? 0,
    opponentHp: opponent?.hp ?? 100,
    selfName: self?.name ?? "YOU",
    opponentName: opponent?.name ?? "WAITING...",
    alphaName: alpha?.name ?? "PLAYER 01",
    bravoName: bravo?.name ?? "WAITING...",
    alphaKills: alpha?.kills ?? 0,
    bravoKills: bravo?.kills ?? 0,
    ammo: self?.ammo[self?.weapon ?? "pistol"] ?? weapon.mag,
    weapon: self?.weapon ?? "pistol",
    reloadProgress,
    dashIn: Math.max(0, ((self?.dashReadyAt ?? 0) - now) / 1000),
    inCover: self ? state.players.some((player) => player.id !== playerId && isPlayerInCover(self, player, state)) : false,
    winner: state.winner,
    winnerTeam,
    selfTeam: self?.team ?? 0,
    isSquad,
    target: isSquad ? TEAM_WIN_SCORE : WIN_SCORE,
    mapName: getMap(state.mapId).name,
    teamKills: scores,
    roster: state.players.map((player) => ({ id: player.id, name: player.name, hp: player.hp, team: player.team, self: player.id === playerId, bot: player.isBot })),
    elapsed: Math.max(0, (now - state.startedAt) / 1000),
    connection,
    opponentOnline: opponent ? now - opponent.lastSeen < 6000 : false,
    fps,
  };
}

export function OnlineGame({ roomCode }: { roomCode: string }) {
  const router = useRouter();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const stateRef = useRef<PublicRoom | null>(null);
  const controlsRef = useRef<Controls>(freshControls());
  const snapshotAtRef = useRef(Date.now());
  const sequenceRef = useRef(0);
  const flushRef = useRef<() => void>(() => {});
  const framesRef = useRef(60);
  const soundRef = useRef(false);
  const audioRef = useRef<AudioContext | null>(null);
  const [session, setSession] = useState<{ token: string; playerId: PlayerSide } | null>(null);
  const [hud, setHud] = useState<OnlineHud>(initialHud);
  const [error, setError] = useState("");
  const [copied, setCopied] = useState(false);
  const [rematching, setRematching] = useState(false);
  const [inviteUrl, setInviteUrl] = useState("");
  const [partyReady, setPartyReady] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const sticks = useTouchSticks();
  const [showRotate, setShowRotate] = useState(
    () => typeof window === "undefined" || localStore?.get("coverfire:rotateDismissed") !== "1",
  );
  const platformMute = useSdkMute();
  const progressState = useProgress();
  const platformMuteRef = useRef(false);
  const recordedRef = useRef(false);
  const matchStartRef = useRef(Date.now());
  const phaseTraceRef = useRef(hud.phase);
  const recordRef = useRef(progressState.record);
  platformMuteRef.current = platformMute.muted;
  recordRef.current = progressState.record;
  useGameSdk(hud.phase, Boolean(session && hud.winner === session.playerId));

  useEffect(() => {
    const previous = phaseTraceRef.current;
    if (hud.phase === "playing" && previous !== "playing") {
      matchStartRef.current = Date.now();
      recordedRef.current = false;
      if (hud.selfName) progressState.rename(hud.selfName);
    }
    if (hud.phase === "finished" && !recordedRef.current && session) {
      recordedRef.current = true;
      void recordRef.current({
        callsign: hud.selfName,
        kills: hud.kills,
        deaths: hud.deaths,
        won: hud.winner === session.playerId,
        durationMs: Date.now() - matchStartRef.current,
        weapon: hud.weapon,
      });
    }
    phaseTraceRef.current = hud.phase;
  }, [hud.phase, hud.selfName, hud.kills, hud.deaths, hud.winner, hud.weapon, session, progressState]);

  const playSound = useCallback((kind: "shot" | "hit" | "kill") => {
    if (!soundRef.current || platformMuteRef.current) return;
    try {
      const audio = audioRef.current ?? createAudioContext();
      if (!audio) return;
      audioRef.current = audio;
      if (audio.state === "suspended") void audio.resume().catch(() => undefined);
      const start = audio.currentTime;
      const oscillator = audio.createOscillator();
      const gain = audio.createGain();
      oscillator.type = kind === "kill" ? "triangle" : "square";
      oscillator.frequency.setValueAtTime(kind === "shot" ? 150 : kind === "hit" ? 95 : 520, start);
      oscillator.frequency.exponentialRampToValueAtTime(kind === "kill" ? 160 : 40, start + .12);
      gain.gain.setValueAtTime(kind === "shot" ? .035 : .06, start);
      gain.gain.exponentialRampToValueAtTime(.0001, start + .13);
      oscillator.connect(gain).connect(audio.destination);
      oscillator.start(start);
      oscillator.stop(start + .14);
    } catch { /* Audio is optional. */ }
  }, []);

  useEffect(() => {
    setInviteUrl(`${window.location.origin}/room/${roomCode}`);
    let active = true;
    (async () => {
      try {
        const key = `coverfire:online:${roomCode}`;
        let savedToken = sessionStore?.get(key) || "";
        if (!savedToken) {
          savedToken = randomId();
          sessionStore?.set(key, savedToken);
        }
        const response = await fetch("/api/online", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ action: "join", roomId: roomCode, token: savedToken, name: shooterName() }),
        });
        const data = await response.json();
        if (!active) return;
        if (!response.ok) { setError(data.error || "Could not join this match."); return; }
        const next = data.state as PublicRoom;
        sessionStore?.set(key, data.token);
        const self = next.players.find((player) => player.id === data.playerId);
        const savedSeq = Number(sessionStore?.get(`coverfire:onlineSeq:${roomCode}`)) || 0;
        sequenceRef.current = Math.max(savedSeq, self?.lastInputSeq ?? 0);
        controlsRef.current.weapon = self?.weapon ?? "pistol";
        stateRef.current = next;
        snapshotAtRef.current = Date.now();
        setSession({ token: data.token, playerId: data.playerId });
        setHud(deriveHud(next, data.playerId, "online", 60));
      } catch {
        if (active) setError("Could not reach the arena. Check your connection and retry.");
      }
    })();
    return () => { active = false; void leaveSdkRoom(); };
  }, [roomCode]);

  // CrazyGames friends can join this player even while another room is open.
  useEffect(() => {
    let active = true;
    let unsubscribe: (() => void) | null = null;
    void subscribeSdkRoomJoin((nextRoom) => {
      if (!active || nextRoom === roomCode) return;
      void leaveSdkRoom();
      router.push(`/room/${nextRoom}`);
    }).then((cleanup) => { unsubscribe = cleanup; });
    return () => { active = false; unsubscribe?.(); };
  }, [roomCode, router]);

  // Use the native CrazyGames invite URL when available and keep lobby visibility current.
  useEffect(() => {
    if (!session) return;
    let active = true;
    void getSdkInviteLink(roomCode).then((link) => {
      if (!active || !link) return;
      setInviteUrl(link);
      setPartyReady(true);
    });
    return () => { active = false; };
  }, [roomCode, session]);

  useEffect(() => {
    if (!session) return;
    void updateSdkRoom(roomCode, hud.phase === "waiting");
  }, [roomCode, session, hud.phase]);

  // Network sync: send input immediately on changes and every 45ms otherwise.
  useEffect(() => {
    if (!session) return;
    let active = true;
    let inFlight = false;
    let lastSent = 0;
    let lastServerTime = 0;

    async function push(force: boolean) {
      if (!active || inFlight || document.hidden) return;
      const now = Date.now();
      if (!force && now - lastSent < 40) return;
      inFlight = true;
      lastSent = now;
      const controls = controlsRef.current;
      const state = stateRef.current;
      const self = state?.players.find((player) => player.id === session!.playerId);
      const { mx, my } = moveVector(controls);
      const age = Math.min(120, Math.max(0, now - snapshotAtRef.current)) / 1000;
      const baseX = (self?.x ?? 600) + mx * 265 * age;
      const baseY = (self?.y ?? 360) + my * 265 * age;
      const aim = controls.touchAim ? controls.touchAim.angle ?? self?.aim ?? 0 : controls.pointerInside ? Math.atan2(controls.aimY - baseY, controls.aimX - baseX) : self?.aim ?? 0;
      const requestSeq = ++sequenceRef.current;
      try {
        sessionStore?.set(`coverfire:onlineSeq:${roomCode}`, String(requestSeq));
        const response = await fetch("/api/online", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          cache: "no-store",
          body: JSON.stringify({
            action: "sync",
            roomId: roomCode,
            token: session!.token,
            seq: requestSeq,
            input: { mx, my, aim, shoot: controls.mouseDown || controls.touchAim !== null, dash: controls.keys.has("shift") || controls.keys.has(" "), reload: controls.keys.has("r"), weapon: controls.weapon },
          }),
        });
        const data = await response.json();
        if (!active) return;
        if (!response.ok) {
          if (response.status === 403 || response.status === 404) setError(data.error || "This match has ended.");
          return;
        }
        if (data.serverTime < lastServerTime) return;
        lastServerTime = data.serverTime;
        const next = data.state as PublicRoom;
        const previousSelf = stateRef.current?.players.find((player) => player.id === session!.playerId);
        const nextSelf = next.players.find((player) => player.id === session!.playerId);
        if (previousSelf && nextSelf) {
          if (nextSelf.lastShotAt > previousSelf.lastShotAt) playSound("shot");
          if (nextSelf.hp < previousSelf.hp) playSound("hit");
          if (nextSelf.kills > previousSelf.kills) playSound("kill");
        }
        stateRef.current = next;
        snapshotAtRef.current = Date.now();
      } catch {
        /* Keep the last snapshot; the next heartbeat retries. */
      } finally {
        inFlight = false;
      }
    }

    flushRef.current = () => void push(true);
    void push(true);
    const interval = window.setInterval(() => void push(false), 45);
    return () => { active = false; window.clearInterval(interval); };
  }, [roomCode, session, playSound]);

  // HUD refresh at 10Hz keeps React off the 60fps render path.
  useEffect(() => {
    const interval = window.setInterval(() => {
      const state = stateRef.current;
      if (!state || !session) return;
      setHud(deriveHud(state, session.playerId, "online", Math.round(framesRef.current)));
    }, 100);
    return () => window.clearInterval(interval);
  }, [session]);

  // Canvas render loop with local prediction and remote interpolation.
  useEffect(() => {
    if (!session) return;
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext("2d", { alpha: false });
    if (!canvas || !ctx) return;
    const visual = new Map<PlayerSide, { x: number; y: number }>();
    const fx = new CosmeticFX();
    const feel = { hp: 100, deaths: 0, shot: 0, kills: 0 };
    let trauma = 0;
    let frame = 0;
    let last = performance.now();
    let windowStart = last;
    let frames = 0;

    function resize() {
      const bounds = canvas!.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
      const width = Math.max(320, Math.round(bounds.width * dpr));
      const height = Math.round(width * (ARENA_HEIGHT / ARENA_WIDTH));
      if (canvas!.width !== width || canvas!.height !== height) { canvas!.width = width; canvas!.height = height; }
    }
    resize();
    const observer = new ResizeObserver(resize);
    observer.observe(canvas);

    // Mouse wheel cycles weapons (throttled so trackpads don't spin through all three).
    let lastWheelSwitch = 0;
    function onWheel(event: WheelEvent) {
      event.preventDefault();
      const nowMs = performance.now();
      if (nowMs - lastWheelSwitch < 120) return;
      lastWheelSwitch = nowMs;
      const order: WeaponKey[] = ["pistol", "smg", "shotgun"];
      const next = order[(order.indexOf(controlsRef.current.weapon) + (event.deltaY > 0 ? 1 : 2)) % 3];
      controlsRef.current.weapon = next;
      setHud((previous) => ({ ...previous, weapon: next }));
      flushRef.current();
    }
    canvas.addEventListener("wheel", onWheel, { passive: false });

    const loop = (time: number) => {
      const state = stateRef.current;
      const delta = Math.min(120, time - last);
      last = time;
      frames++;
      if (time - windowStart > 500) {
        framesRef.current = Math.round((frames * 1000) / (time - windowStart));
        frames = 0;
        windowStart = time;
      }
      if (state) {
        const controls = controlsRef.current;
        const now = Date.now();
        const age = Math.min(110, Math.max(0, now - snapshotAtRef.current)) / 1000;
        const { mx, my } = moveVector(controls);
        const self = state.players.find((player) => player.id === session!.playerId);
        const predicted = self && self.hp > 0 && state.phase === "playing" ? moveWithCollisions(self.x, self.y, mx * 265 * age, my * 265 * age, state.coverHealth, mapCover(state.mapId)) : self;
        const localX = predicted?.x ?? 600;
        const localY = predicted?.y ?? 360;
        const aim = controls.touchAim ? controls.touchAim.angle ?? self?.aim ?? 0 : controls.pointerInside ? Math.atan2(controls.aimY - localY, controls.aimX - localX) : self?.aim ?? 0;
        const display: PublicRoom = {
          ...state,
          players: state.players.map((player) => {
            if (player.id === session!.playerId) return { ...player, x: localX, y: localY, aim };
            const previous = visual.get(player.id) ?? { x: player.x, y: player.y };
            const step = Math.min(1, Math.max(.18, delta / 55) * .55);
            const smooth = { x: previous.x + (player.x - previous.x) * step, y: previous.y + (player.y - previous.y) * step };
            visual.set(player.id, smooth);
            return { ...player, x: smooth.x, y: smooth.y };
          }),
        };
        const reticle = controls.touchAim
          ? { x: localX + Math.cos(aim) * 190, y: localY + Math.sin(aim) * 190 }
          : controls.pointerInside ? { x: controls.aimX, y: controls.aimY } : null;
        const selfHp = self?.hp ?? 100;
        const selfDeaths = self?.deaths ?? 0;
        const selfShot = self?.lastShotAt ?? 0;
        const selfKills = self?.kills ?? 0;
        if (selfHp === 100 && selfKills === 0 && selfDeaths === 0 && selfShot === 0) {
          feel.hp = 100; feel.deaths = 0; feel.shot = 0; feel.kills = 0; trauma = 0;
        }
        if (selfHp < feel.hp) trauma = Math.min(1, trauma + 0.45);
        if (selfDeaths > feel.deaths) trauma = Math.min(1, trauma + 0.7);
        if (selfShot !== feel.shot) { trauma = Math.min(1, trauma + 0.1); feel.shot = selfShot; }
        if (selfKills > feel.kills) { trauma = Math.min(1, trauma + 0.2); feel.kills = selfKills; }
        feel.hp = selfHp;
        feel.deaths = selfDeaths;
        trauma = Math.max(0, trauma - (delta / 1000) * 1.5);
        const scale = canvas!.width / ARENA_WIDTH;
        ctx!.setTransform(scale, 0, 0, scale, 0, 0);
        fx.update(display, now);
        drawArena(ctx!, display, { now, localId: session!.playerId, reticle, shake: trauma, localHp: selfHp });
        fx.draw(ctx!);
      }
      frame = requestAnimationFrame(loop);
    };
    frame = requestAnimationFrame(loop);
    return () => { cancelAnimationFrame(frame); observer.disconnect(); canvas.removeEventListener("wheel", onWheel); };
  }, [session]);

  useEffect(() => {
    function onKeyDown(event: KeyboardEvent) {
      if (event.target instanceof HTMLInputElement) return;
      const key = event.key.toLowerCase();
      if (key === "f") {
        event.preventDefault();
        void toggleArenaFullscreen();
        return;
      }
      if (!KEY_CODES.has(key)) return;
      event.preventDefault();
      const controls = controlsRef.current;
      controls.keys.add(key);
      if (key === "1" || key === "2" || key === "3") { controls.weapon = key === "1" ? "pistol" : key === "2" ? "smg" : "shotgun"; flushRef.current(); }
      if (key === "shift" || key === " " || key === "r") flushRef.current();
    }
    function onKeyUp(event: KeyboardEvent) {
      controlsRef.current.keys.delete(event.key.toLowerCase());
    }
    function onBlur() {
      const controls = controlsRef.current;
      controls.keys.clear(); controls.mouseDown = false; controls.touchAim = null; controls.touchMove = null;
      sticks.hideAll();
    }
    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);
    window.addEventListener("blur", onBlur);
    return () => { window.removeEventListener("keydown", onKeyDown); window.removeEventListener("keyup", onKeyUp); window.removeEventListener("blur", onBlur); };
  }, []);

  function arenaPoint(event: ReactPointerEvent<HTMLCanvasElement>) {
    const bounds = event.currentTarget.getBoundingClientRect();
    return { x: ((event.clientX - bounds.left) / bounds.width) * ARENA_WIDTH, y: ((event.clientY - bounds.top) / bounds.height) * ARENA_HEIGHT };
  }

  function pointerDown(event: ReactPointerEvent<HTMLCanvasElement>) {
    event.preventDefault();
    event.currentTarget.setPointerCapture(event.pointerId);
    const point = arenaPoint(event);
    const controls = controlsRef.current;
    if (event.pointerType === "touch") {
      if (point.x < ARENA_WIDTH * .46 && !controls.touchMove) controls.touchMove = { id: event.pointerId, startX: point.x, startY: point.y, mx: 0, my: 0 };
      else if (!controls.touchAim) controls.touchAim = { id: event.pointerId, startX: point.x, startY: point.y, angle: null };
      sticks.paint(event.currentTarget, controls.touchMove, controls.touchAim, point);
    } else {
      controls.aimX = point.x;
      controls.aimY = point.y;
      controls.pointerInside = true;
      if (event.button === 0) controls.mouseDown = true;
    }
    flushRef.current();
  }

  function pointerMove(event: ReactPointerEvent<HTMLCanvasElement>) {
    const point = arenaPoint(event);
    const controls = controlsRef.current;
    if (event.pointerType !== "touch") {
      controls.aimX = point.x;
      controls.aimY = point.y;
      controls.pointerInside = true;
      return;
    }
    if (controls.touchMove?.id === event.pointerId) {
      const dx = (point.x - controls.touchMove.startX) / 88;
      const dy = (point.y - controls.touchMove.startY) / 88;
      const length = Math.hypot(dx, dy);
      controls.touchMove.mx = length > 1 ? dx / length : dx;
      controls.touchMove.my = length > 1 ? dy / length : dy;
    }
    if (controls.touchAim?.id === event.pointerId) {
      const dx = point.x - controls.touchAim.startX;
      const dy = point.y - controls.touchAim.startY;
      if (Math.hypot(dx, dy) > 14) controls.touchAim.angle = Math.atan2(dy, dx);
    }
    if (event.pointerType === "touch") sticks.paint(event.currentTarget, controls.touchMove, controls.touchAim, point);
  }

  function pointerUp(event: ReactPointerEvent<HTMLCanvasElement>) {
    const controls = controlsRef.current;
    if (controls.touchMove?.id === event.pointerId) {
      controls.touchMove = null;
      sticks.hideMove();
    }
    if (controls.touchAim?.id === event.pointerId) {
      controls.touchAim = null;
      sticks.hideAim();
    }
    if (event.pointerType !== "touch") controls.mouseDown = false;
    flushRef.current();
  }

  function chooseWeapon(weapon: WeaponKey) {
    controlsRef.current.weapon = weapon;
    setHud((previous) => ({ ...previous, weapon }));
    flushRef.current();
  }

  useEffect(() => {
    function onFullscreenChange() {
      setIsFullscreen(isFullscreenActive());
    }
    document.addEventListener("fullscreenchange", onFullscreenChange);
    return () => document.removeEventListener("fullscreenchange", onFullscreenChange);
  }, []);

  async function toggleArenaFullscreen() {
    const frame = canvasRef.current?.closest(".arena-frame") ?? document.documentElement;
    setIsFullscreen(await toggleFullscreen(frame));
  }

  async function copyInvite() {
    const nativeLink = await getSdkInviteLink(roomCode);
    const url = nativeLink || inviteUrl || `${window.location.origin}/room/${roomCode}`;
    if (nativeLink) { setInviteUrl(nativeLink); setPartyReady(true); }
    try {
      await navigator.clipboard.writeText(url);
    } catch {
      const field = document.createElement("textarea");
      field.value = url;
      field.style.position = "fixed";
      field.style.opacity = "0";
      document.body.appendChild(field);
      field.select();
      document.execCommand("copy");
      field.remove();
    }
    setCopied(true);
    window.setTimeout(() => setCopied(false), 2200);
  }

  async function rematch() {
    if (!session || rematching) return;
    setRematching(true);
    const audioWasOn = soundRef.current;
    soundRef.current = false;
    await requestMidgameAd();
    soundRef.current = audioWasOn;
    try {
      const response = await fetch("/api/online", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "rematch", roomId: roomCode, token: session.token }),
      });
      const data = await response.json();
      if (response.ok) {
        stateRef.current = data.state;
        snapshotAtRef.current = Date.now();
        setHud(deriveHud(data.state, session.playerId, "online", Math.round(framesRef.current)));
      }
    } catch { /* Next sync will recover. */ } finally { setRematching(false); }
  }

  async function findAnother() {
    setError("");
    try {
      const response = await fetch("/api/online", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "quick", name: shooterName() }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "No match found.");
      sessionStore?.set(`coverfire:online:${data.roomId}`, data.token);
      window.location.href = `/room/${data.roomId}`;
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "No match found. Please try again.");
    }
  }

  function toggleSound() {
    if (platformMute.muted) return;
    const next = !soundEnabled;
    soundRef.current = next;
    setSoundEnabled(next);
    if (next) {
      try {
        audioRef.current ??= createAudioContext();
        void audioRef.current?.resume()?.catch(() => undefined);
      } catch { /* Optional audio. */ }
    }
  }

  if (error) {
    return (
      <div className="room-screen room-error-screen">
        <div className="room-error-card">
          <span className="error-symbol"><WifiOff size={32} /></span>
          <div className="section-kicker">// CONNECTION FAILED</div>
          <h1>CAN&apos;T JOIN<br /><span>THIS MATCH.</span></h1>
          <p>{error}</p>
          <Link href="/" className="primary-button">BACK TO HOME <ArrowRight size={18} /></Link>
          <button type="button" className="secondary-launch" onClick={() => void findAnother()}><Users size={15} /> FIND ANOTHER MATCH</button>
        </div>
      </div>
    );
  }

  if (!session) {
    return (
      <div className="room-screen room-loading-screen">
        <div className="loading-mark"><Crosshair size={39} /><LoaderCircle className="loading-spinner" size={71} /></div>
        <span>CONNECTING TO ARENA</span>
        <small>MATCH #{roomCode}</small>
      </div>
    );
  }

  const weapon = WEAPONS[hud.weapon];
  const dashReady = hud.dashIn <= 0;
  const saveStatus = progressState.status;
  const account = progressState.account;
  const saveLabel = saveStatus === "synced" ? (account ? `SAVED · ${account.username.slice(0, 10)}` : "CLOUD SAVED") : saveStatus === "saving" ? "SAVING..." : saveStatus === "loading" ? "SYNCING..." : "LOCAL SAVE";
  const audioLocked = platformMute.muted;
  const audioOn = soundEnabled && !audioLocked;
  const waiting = hud.phase === "waiting";
  const finished = hud.phase === "finished";

  return (
    <div className="room-screen">
      <header className="room-header page-container">
        <Link className="brand room-brand" href="/" aria-label="Coverfire home"><span className="brand-icon"><Crosshair size={26} strokeWidth={2.2} /></span><span className="brand-type"><strong>COVER<span>FIRE</span><i>.</i></strong><small>ONLINE ARENA</small></span></Link>
        <div className="room-header-center"><span className="room-header-label">{hud.isSquad ? "ONLINE 2V2" : "ONLINE 1V1"}</span><span className="room-header-code">#{roomCode}</span><span className="room-header-divider" /><span className={`connection-indicator ${hud.connection}`}><span className="live-dot" />{hud.connection === "online" ? "CONNECTED" : "RECONNECTING"}</span></div>
        <div className="room-header-actions">
          <span className={`save-chip ${saveStatus}`} title={account ? `Linked CrazyGames account · ${account.username}` : "Progress synced to the game backend"}>
            {saveStatus === "synced" ? <Cloud size={14} /> : <CloudOff size={14} />}{saveLabel}
          </span>
          <button className="icon-button sound-button" type="button" onClick={toggleSound} disabled={audioLocked} aria-label={audioLocked ? "Audio muted by CrazyGames" : audioOn ? "Mute game audio" : "Enable game audio"} title={audioLocked ? "Muted by CrazyGames" : audioOn ? "Mute audio" : "Enable audio"}>{audioOn ? <Volume2 size={19} /> : <VolumeX size={19} />}</button>
          <button className="icon-button fullscreen-button" type="button" onClick={() => void toggleArenaFullscreen()} aria-label={isFullscreen ? "Exit fullscreen (F)" : "Enter fullscreen (F)"} title={isFullscreen ? "Exit fullscreen (F)" : "Fullscreen (F)"}>{isFullscreen ? <Minimize2 size={19} /> : <Maximize2 size={19} />}</button>
          <button className="invite-button" type="button" onClick={copyInvite}>{copied ? <Check size={17} /> : <Link2 size={17} />}{copied ? "LINK COPIED" : "COPY INVITE LINK"}</button>
          <Link href="/" className="icon-button exit-button" aria-label="Leave match" title="Leave match"><ArrowLeft size={19} /></Link>
        </div>
      </header>

      <main className="game-main page-container">
        <div className="game-meta-row"><span><span className="meta-square" /> SECTOR 01 <span className="meta-muted">/ {hud.mapName}</span></span><span className="game-meta-right"><span className="meta-muted">{hud.isSquad ? "ONLINE 2V2" : "ONLINE 1V1"}</span> ROOM {roomCode} <span className="meta-slash">//</span> <span className="meta-muted">{hud.fps} FPS</span> <span className="meta-slash">//</span> <span className="meta-muted">{hud.connection === "online" ? "LIVE" : "RECONNECTING"}</span></span></div>

        <div className="scoreboard" key={`score-${hud.teamKills[0]}-${hud.teamKills[1]}-${hud.alphaKills}-${hud.bravoKills}`}>
          {hud.isSquad ? (
            <div className="scoreboard-side alpha"><span className="scoreboard-avatar">01</span><div className="scoreboard-player"><span className="scoreboard-side-label">BLUE TEAM{hud.selfTeam === 0 ? " · YOU" : ""}</span><strong>{hud.roster.filter((entry) => entry.team === 0).map((entry) => entry.name).join(" + ") || "BLUE TEAM"}</strong><div className="score-pips">{Array.from({ length: hud.target }, (_, index) => <span key={index} className={index < hud.teamKills[0] ? "filled" : ""} />)}</div></div><strong className="score-number">{hud.teamKills[0]}</strong></div>
          ) : (
            <div className="scoreboard-side alpha"><span className="scoreboard-avatar">01</span><div className="scoreboard-player"><span className="scoreboard-side-label">{session.playerId === "alpha" ? "YOU / BLUE TEAM" : "PLAYER 01 / BLUE TEAM"}</span><strong>{hud.alphaName}</strong><div className="score-pips">{Array.from({ length: 5 }, (_, index) => <span key={index} className={index < hud.alphaKills ? "filled" : ""} />)}</div></div><strong className="score-number">{hud.alphaKills}</strong></div>
          )}
          <div className="scoreboard-center"><span>FIRST TO {hud.target} KILLS</span><strong>VS</strong><small>{hud.isSquad ? "2V2 SQUAD" : "ONLINE 1V1"}</small></div>
          {hud.isSquad ? (
            <div className="scoreboard-side bravo"><strong className="score-number">{hud.teamKills[1]}</strong><div className="scoreboard-player"><span className="scoreboard-side-label">RED TEAM{hud.selfTeam === 1 ? " · YOU" : ""}</span><strong>{hud.roster.filter((entry) => entry.team === 1).map((entry) => entry.name).join(" + ") || "RED TEAM"}</strong><div className="score-pips">{Array.from({ length: hud.target }, (_, index) => <span key={index} className={index < hud.teamKills[1] ? "filled" : ""} />)}</div></div><span className="scoreboard-avatar">02</span></div>
          ) : (
            <div className="scoreboard-side bravo"><strong className="score-number">{hud.bravoKills}</strong><div className="scoreboard-player"><span className="scoreboard-side-label">{session.playerId === "bravo" ? "YOU / RED TEAM" : "PLAYER 02 / RED TEAM"}</span><strong>{hud.bravoName}</strong><div className="score-pips">{Array.from({ length: 5 }, (_, index) => <span key={index} className={index < hud.bravoKills ? "filled" : ""} />)}</div></div><span className="scoreboard-avatar">02</span></div>
          )}
        </div>
        {hud.isSquad && hud.roster.length > 0 ? (
          <div className="roster">
            {hud.roster.map((entry) => (
              <span key={entry.id} className={`roster-chip team-${entry.team}${entry.self ? " self" : ""}`}>
                <i style={{ width: `${Math.max(0, entry.hp)}%` }} />
                <b>{entry.self ? "YOU" : entry.name}</b>
                <small>{entry.bot ? "BOT" : `${Math.max(0, Math.round(entry.hp))} HP`}</small>
              </span>
            ))}
          </div>
        ) : null}

        {showRotate ? (
          <div className="rotate-tip" role="note">
            <span>ROTATE YOUR PHONE FOR THE FULL ARENA</span>
            <button type="button" aria-label="Dismiss rotate tip" onClick={() => { localStore?.set("coverfire:rotateDismissed", "1"); setShowRotate(false); }}>✕</button>
          </div>
        ) : null}
        <div className="arena-frame" ref={sticks.frameRef}>
          {sticks.sticks}
          <canvas ref={canvasRef} width={2400} height={1440} className="game-canvas" onPointerDown={pointerDown} onPointerMove={pointerMove} onPointerUp={pointerUp} onPointerCancel={pointerUp} onPointerLeave={(event) => { if (event.pointerType !== "touch") { controlsRef.current.pointerInside = false; controlsRef.current.mouseDown = false; } }} onContextMenu={(event) => event.preventDefault()} aria-label="Online one versus one arena. Use W A S D to move, mouse to aim, click to fire, and F for fullscreen." />
          <button type="button" className="exit-fullscreen-button" onClick={() => void toggleArenaFullscreen()}>EXIT FULLSCREEN <kbd>ESC</kbd></button>
          <ArenaVitals hp={hud.hp} ammo={hud.ammo} mag={weapon.mag} weaponName={weapon.name} reloadProgress={hud.reloadProgress} selfName={hud.selfName} opponentName={hud.opponentName} opponentHp={hud.opponentHp} />
          <div className="arena-top-left"><span className="arena-live"><span className="live-dot" /> {hud.phase === "playing" ? hud.isSquad ? "LIVE 2V2" : "LIVE 1V1" : waiting ? "WAITING FOR RIVAL" : "MATCH COMPLETE"}</span><span className="arena-separator" /><span>{hud.mapName}</span></div>
          <div className="arena-top-right">{hud.inCover ? <span className="cover-chip safe"><ShieldCheck size={14} /> IN COVER</span> : <span className="cover-chip exposed"><Target size={14} /> EXPOSED</span>}</div>
          {hud.phase === "playing" && !hud.opponentOnline ? <div className="opponent-warning"><WifiOff size={15} /> OPPONENT RECONNECTING...</div> : null}
          {hud.phase === "playing" ? <div className="practice-hint"><span><kbd>WASD</kbd> MOVE</span><span><kbd>MOUSE</kbd> AIM</span><span><kbd>CLICK</kbd> FIRE</span><span><kbd>SHIFT</kbd> DASH</span><span><kbd>R</kbd> RELOAD</span><span><kbd>F</kbd> FULLSCREEN</span></div> : null}
          {hud.phase === "playing" && hud.elapsed < 1.4 ? <div className="fight-banner"><span>FIGHT!</span></div> : null}
          {hud.phase === "playing" && hud.hp <= 0 ? <div className="respawn-note"><Crosshair size={24} /><strong>ELIMINATED</strong><span>RESPAWNING...</span></div> : null}
          <div className="touch-guide"><span className="touch-stick-guide"><span className="touch-ring" /><small>DRAG TO MOVE</small></span><span className="touch-stick-guide"><span className="touch-ring"><Crosshair size={24} /></span><small>DRAG TO AIM + FIRE</small></span></div>

          {waiting ? (
            <div className="match-overlay">
              <div className="overlay-card lobby-card">
                <div className="overlay-topline"><span className="live-dot" /> {partyReady ? "CRAZYGAMES PARTY LOBBY" : "MATCH CREATED"} <span>{hud.isSquad ? "SQUAD" : "01 / 02"}</span></div>
                <div className="waiting-graphic"><span className="waiting-orbit orbit-one" /><span className="waiting-orbit orbit-two" /><LoaderCircle size={30} className="loading-spinner" /></div>
                <div className="section-kicker">// YOUR ARENA IS READY</div>
                <h2>{hud.isSquad ? <>ASSEMBLE YOUR<br /><span>SQUAD.</span></> : <>WAITING FOR<br /><span>YOUR RIVAL.</span></>}</h2>
                <p>{hud.isSquad ? "Bots hold the empty slots so the fight starts now. Send this link — friends take over a bot on your team when they join." : "Send this link to your rival, or open it on their device. The match starts the moment they join."}</p>
                <div className="invite-url"><Link2 size={16} /><span>{inviteUrl}</span><button type="button" onClick={copyInvite} aria-label="Copy invite link">{copied ? <Check size={17} /> : <Copy size={17} />}</button></div>
                <button type="button" className="primary-button overlay-button" onClick={copyInvite}>{copied ? "LINK COPIED!" : "COPY INVITE LINK"}{copied ? <Check size={19} /> : <ArrowRight size={19} />}</button>
                <div className="waiting-footer"><span><span className="player-ready-dot" /> YOU&apos;RE READY</span><span><LoaderCircle size={14} className="loading-spinner" /> {hud.isSquad ? "BOTS FILL EMPTY SLOTS" : "WAITING FOR PLAYER 2"}</span></div>
              </div>
            </div>
          ) : null}

          {finished ? (
            <div className="match-overlay">
              <div className="overlay-card result-card">
                <div className="overlay-topline"><span className="live-dot" /> MATCH COMPLETE <span>{hud.isSquad ? `FIRST TO ${hud.target}` : "FIRST TO FIVE"}</span></div>
                <div className="result-icon">{(hud.isSquad ? hud.winnerTeam === hud.selfTeam : hud.winner === session.playerId) ? <Trophy size={34} /> : <Shield size={34} />}</div>
                <div className="section-kicker">// THE FINAL SCORE</div>
                <h2>{(hud.isSquad ? hud.winnerTeam === hud.selfTeam : hud.winner === session.playerId) ? <>VICTORY<span> IS YOURS.</span></> : <>NOT THIS<span> TIME.</span></>}</h2>
                <p>{hud.isSquad ? (hud.winnerTeam === hud.selfTeam ? "Your squad owned the arena. Run it back." : "The enemy squad took this one. Regroup and run it back.") : hud.winner === session.playerId ? "Clean shooting. The arena is yours — for now." : "Your rival got the better of you. Read the angle, then run it back."}</p>
                <div className="result-score">{hud.isSquad ? <><span>BLUE<strong>{hud.teamKills[0]}</strong></span><b>—</b><span><strong>{hud.teamKills[1]}</strong>RED</span></> : <><span>{hud.selfName}<strong>{hud.kills}</strong></span><b>—</b><span><strong>{hud.opponentKills}</strong>{hud.opponentName}</span></>}</div>
                <button type="button" className="primary-button overlay-button" onClick={rematch} disabled={rematching}>{rematching ? "RESTARTING..." : "PLAY AGAIN"}<RotateCcw size={18} /></button>
                <span className="result-note">{hud.isSquad ? "SAME ROOM. SAME SQUAD. FRESH SCORE." : "SAME ROOM. SAME RIVAL. FRESH SCORE."}</span>
              </div>
            </div>
          ) : null}
        </div>

        <div className="hud-layout">
          <div className="hud-panel health-panel"><div className="hud-label"><span><Heart size={15} /> HEALTH STATUS</span><span>{hud.hp > 0 && hud.hp < 30 ? "CRITICAL" : "OPERATIONAL"}</span></div><div className="health-value"><strong>{Math.round(hud.hp)}</strong><span>/ 100 HP</span></div><div className="health-track"><span style={{ width: `${hud.hp}%` }} className={hud.hp < 30 ? "low-health" : ""} /></div></div>
          <div className={`hud-panel ammo-panel${hud.ammo <= Math.max(1, Math.ceil(weapon.mag * 0.25)) ? " low-ammo" : ""}`}><div className="hud-label"><span><Crosshair size={15} /> EQUIPPED WEAPON</span><span>{hud.reloadProgress > 0 ? "RELOADING" : "READY TO FIRE"}</span></div><div className="ammo-content"><div><strong>{weapon.name}</strong><span>{hud.weapon === "pistol" ? "TRUSTY SIDEARM" : hud.weapon === "smg" ? "RAPID FIRE" : "CLOSE QUARTERS"}</span></div><div className="ammo-value"><strong>{hud.ammo}</strong><span>/ {weapon.mag}</span></div></div><div className="ammo-track" style={{ "--segments": String(weapon.mag) } as CSSProperties}><span style={{ width: `${(hud.ammo / weapon.mag) * 100}%` }} /></div>{hud.reloadProgress > 0 ? <div className="reload-track"><span style={{ width: `${hud.reloadProgress}%` }} /></div> : null}</div>
          <div className="hud-panel tactical-panel"><div className="hud-label"><span><Shield size={15} /> TACTICAL STATUS</span><span>{hud.fps} FPS</span></div><div className="tactical-line"><span><Zap size={17} /> DASH</span><strong className={dashReady ? "status-good" : "status-wait"}>{dashReady ? "READY" : `${hud.dashIn.toFixed(1)}S`}</strong></div><div className="tactical-line"><span><Users size={17} /> RIVAL</span><strong className={hud.opponentOnline ? "status-good" : "status-wait"}>{hud.opponentOnline ? "CONNECTED" : waiting ? "NOT JOINED" : "RECONNECTING"}</strong></div></div>
        </div>

        <div className="loadout-section"><div className="loadout-title"><span>// SELECT YOUR LOADOUT</span><span>SWITCH GUNS ANYTIME <ArrowRight size={14} /></span></div><div className="loadout-grid">{(["pistol", "smg", "shotgun"] as WeaponKey[]).map((key, index) => <button type="button" key={key} className={`weapon-option ${hud.weapon === key ? "active" : ""}`} onClick={() => chooseWeapon(key)}><span className="weapon-option-number">0{index + 1}</span><span className="weapon-symbol">{key === "pistol" ? <Target size={23} /> : key === "smg" ? <Crosshair size={23} /> : <Maximize2 size={23} />}</span><span className="weapon-option-name"><strong>{WEAPONS[key].name}</strong><small>{key === "pistol" ? "BALANCED / RELIABLE" : key === "smg" ? "FAST / AGGRESSIVE" : "HEAVY / CLOSE RANGE"}</small></span><kbd>{index + 1}</kbd></button>)}</div></div>

        <div className="game-bottom"><div><span className="bottom-control-label">CONTROLS</span><span><kbd>W</kbd><kbd>A</kbd><kbd>S</kbd><kbd>D</kbd> MOVE</span><span><kbd>CLICK</kbd> FIRE</span><span><kbd>SHIFT</kbd> DASH</span><span><kbd>R</kbd> RELOAD</span><span><kbd>WHEEL</kbd> GUNS</span><span><kbd>F</kbd> FULLSCREEN</span></div><div className="identity-field"><span>ROOM</span><strong className="identity-code">{roomCode}</strong></div></div>
        <div className="mobile-actions four"><button type="button" onPointerDown={() => { controlsRef.current.keys.add("shift"); flushRef.current(); }} onPointerUp={() => controlsRef.current.keys.delete("shift")}><Zap size={18} /> DASH</button><button type="button" onPointerDown={() => { controlsRef.current.keys.add("r"); flushRef.current(); }} onPointerUp={() => controlsRef.current.keys.delete("r")}><RotateCcw size={18} /> RELOAD</button><button type="button" onClick={() => chooseWeapon(hud.weapon === "pistol" ? "smg" : hud.weapon === "smg" ? "shotgun" : "pistol")}><Play size={18} /> GUN</button><button type="button" onClick={copyInvite}><Link2 size={18} /> INVITE</button></div>
        <div className="game-footer"><span><Gamepad2 size={15} /> COVERFIRE ONLINE 1V1</span><span>GOOD COVER. BETTER AIM.</span><Link href="/">EXIT MATCH <ArrowRight size={14} /></Link></div>
      </main>
    </div>
  );
}
