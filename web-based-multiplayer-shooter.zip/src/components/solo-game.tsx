"use client";

import { useCallback, useEffect, useRef, useState, type CSSProperties, type PointerEvent as ReactPointerEvent } from "react";
import Link from "next/link";
import { ArrowLeft, ArrowRight, Bot, Cloud, CloudOff, Crosshair, Gamepad2, Heart, Maximize2, Minimize2, Play, RotateCcw, Shield, ShieldCheck, Target, Trophy, Volume2, VolumeX, Zap } from "lucide-react";
import {
  ARENA_HEIGHT,
  ARENA_WIDTH,
  WEAPONS,
  advanceGame,
  applyPlayerInput,
  createPlayer,
  createRoomState,
  isPlayerInCover,
  resetMatch,
  type GamePhase,
  type PlayerSide,
  type PublicRoom,
  type RoomState,
  type WeaponKey,
} from "@/lib/game";
import { CosmeticFX, drawArena } from "@/lib/render";
import { ArenaVitals } from "@/components/arena-vitals";
import { createAudioContext, localStore } from "@/lib/browser";
import { useTouchSticks } from "@/components/touch-sticks";
import { requestMidgameAd, useGameSdk, useSdkMute } from "@/lib/crazygames";
import { isFullscreenActive, toggleFullscreen } from "@/lib/fullscreen";
import { useProgress } from "@/lib/progress-client";

const STEP_MS = 1000 / 60;
const KEY_CODES = new Set(["w", "a", "s", "d", "arrowup", "arrowdown", "arrowleft", "arrowright", "shift", " ", "r", "1", "2", "3"]);

type TouchMove = { id: number; startX: number; startY: number; mx: number; my: number };
type TouchAim = { id: number; startX: number; startY: number; angle: number | null };

type Controls = {
  keys: Set<string>;
  aimX: number;
  aimY: number;
  pointerInside: boolean;
  mouseDown: boolean;
  touchMove: TouchMove | null;
  touchAim: TouchAim | null;
  weapon: WeaponKey;
  dashQueued: boolean;
  reloadQueued: boolean;
};

type Snapshot = {
  phase: GamePhase;
  hp: number;
  kills: number;
  deaths: number;
  ammo: number;
  weapon: WeaponKey;
  reloadProgress: number;
  dashIn: number;
  inCover: boolean;
  opponentName: string;
  opponentHp: number;
  opponentKills: number;
  winner: PlayerSide | null;
  fps: number;
  elapsed: number;
  touch: boolean;
};

function freshControls(): Controls {
  return {
    keys: new Set(),
    aimX: 760,
    aimY: 360,
    pointerInside: false,
    mouseDown: false,
    touchMove: null,
    touchAim: null,
    weapon: "pistol",
    dashQueued: false,
    reloadQueued: false,
  };
}

function moveVector(controls: Controls) {
  // WASD + arrow keys.
  let mx = Number(controls.keys.has("d") || controls.keys.has("arrowright")) - Number(controls.keys.has("a") || controls.keys.has("arrowleft"));
  let my = Number(controls.keys.has("s") || controls.keys.has("arrowdown")) - Number(controls.keys.has("w") || controls.keys.has("arrowup"));
  if (controls.touchMove) { mx += controls.touchMove.mx; my += controls.touchMove.my; }
  const length = Math.hypot(mx, my);
  return length > 1 ? { mx: mx / length, my: my / length } : { mx, my };
}

const INITIAL_HUD: Snapshot = {
  phase: "playing",
  hp: 100,
  kills: 0,
  deaths: 0,
  ammo: WEAPONS.pistol.mag,
  weapon: "pistol",
  reloadProgress: 0,
  dashIn: 0,
  inCover: false,
  opponentName: "TRAINING BOT",
  opponentHp: 100,
  opponentKills: 0,
  winner: null,
  fps: 60,
  elapsed: 0,
  touch: false,
};

function shooterName() {
  if (typeof window === "undefined") return "ROOKIE";
  return (localStore?.get("coverfire:name") || "ROOKIE").replace(/[^a-zA-Z0-9 _-]/g, "").trim().slice(0, 16).toUpperCase() || "ROOKIE";
}

function botSkillSetting(): 0 | 1 | 2 {
  const raw = typeof window === "undefined" ? "" : localStore?.get("coverfire:botSkill") ?? "";
  return raw === "0" || raw === "2" ? (Number(raw) as 0 | 2) : 1;
}

function buildSoloMatch(name: string): RoomState {
  const now = Date.now();
  const state = createRoomState("SOLO", now, "practice", "foundry", botSkillSetting());
  const human = createPlayer("alpha", "", name, now);
  const bot = createPlayer("bravo", "", "TRAINING BOT", now);
  bot.isBot = true;
  bot.weapon = "smg";
  state.players = [human, bot];
  state.phase = "playing";
  state.startedAt = now;
  return state;
}

export function SoloGame({ embed = false }: { embed?: boolean }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const stateRef = useRef<RoomState | null>(null);
  const controlsRef = useRef<Controls>(freshControls());
  const clockRef = useRef(0);
  const sequenceRef = useRef(0);
  const reportedRef = useRef(false);
  const soundRef = useRef(false);
  const audioRef = useRef<AudioContext | null>(null);
  const [hud, setHud] = useState<Snapshot>(INITIAL_HUD);
  const [soundEnabled, setSoundEnabled] = useState(false);
  const sticks = useTouchSticks();
  const [showRotate, setShowRotate] = useState(
    () => typeof window === "undefined" || localStore?.get("coverfire:rotateDismissed") !== "1",
  );
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [name, setName] = useState("ROOKIE");
  const [nameDraft, setNameDraft] = useState("");
  const [lastScore, setLastScore] = useState<{ kills: number; won: boolean } | null>(null);
  const platformMute = useSdkMute();
  const progressState = useProgress();
  const platformMuteRef = useRef(false);
  const recordRef = useRef(progressState.record);
  platformMuteRef.current = platformMute.muted;
  recordRef.current = progressState.record;
  useGameSdk(hud.phase, hud.winner === "alpha");

  const playSound = useCallback((kind: "shot" | "hit" | "kill") => {
    if (!soundRef.current || platformMuteRef.current) return;
    try {
      const audio = audioRef.current ?? createAudioContext();
      if (!audio) return;
      audioRef.current = audio;
      if (audio.state === "suspended") void audio.resume().catch(() => undefined);
      const start = audio.currentTime;
      const oscillator = audio.createOscillator();
      const gain = audio.createGain();
      oscillator.type = kind === "kill" ? "triangle" : "square";
      oscillator.frequency.setValueAtTime(kind === "shot" ? 150 : kind === "hit" ? 95 : 520, start);
      oscillator.frequency.exponentialRampToValueAtTime(kind === "kill" ? 160 : 40, start + .12);
      gain.gain.setValueAtTime(kind === "shot" ? .035 : .06, start);
      gain.gain.exponentialRampToValueAtTime(.0001, start + .13);
      oscillator.connect(gain).connect(audio.destination);
      oscillator.start(start);
      oscillator.stop(start + .14);
    } catch { /* Audio is optional. */ }
  }, []);

  const saveName = useCallback((value: string) => {
    const cleaned = value.replace(/[^a-zA-Z0-9 _-]/g, "").trim().slice(0, 16).toUpperCase() || "ROOKIE";
    setNameDraft(cleaned);
    localStore?.set("coverfire:name", cleaned);
    const state = stateRef.current;
    const human = state?.players.find((player) => player.id === "alpha");
    if (human) human.name = cleaned;
    setName(cleaned);
  }, []);

  useEffect(() => {
    const saved = shooterName();
    setName(saved);
    setNameDraft(saved);

    const state = buildSoloMatch(saved);
    stateRef.current = state;
    clockRef.current = Date.now();
    sequenceRef.current = 0;
    reportedRef.current = false;

    const canvas = canvasRef.current;
    const ctx = canvas?.getContext("2d", { alpha: false });
    if (!canvas || !ctx) return;

    function resize() {
      const rect = canvas!.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
      const width = Math.max(320, Math.round(rect.width * dpr));
      const height = Math.round(width * (ARENA_HEIGHT / ARENA_WIDTH));
      if (canvas!.width !== width || canvas!.height !== height) {
        canvas!.width = width;
        canvas!.height = height;
      }
    }
    resize();
    const observer = new ResizeObserver(resize);
    observer.observe(canvas);

    // Mouse wheel cycles weapons (throttled so trackpads don't spin through all three).
    let lastWheelSwitch = 0;
    function onWheel(event: WheelEvent) {
      event.preventDefault();
      const nowMs = performance.now();
      if (nowMs - lastWheelSwitch < 120) return;
      lastWheelSwitch = nowMs;
      const order: WeaponKey[] = ["pistol", "smg", "shotgun"];
      const controls = controlsRef.current;
      const next = order[(order.indexOf(controls.weapon) + (event.deltaY > 0 ? 1 : 2)) % 3];
      controls.weapon = next;
      setHud((previous) => (previous ? { ...previous, weapon: next } : previous));
    }
    canvas.addEventListener("wheel", onWheel, { passive: false });

    function publish(fps: number, force = false) {
      const current = stateRef.current;
      if (!current) return;
      const human = current.players.find((player) => player.id === "alpha");
      const bot = current.players.find((player) => player.id === "bravo");
      if (!human || !bot) return;
      const weapon = WEAPONS[human.weapon];
      const reload = human.reloadEndsAt ? Math.max(0, Math.min(100, (1 - (human.reloadEndsAt - clockRef.current) / weapon.reload) * 100)) : 0;
      void force;
      setHud({
        phase: current.phase,
        hp: human.hp,
        kills: human.kills,
        deaths: human.deaths,
        ammo: human.ammo[human.weapon],
        weapon: human.weapon,
        reloadProgress: reload,
        dashIn: Math.max(0, human.dashReadyAt - clockRef.current) / 1000,
        inCover: isPlayerInCover(human, bot, current),
        opponentName: bot.name,
        opponentHp: bot.hp,
        opponentKills: bot.kills,
        winner: current.winner,
        fps,
        elapsed: Math.max(0, (clockRef.current - current.startedAt) / 1000),
        touch: controlsRef.current.touchMove !== null || controlsRef.current.touchAim !== null,
      });

      if (current.phase === "finished" && !reportedRef.current) {
        reportedRef.current = true;
        setLastScore({ kills: human.kills, won: current.winner === "alpha" });
        void fetch("/api/matches", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ callsign: human.name, kills: human.kills, deaths: human.deaths, won: current.winner === "alpha", durationMs: Math.max(0, Date.now() - current.startedAt) }),
        }).catch(() => undefined);
        void recordRef.current({
          callsign: human.name,
          kills: human.kills,
          deaths: human.deaths,
          won: current.winner === "alpha",
          durationMs: Math.max(0, Date.now() - current.startedAt),
          weapon: human.weapon,
        });
      }
    }

    function simulateStep() {
      const current = stateRef.current;
      if (!current) return;
      const human = current.players.find((player) => player.id === "alpha");
      if (!human) return;
      clockRef.current += STEP_MS;
      const now = clockRef.current;
      const controls = controlsRef.current;
      const previousShot = human.lastShotAt;
      const previousKills = human.kills;
      const previousHp = human.hp;
      const previousBotShot = current.players.find((player) => player.id === "bravo")?.lastShotAt ?? 0;
      const { mx, my } = moveVector(controls);
      const aim = controls.touchAim
        ? controls.touchAim.angle ?? human.aim
        : controls.pointerInside
          ? Math.atan2(controls.aimY - human.y, controls.aimX - human.x)
          : human.aim;
      const dash = controls.dashQueued || controls.keys.has("shift") || controls.keys.has(" ");
      const reload = controls.reloadQueued || controls.keys.has("r");
      controls.dashQueued = false;
      controls.reloadQueued = false;
      applyPlayerInput(current, human, { mx, my, aim, shoot: controls.mouseDown || controls.touchAim !== null, dash, reload, weapon: controls.weapon }, now, ++sequenceRef.current);
      advanceGame(current, now);

      if (human.lastShotAt !== previousShot) playSound("shot");
      if (human.kills > previousKills) playSound("kill");
      else if (human.hp < previousHp) playSound("hit");
      const bot = current.players.find((player) => player.id === "bravo");
      if (bot && bot.lastShotAt !== previousBotShot && Math.abs(bot.x - human.x) < 460) playSound("shot");
    }

    const feel = { hp: 100, deaths: 0, shot: 0, kills: 0 };
    let trauma = 0;
    const fx = new CosmeticFX();

    function draw(fps: number, delta: number) {
      const current = stateRef.current;
      if (!current) return;
      const human = current.players.find((player) => player.id === "alpha");
      if (!human) return;
      // Screen-shake trauma follows the local player's combat events.
      if (human.hp === 100 && human.kills === 0 && human.deaths === 0 && human.lastShotAt === 0) {
        feel.hp = 100; feel.deaths = 0; feel.shot = 0; feel.kills = 0; trauma = 0;
      }
      if (human.hp < feel.hp) trauma = Math.min(1, trauma + 0.45);
      if (human.deaths > feel.deaths) trauma = Math.min(1, trauma + 0.7);
      if (human.lastShotAt !== feel.shot) { trauma = Math.min(1, trauma + 0.1); feel.shot = human.lastShotAt; }
      if (human.kills > feel.kills) { trauma = Math.min(1, trauma + 0.2); feel.kills = human.kills; }
      feel.hp = human.hp;
      feel.deaths = human.deaths;
      trauma = Math.max(0, trauma - (delta / 1000) * 1.5);
      const controls = controlsRef.current;
      const scale = canvas!.width / ARENA_WIDTH;
      ctx!.setTransform(scale, 0, 0, scale, 0, 0);
      const reticle = controls.touchAim
        ? { x: human.x + Math.cos(human.aim) * 190, y: human.y + Math.sin(human.aim) * 190 }
        : controls.pointerInside ? { x: controls.aimX, y: controls.aimY } : null;
      const snapshot = current as unknown as PublicRoom;
      fx.update(snapshot, clockRef.current);
      drawArena(ctx!, snapshot, { now: clockRef.current, localId: "alpha", reticle, shake: trauma, localHp: human.hp });
      fx.draw(ctx!);
      ctx!.font = "bold 11px monospace";
      ctx!.textAlign = "right";
      ctx!.fillStyle = "rgba(215,232,214,.45)";
      ctx!.fillText(`${fps} FPS`, ARENA_WIDTH - 42, ARENA_HEIGHT - 38);
    }

    let raf = 0;
    let lastFrame = performance.now();
    let accumulator = 0;
    let frames = 0;
    let fpsWindow = lastFrame;
    let fps = 60;
    let hudAt = 0;

    const loop = (time: number) => {
      const delta = Math.min(90, Math.max(0, time - lastFrame));
      lastFrame = time;
      accumulator += delta;
      let steps = 0;
      while (accumulator >= STEP_MS && steps < 4) {
        simulateStep();
        accumulator -= STEP_MS;
        steps++;
      }
      if (accumulator > STEP_MS * 4) accumulator = 0;
      frames++;
      if (time - fpsWindow >= 500) {
        fps = Math.round((frames * 1000) / (time - fpsWindow));
        frames = 0;
        fpsWindow = time;
      }
      draw(fps, delta);
      if (time - hudAt >= 100) {
        hudAt = time;
        publish(fps, false);
      }
      raf = requestAnimationFrame(loop);
    };

    const onVisibility = () => {
      lastFrame = performance.now();
      accumulator = 0;
    };
    document.addEventListener("visibilitychange", onVisibility);
    raf = requestAnimationFrame(loop);
    publish(60, true);
    return () => {
      cancelAnimationFrame(raf);
      observer.disconnect();
      canvas.removeEventListener("wheel", onWheel);
      document.removeEventListener("visibilitychange", onVisibility);
    };
  }, [playSound]);

  useEffect(() => {
    function onKeyDown(event: KeyboardEvent) {
      if (event.target instanceof HTMLInputElement) return;
      const key = event.key.toLowerCase();
      if (key === "f") {
        event.preventDefault();
        void toggleArenaFullscreen();
        return;
      }
      if (!KEY_CODES.has(key)) return;
      event.preventDefault();
      const controls = controlsRef.current;
      controls.keys.add(key);
      if (key === "1" || key === "2" || key === "3") controls.weapon = key === "1" ? "pistol" : key === "2" ? "smg" : "shotgun";
    }
    function onKeyUp(event: KeyboardEvent) {
      controlsRef.current.keys.delete(event.key.toLowerCase());
    }
    function onBlur() {
      const controls = controlsRef.current;
      controls.keys.clear();
      controls.mouseDown = false;
      controls.touchMove = null;
      controls.touchAim = null;
      sticks.hideAll();
    }
    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);
    window.addEventListener("blur", onBlur);
    return () => {
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
      window.removeEventListener("blur", onBlur);
    };
  }, []);

  function arenaPoint(event: ReactPointerEvent<HTMLCanvasElement>) {
    const bounds = event.currentTarget.getBoundingClientRect();
    return { x: ((event.clientX - bounds.left) / bounds.width) * ARENA_WIDTH, y: ((event.clientY - bounds.top) / bounds.height) * ARENA_HEIGHT };
  }

  function pointerDown(event: ReactPointerEvent<HTMLCanvasElement>) {
    event.preventDefault();
    event.currentTarget.setPointerCapture(event.pointerId);
    const point = arenaPoint(event);
    const controls = controlsRef.current;
    if (event.pointerType === "touch") {
      if (point.x < ARENA_WIDTH * .46 && !controls.touchMove) controls.touchMove = { id: event.pointerId, startX: point.x, startY: point.y, mx: 0, my: 0 };
      else if (!controls.touchAim) controls.touchAim = { id: event.pointerId, startX: point.x, startY: point.y, angle: null };
      sticks.paint(event.currentTarget, controls.touchMove, controls.touchAim, point);
    } else {
      controls.aimX = point.x;
      controls.aimY = point.y;
      controls.pointerInside = true;
      if (event.button === 0) controls.mouseDown = true;
    }
  }

  function pointerMove(event: ReactPointerEvent<HTMLCanvasElement>) {
    const point = arenaPoint(event);
    const controls = controlsRef.current;
    if (event.pointerType !== "touch") {
      controls.aimX = point.x;
      controls.aimY = point.y;
      controls.pointerInside = true;
      return;
    }
    if (controls.touchMove?.id === event.pointerId) {
      const dx = (point.x - controls.touchMove.startX) / 88;
      const dy = (point.y - controls.touchMove.startY) / 88;
      const length = Math.hypot(dx, dy);
      controls.touchMove.mx = length > 1 ? dx / length : dx;
      controls.touchMove.my = length > 1 ? dy / length : dy;
    }
    if (controls.touchAim?.id === event.pointerId) {
      const dx = point.x - controls.touchAim.startX;
      const dy = point.y - controls.touchAim.startY;
      if (Math.hypot(dx, dy) > 14) controls.touchAim.angle = Math.atan2(dy, dx);
    }
    if (event.pointerType === "touch") sticks.paint(event.currentTarget, controls.touchMove, controls.touchAim, point);
  }

  function pointerUp(event: ReactPointerEvent<HTMLCanvasElement>) {
    const controls = controlsRef.current;
    if (controls.touchMove?.id === event.pointerId) {
      controls.touchMove = null;
      sticks.hideMove();
    }
    if (controls.touchAim?.id === event.pointerId) {
      controls.touchAim = null;
      sticks.hideAim();
    }
    if (event.pointerType !== "touch") controls.mouseDown = false;
  }

  function chooseWeapon(weapon: WeaponKey) {
    controlsRef.current.weapon = weapon;
    setHud((previous) => previous ? { ...previous, weapon } : previous);
  }

  useEffect(() => {
    const callsign = progressState.progress.callsign;
    if (!callsign) return;
    const human = stateRef.current?.players.find((player) => player.id === "alpha");
    if (human && human.name !== callsign) human.name = callsign;
    setName((previous) => (previous === callsign ? previous : callsign));
    setNameDraft((previous) => (previous === callsign ? previous : callsign));
  }, [progressState.progress.callsign]);

  const rematchBusyRef = useRef(false);
  const rematch = useCallback(async () => {
    const current = stateRef.current;
    if (!current || rematchBusyRef.current) return;
    rematchBusyRef.current = true;
    const audioWasOn = soundRef.current;
    soundRef.current = false;
    await requestMidgameAd();
    soundRef.current = audioWasOn;
    rematchBusyRef.current = false;
    resetMatch(current, clockRef.current);
    reportedRef.current = false;
    controlsRef.current.mouseDown = false;
    setLastScore(null);
    setHud((previous) => previous ? { ...previous, phase: "playing", hp: 100, kills: 0, deaths: 0, opponentHp: 100, opponentKills: 0, winner: null, ammo: WEAPONS[controlsRef.current.weapon].mag, elapsed: 0 } : previous);
  }, []);

  useEffect(() => {
    function onFullscreenChange() {
      setIsFullscreen(isFullscreenActive());
    }
    document.addEventListener("fullscreenchange", onFullscreenChange);
    return () => document.removeEventListener("fullscreenchange", onFullscreenChange);
  }, []);

  async function toggleArenaFullscreen() {
    const frame = canvasRef.current?.closest(".arena-frame") ?? document.documentElement;
    setIsFullscreen(await toggleFullscreen(frame));
  }

  function toggleSound() {
    if (platformMute.muted) return;
    const next = !soundEnabled;
    soundRef.current = next;
    setSoundEnabled(next);
    if (next) {
      try {
        audioRef.current ??= createAudioContext();
        void audioRef.current?.resume()?.catch(() => undefined);
      } catch { /* Optional audio. */ }
    }
  }

  const weapon = WEAPONS[hud.weapon];
  const dashReady = hud.dashIn <= 0;
  const weaponLabel = hud.weapon === "pistol" ? "TRUSTY SIDEARM" : hud.weapon === "smg" ? "RAPID FIRE" : "CLOSE QUARTERS";
  const saveStatus = progressState.status;
  const account = progressState.account;
  const saveLabel = saveStatus === "synced" ? (account ? `SAVED · ${account.username.slice(0, 10)}` : "CLOUD SAVED") : saveStatus === "saving" ? "SAVING..." : saveStatus === "loading" ? "SYNCING..." : "LOCAL SAVE";
  const audioLocked = platformMute.muted;
  const audioOn = soundEnabled && !audioLocked;

  return (
    <div className="room-screen">
      <header className="room-header page-container">
        <Link className="brand room-brand" href="/" aria-label="Back to Coverfire home"><span className="brand-icon"><Crosshair size={26} strokeWidth={2.2} /></span><span className="brand-type"><strong>COVER<span>FIRE</span><i>.</i></strong><small>ONLINE ARENA</small></span></Link>
        <div className="room-header-center"><span className="room-header-label">SOLO PRACTICE</span><span className="room-header-code">#{hud.fps} FPS</span><span className="room-header-divider" /><span className="connection-indicator online"><span className="live-dot" />LOCAL SIMULATION</span></div>
        <div className="room-header-actions">
          <span className={`save-chip ${saveStatus}`} title={account ? `Linked CrazyGames account · ${account.username}` : "Progress saved in this browser and synced to the game backend"}>
            {saveStatus === "synced" ? <Cloud size={14} /> : <CloudOff size={14} />}{saveLabel}
          </span>
          <button className="icon-button sound-button" type="button" onClick={toggleSound} disabled={audioLocked} aria-label={audioLocked ? "Audio muted by CrazyGames" : audioOn ? "Mute game audio" : "Enable game audio"} title={audioLocked ? "Muted by CrazyGames" : audioOn ? "Mute audio" : "Enable audio"}>{audioOn ? <Volume2 size={19} /> : <VolumeX size={19} />}</button>
          <button className="icon-button fullscreen-button" type="button" onClick={() => void toggleArenaFullscreen()} aria-label={isFullscreen ? "Exit fullscreen (F)" : "Enter fullscreen (F)"} title={isFullscreen ? "Exit fullscreen (F)" : "Fullscreen (F)"}>{isFullscreen ? <Minimize2 size={19} /> : <Maximize2 size={19} />}</button>
          <span className="practice-tag"><Bot size={17} /> VS BOT</span>
          {embed ? null : <Link href="/" className="icon-button exit-button" aria-label="Leave match" title="Leave match"><ArrowLeft size={19} /></Link>}
        </div>
      </header>

      <main className="game-main page-container">
        <div className="game-meta-row"><span><span className="meta-square" /> SECTOR 01 <span className="meta-muted">/ THE FOUNDRY</span></span><span className="game-meta-right"><span className="meta-muted">OPTION A</span> SOLO PRACTICE <span className="meta-slash">//</span> <span className="meta-muted">TRAINING BOT ACTIVE</span> <span className="meta-slash">//</span> <span className="meta-muted">{hud.fps} FPS</span></span></div>

        <div className="scoreboard" key={`score-${hud.kills}-${hud.opponentKills}`}>
          <div className="scoreboard-side alpha"><span className="scoreboard-avatar">01</span><div className="scoreboard-player"><span className="scoreboard-side-label">YOU / BLUE TEAM</span><strong>{name}</strong><div className="score-pips">{Array.from({ length: 5 }, (_, index) => <span key={index} className={index < hud.kills ? "filled" : ""} />)}</div></div><strong className="score-number">{hud.kills}</strong></div>
          <div className="scoreboard-center"><span>FIRST TO 5 KILLS</span><strong>VS</strong><small>TRAINING PROTOCOL</small></div>
          <div className="scoreboard-side bravo"><strong className="score-number">{hud.opponentKills}</strong><div className="scoreboard-player"><span className="scoreboard-side-label">AI OPPONENT / RED TEAM</span><strong>{hud.opponentName}</strong><div className="score-pips">{Array.from({ length: 5 }, (_, index) => <span key={index} className={index < hud.opponentKills ? "filled" : ""} />)}</div></div><span className="scoreboard-avatar">02</span></div>
        </div>

        {showRotate ? (
          <div className="rotate-tip" role="note">
            <span>ROTATE YOUR PHONE FOR THE FULL ARENA</span>
            <button type="button" aria-label="Dismiss rotate tip" onClick={() => { localStore?.set("coverfire:rotateDismissed", "1"); setShowRotate(false); }}>✕</button>
          </div>
        ) : null}
        <div className="arena-frame" ref={sticks.frameRef}>
          {sticks.sticks}
          <canvas ref={canvasRef} width={2400} height={1440} className="game-canvas" onPointerDown={pointerDown} onPointerMove={pointerMove} onPointerUp={pointerUp} onPointerCancel={pointerUp} onPointerLeave={(event) => { if (event.pointerType !== "touch") { controlsRef.current.pointerInside = false; controlsRef.current.mouseDown = false; } }} onContextMenu={(event) => event.preventDefault()} aria-label="Solo practice arena. Use W A S D to move, mouse to aim, click to fire, and F for fullscreen." />
          <button type="button" className="exit-fullscreen-button" onClick={() => void toggleArenaFullscreen()}>EXIT FULLSCREEN <kbd>ESC</kbd></button>
          <ArenaVitals hp={hud.hp} ammo={hud.ammo} mag={weapon.mag} weaponName={weapon.name} reloadProgress={hud.reloadProgress} selfName={name} opponentName={hud.opponentName} opponentHp={hud.opponentHp} />
          <div className="arena-top-left"><span className="arena-live"><span className="live-dot" /> {hud.phase === "playing" ? "SOLO PRACTICE" : hud.phase === "waiting" ? "STANDBY" : "MATCH COMPLETE"}</span><span className="arena-separator" /><span>MAP 01 — THE FOUNDRY</span></div>
          <div className="arena-top-right">{hud.inCover ? <span className="cover-chip safe"><ShieldCheck size={14} /> IN COVER</span> : <span className="cover-chip exposed"><Target size={14} /> EXPOSED</span>}</div>
          {hud.phase === "playing" ? <div className="practice-hint"><span><kbd>WASD</kbd> MOVE</span><span><kbd>MOUSE</kbd> AIM</span><span><kbd>CLICK</kbd> FIRE</span><span><kbd>SHIFT</kbd> DASH</span><span><kbd>R</kbd> RELOAD</span><span><kbd>F</kbd> FULLSCREEN</span></div> : null}
          {hud.phase === "playing" && hud.elapsed < 1.4 ? <div className="fight-banner"><span>FIGHT!</span></div> : null}
          {hud.phase === "playing" && hud.hp <= 0 ? <div className="respawn-note"><Crosshair size={24} /><strong>ELIMINATED</strong><span>RESPAWNING...</span></div> : null}
          <div className="touch-guide"><span className="touch-stick-guide"><span className="touch-ring" /><small>DRAG TO MOVE</small></span><span className="touch-stick-guide"><span className="touch-ring"><Crosshair size={24} /></span><small>DRAG TO AIM + FIRE</small></span></div>

          {hud.phase === "finished" ? (
            <div className="match-overlay">
              <div className="overlay-card result-card">
                <div className="overlay-topline"><span className="live-dot" /> MATCH COMPLETE <span>FIRST TO FIVE</span></div>
                <div className="result-icon">{hud.winner === "alpha" ? <Zap size={34} /> : <Shield size={34} />}</div>
                <div className="section-kicker">// THE FINAL SCORE</div>
                <h2>{hud.winner === "alpha" ? <>VICTORY<span> IS YOURS.</span></> : <>NOT THIS<span> TIME.</span></>}</h2>
                <p>{hud.winner === "alpha" ? "Clean shooting. The training bot never stood a chance." : "The bot got the better of you. Read the cover, then run it back."}</p>
                <div className="result-score"><span>{name}<strong>{hud.kills}</strong></span><b>—</b><span><strong>{hud.opponentKills}</strong>{hud.opponentName}</span></div>
                <button type="button" className="primary-button overlay-button" onClick={rematch}>PLAY AGAIN<Trophy size={18} /></button>
                <span className="result-note">{lastScore ? "RESULT SAVED TO THE LEADERBOARD" : "SAVING RESULT..."}</span>
              </div>
            </div>
          ) : null}
        </div>

        <div className="hud-layout">
          <div className="hud-panel health-panel"><div className="hud-label"><span><Heart size={15} /> HEALTH STATUS</span><span>{hud.hp > 0 && hud.hp < 30 ? "CRITICAL" : "OPERATIONAL"}</span></div><div className="health-value"><strong>{Math.round(hud.hp)}</strong><span>/ 100 HP</span></div><div className="health-track"><span style={{ width: `${hud.hp}%` }} className={hud.hp < 30 ? "low-health" : ""} /></div></div>
          <div className={`hud-panel ammo-panel${hud.ammo <= Math.max(1, Math.ceil(weapon.mag * 0.25)) ? " low-ammo" : ""}`}><div className="hud-label"><span><Crosshair size={15} /> EQUIPPED WEAPON</span><span>{hud.reloadProgress > 0 ? "RELOADING" : "READY TO FIRE"}</span></div><div className="ammo-content"><div><strong>{weapon.name}</strong><span>{weaponLabel}</span></div><div className="ammo-value"><strong>{hud.ammo}</strong><span>/ {weapon.mag}</span></div></div><div className="ammo-track" style={{ "--segments": String(weapon.mag) } as CSSProperties}><span style={{ width: `${(hud.ammo / weapon.mag) * 100}%` }} /></div>{hud.reloadProgress > 0 ? <div className="reload-track"><span style={{ width: `${hud.reloadProgress}%` }} /></div> : null}</div>
          <div className="hud-panel tactical-panel"><div className="hud-label"><span><Shield size={15} /> TACTICAL STATUS</span><span>{hud.fps} FPS</span></div><div className="tactical-line"><span><Zap size={17} /> DASH</span><strong className={dashReady ? "status-good" : "status-wait"}>{dashReady ? "READY" : `${hud.dashIn.toFixed(1)}S`}</strong></div><div className="tactical-line"><span><ShieldCheck size={17} /> POSITION</span><strong className={hud.inCover ? "status-good" : "status-wait"}>{hud.inCover ? "IN COVER" : "EXPOSED"}</strong></div></div>
        </div>

        <div className="loadout-section"><div className="loadout-title"><span>// SELECT YOUR LOADOUT</span><span>SWITCH GUNS ANYTIME <ArrowRight size={14} /></span></div><div className="loadout-grid">{(["pistol", "smg", "shotgun"] as WeaponKey[]).map((key, index) => <button type="button" key={key} className={`weapon-option ${hud.weapon === key ? "active" : ""}`} onClick={() => chooseWeapon(key)}><span className="weapon-option-number">0{index + 1}</span><span className="weapon-symbol">{key === "pistol" ? <Target size={23} /> : key === "smg" ? <Crosshair size={23} /> : <Maximize2 size={23} />}</span><span className="weapon-option-name"><strong>{WEAPONS[key].name}</strong><small>{key === "pistol" ? "BALANCED / RELIABLE" : key === "smg" ? "FAST / AGGRESSIVE" : "HEAVY / CLOSE RANGE"}</small></span><kbd>{index + 1}</kbd></button>)}</div></div>

        <div className="game-bottom"><div><span className="bottom-control-label">CONTROLS</span><span><kbd>W</kbd><kbd>A</kbd><kbd>S</kbd><kbd>D</kbd> MOVE</span><span><kbd>CLICK</kbd> FIRE</span><span><kbd>SHIFT</kbd> DASH</span><span><kbd>R</kbd> RELOAD</span><span><kbd>WHEEL</kbd> GUNS</span><span><kbd>F</kbd> FULLSCREEN</span></div><div className="identity-field"><span>YOUR CALLSIGN</span><input aria-label="Edit your callsign" maxLength={16} value={nameDraft} onChange={(event) => setNameDraft(event.target.value.toUpperCase())} onBlur={() => saveName(nameDraft)} onKeyDown={(event) => { if (event.key === "Enter") event.currentTarget.blur(); }} /></div></div>
        <div className="mobile-actions"><button type="button" onPointerDown={() => { controlsRef.current.dashQueued = true; }}><Zap size={18} /> DASH</button><button type="button" onPointerDown={() => { controlsRef.current.reloadQueued = true; }}><RotateCcw size={18} /> RELOAD</button><button type="button" onClick={() => chooseWeapon(hud.weapon === "pistol" ? "smg" : hud.weapon === "smg" ? "shotgun" : "pistol")}><Play size={18} /> SWAP GUN</button></div>
        <div className="game-footer"><span><Gamepad2 size={15} /> COVERFIRE SOLO PRACTICE</span><span>GOOD COVER. BETTER AIM.</span>{embed ? <span>ARCADE MODE</span> : <Link href="/">EXIT MATCH <ArrowRight size={14} /></Link>}</div>
      </main>
    </div>
  );
}
