"use client";

import { useCallback, useRef } from "react";
import { ARENA_HEIGHT, ARENA_WIDTH } from "@/lib/game";

export type StickMove = { startX: number; startY: number; mx: number; my: number } | null;
export type StickAim = { startX: number; startY: number } | null;

function place(
  frame: HTMLElement | null,
  canvas: HTMLCanvasElement | null,
  stick: HTMLElement | null,
  knob: HTMLElement | null,
  startX: number,
  startY: number,
  knobDX: number,
  knobDY: number,
) {
  if (!frame || !canvas || !stick) return;
  const fr = frame.getBoundingClientRect();
  const cr = canvas.getBoundingClientRect();
  const baseX = (startX / ARENA_WIDTH) * cr.width + (cr.left - fr.left);
  const baseY = (startY / ARENA_HEIGHT) * cr.height + (cr.top - fr.top);
  stick.classList.add("on");
  stick.style.left = `${baseX}px`;
  stick.style.top = `${baseY}px`;
  if (knob) {
    const len = Math.hypot(knobDX, knobDY);
    const reach = 34;
    const scale = len > 0 ? Math.min(len, 1) * reach : 0;
    const nx = len > 0 ? (knobDX / len) * scale : 0;
    const ny = len > 0 ? (knobDY / len) * scale : 0;
    knob.style.transform = `translate(${nx}px, ${ny}px)`;
  }
}

function hide(stick: HTMLElement | null) {
  stick?.classList.remove("on");
}

/** Floating dual-stick visuals driven directly from the touch control state. */
export function useTouchSticks() {
  const frameRef = useRef<HTMLDivElement>(null);
  const moveRef = useRef<HTMLDivElement>(null);
  const moveKnobRef = useRef<HTMLSpanElement>(null);
  const aimRef = useRef<HTMLDivElement>(null);
  const aimKnobRef = useRef<HTMLSpanElement>(null);

  const paint = useCallback(
    (
      canvas: HTMLCanvasElement | null,
      move: StickMove,
      aim: StickAim,
      aimNow?: { x: number; y: number } | null,
    ) => {
      const frame = frameRef.current;
      if (move) {
        place(frame, canvas, moveRef.current, moveKnobRef.current, move.startX, move.startY, move.mx, move.my);
      } else {
        hide(moveRef.current);
      }
      if (aim) {
        const dx = aimNow ? (aimNow.x - aim.startX) / 88 : 0;
        const dy = aimNow ? (aimNow.y - aim.startY) / 88 : 0;
        place(frame, canvas, aimRef.current, aimKnobRef.current, aim.startX, aim.startY, dx, dy);
      } else {
        hide(aimRef.current);
      }
    },
    [],
  );

  const hideMove = useCallback(() => hide(moveRef.current), []);
  const hideAim = useCallback(() => hide(aimRef.current), []);
  const hideAll = useCallback(() => {
    hide(moveRef.current);
    hide(aimRef.current);
  }, []);

  const sticks = (
    <>
      <div className="touch-stick" ref={moveRef} aria-hidden="true"><span className="knob" ref={moveKnobRef} /></div>
      <div className="touch-stick aim" ref={aimRef} aria-hidden="true"><span className="knob" ref={aimKnobRef} /></div>
    </>
  );

  return { frameRef, paint, hideMove, hideAim, hideAll, sticks };
}
