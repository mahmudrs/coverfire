import { boolean, integer, jsonb, pgTable, serial, timestamp, uuid, varchar } from "drizzle-orm/pg-core";
import type { RoomState } from "@/lib/game";
import type { ProgressSave } from "@/lib/progress";

export const matchResults = pgTable("match_results", {
  id: serial("id").primaryKey(),
  callsign: varchar("callsign", { length: 16 }).notNull(),
  kills: integer("kills").notNull().default(0),
  deaths: integer("deaths").notNull().default(0),
  won: boolean("won").notNull().default(false),
  durationMs: integer("duration_ms").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const onlineRooms = pgTable("online_rooms", {
  id: varchar("id", { length: 8 }).primaryKey(),
  state: jsonb("state").$type<RoomState>().notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export const playerAccounts = pgTable("player_accounts", {
  id: uuid("id").primaryKey().defaultRandom(),
  platform: varchar("platform", { length: 24 }).notNull().default("local"),
  platformUserId: varchar("platform_user_id", { length: 128 }).notNull().unique(),
  username: varchar("username", { length: 32 }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  lastSeenAt: timestamp("last_seen_at", { withTimezone: true }).defaultNow().notNull(),
});

export const playerSaves = pgTable("player_saves", {
  accountId: uuid("account_id").primaryKey().references(() => playerAccounts.id, { onDelete: "cascade" }),
  data: jsonb("data").$type<ProgressSave>().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});
