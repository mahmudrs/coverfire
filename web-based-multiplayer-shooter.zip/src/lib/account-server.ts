import { createHmac, timingSafeEqual } from "node:crypto";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { playerAccounts, playerSaves } from "@/db/schema";
import { mergeProgress, normalizeProgress, type ProgressSave } from "@/lib/progress";

export type AccountIdentity = {
  platform: "crazygames" | "local";
  platformUserId: string;
  username: string;
  verified: boolean;
};

export type AccountSummary = {
  id: string;
  platform: string;
  platformUserId: string;
  username: string;
  verified: boolean;
};

function base64UrlDecode(value: string): Buffer {
  const normalized = value.replace(/-/g, "+").replace(/_/g, "/");
  const padded = normalized + "=".repeat((4 - (normalized.length % 4)) % 4);
  return Buffer.from(padded, "base64");
}

/** Decodes and (when CRAZYGAMES_SECRET is set) verifies the CrazyGames user JWT. */
export function decodeUserToken(token: string): { userId: string; username: string; verified: boolean } | null {
  const parts = token.split(".");
  if (parts.length !== 3) return null;
  let payload: Record<string, unknown>;
  try {
    payload = JSON.parse(base64UrlDecode(parts[1]).toString("utf8")) as Record<string, unknown>;
  } catch {
    return null;
  }

  const secret = process.env.CRAZYGAMES_SECRET;
  let verified = false;
  if (secret) {
    const expected = createHmac("sha256", secret).update(`${parts[0]}.${parts[1]}`).digest();
    let signature: Buffer;
    try {
      signature = base64UrlDecode(parts[2]);
    } catch {
      return null;
    }
    verified = signature.length === expected.length && timingSafeEqual(signature, expected);
    if (!verified) return null;
  }

  const exp = typeof payload.exp === "number" ? payload.exp : null;
  if (exp !== null && exp * 1000 < Date.now()) return null;

  const userId = payload.userId ?? payload.sub ?? payload.id;
  if (typeof userId !== "string" || userId.length < 3) return null;
  const username = typeof payload.username === "string" ? payload.username : "PLAYER";

  return { userId: userId.slice(0, 128), username, verified };
}

export function resolveIdentity(input: { token?: unknown; localId?: unknown; username?: unknown }): AccountIdentity | null {
  const token = typeof input.token === "string" ? input.token : "";
  if (token) {
    const decoded = decodeUserToken(token);
    if (decoded) {
      return {
        platform: "crazygames",
        platformUserId: `cg:${decoded.userId}`,
        username: String(decoded.username).slice(0, 32),
        verified: decoded.verified,
      };
    }
    return null;
  }

  const localId = typeof input.localId === "string" ? input.localId.trim() : "";
  if (/^[a-zA-Z0-9-]{8,64}$/.test(localId)) {
    const fallbackName = typeof input.username === "string" ? input.username : "PLAYER";
    return { platform: "local", platformUserId: `local:${localId}`, username: fallbackName.slice(0, 32), verified: true };
  }

  return null;
}

async function upsertAccount(identity: AccountIdentity): Promise<AccountSummary> {
  const [existing] = await db.select().from(playerAccounts).where(eq(playerAccounts.platformUserId, identity.platformUserId)).limit(1);
  if (existing) {
    if (existing.username !== identity.username) {
      await db.update(playerAccounts).set({ username: identity.username, lastSeenAt: new Date() }).where(eq(playerAccounts.id, existing.id));
    } else {
      await db.update(playerAccounts).set({ lastSeenAt: new Date() }).where(eq(playerAccounts.id, existing.id));
    }
    return { id: existing.id, platform: existing.platform, platformUserId: existing.platformUserId, username: identity.username, verified: identity.verified };
  }

  const [created] = await db
    .insert(playerAccounts)
    .values({ platform: identity.platform, platformUserId: identity.platformUserId, username: identity.username })
    .onConflictDoUpdate({ target: playerAccounts.platformUserId, set: { username: identity.username, lastSeenAt: new Date() } })
    .returning();

  return { id: created.id, platform: created.platform, platformUserId: created.platformUserId, username: created.username ?? identity.username, verified: identity.verified };
}

export async function loadSave(accountId: string): Promise<ProgressSave | null> {
  const [row] = await db.select().from(playerSaves).where(eq(playerSaves.accountId, accountId)).limit(1);
  return row ? normalizeProgress(row.data) : null;
}

export async function storeSave(accountId: string, progress: ProgressSave): Promise<ProgressSave> {
  const normalized = normalizeProgress(progress);
  await db
    .insert(playerSaves)
    .values({ accountId, data: normalized, updatedAt: new Date() })
    .onConflictDoUpdate({ target: playerSaves.accountId, set: { data: normalized, updatedAt: new Date() } });
  return normalized;
}

/** Links the incoming identity to a backend account and merges any local/CrazyGames progress into it. */
export async function syncAccount(
  identity: AccountIdentity,
  clientProgress: ProgressSave | null,
): Promise<{ account: AccountSummary; save: ProgressSave; merged: boolean }> {
  const account = await upsertAccount(identity);
  const stored = await loadSave(account.id);
  const incoming = clientProgress ? normalizeProgress(clientProgress, identity.username) : null;

  if (!stored && !incoming) {
    const fresh = normalizeProgress({ ...defaultFallback(identity.username), updatedAt: Date.now() }, identity.username);
    return { account, save: await storeSave(account.id, fresh), merged: false };
  }
  if (!stored && incoming) return { account, save: await storeSave(account.id, incoming), merged: false };
  if (stored && !incoming) return { account, save: stored, merged: false };

  const mergedSave = mergeProgress(stored!, incoming!);
  const changed = mergedSave.kills !== stored!.kills || mergedSave.wins !== stored!.wins || mergedSave.matches !== stored!.matches || mergedSave.callsign !== stored!.callsign;
  return { account, save: changed ? await storeSave(account.id, mergedSave) : stored!, merged: changed };
}

function defaultFallback(username: string) {
  return {
    version: 1 as const,
    callsign: username.slice(0, 16).toUpperCase(),
    matches: 0,
    wins: 0,
    kills: 0,
    deaths: 0,
    bestKills: 0,
    bestStreak: 0,
    selectedWeapon: "pistol" as const,
    totalPlayMs: 0,
    updatedAt: 0,
  };
}
