/** Browser API helpers with graceful fallbacks for locked-down webviews and old engines. */

type StorageLike = {
  get: (key: string) => string;
  set: (key: string, value: string) => void;
  del: (key: string) => void;
};

function makeStore(kind: "localStorage" | "sessionStorage"): StorageLike {
  const backend = (): Storage | null => {
    try {
      return window[kind];
    } catch {
      return null;
    }
  };
  return {
    get: (key: string) => {
      try {
        return backend()?.getItem(key) ?? "";
      } catch {
        return "";
      }
    },
    set: (key: string, value: string) => {
      try {
        backend()?.setItem(key, value);
      } catch {
        /* Storage can be blocked (private mode, sandbox) — play on without it. */
      }
    },
    del: (key: string) => {
      try {
        backend()?.removeItem(key);
      } catch {
        /* ignore */
      }
    },
  };
}

export const localStore = typeof window === "undefined" ? null : makeStore("localStorage");
export const sessionStore = typeof window === "undefined" ? null : makeStore("sessionStorage");

/** UUID without requiring crypto.randomUUID (unavailable in insecure contexts). */
export function randomId(): string {
  try {
    if (typeof window !== "undefined" && typeof window.crypto?.randomUUID === "function") {
      return window.crypto.randomUUID();
    }
  } catch {
    /* fall through to Math.random */
  }
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (char) => {
    const bits = Math.floor(Math.random() * 16);
    return (char === "x" ? bits : (bits & 0x3) | 0x8).toString(16);
  });
}

export function createAudioContext(): AudioContext | null {
  try {
    const Ctor =
      window.AudioContext ??
      (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Ctor) return null;
    return new Ctor();
  } catch {
    return null;
  }
}
