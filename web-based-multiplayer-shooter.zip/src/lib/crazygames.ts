"use client";

import { useEffect, useRef, useState } from "react";

export type SdkPhase = "waiting" | "playing" | "finished";

type CgSdk = {
  init: () => Promise<void>;
  user?: {
    isUserAccountAvailable?: boolean;
    getUser?: () => Promise<{ username?: string } | null | undefined>;
    getUserToken?: () => Promise<string | null | undefined>;
  };
  data?: {
    getItem?: (key: string) => string | null;
    setItem?: (key: string, value: string) => void;
    removeItem?: (key: string) => void;
  };
  game: {
    loadingStart?: () => void;
    loadingStop?: () => void;
    gameplayStart?: () => void;
    gameplayStop?: () => void;
    happytime?: () => void;
    requestAd?: (type: string, callbacks?: { adStarted?: () => void; adFinished?: () => void; adError?: () => void }) => void;
    settings?: { muteAudio?: boolean; disableChat?: boolean };
    addSettingsChangeListener?: (listener: (settings: GameSettings) => void) => void;
    removeSettingsChangeListener?: (listener: (settings: GameSettings) => void) => void;
    reportGameCompletedPercentage?: (percentage: number) => void;
    setGameContext?: (context: Record<string, string>) => void;
    clearGameContext?: () => void;
    isInstantMultiplayer?: boolean;
    inviteParams?: Record<string, string> | null;
    getInviteParam?: (key: string) => string | null;
    updateRoom?: (room: { roomId: string; isJoinable?: boolean; inviteParams?: Record<string, string> }) => void;
    leftRoom?: () => void;
    inviteLink?: (params: Record<string, string>) => string;
    addJoinRoomListener?: (listener: (params: Record<string, string>) => void) => void;
    removeJoinRoomListener?: (listener: (params: Record<string, string>) => void) => void;
  };
};

export type GameSettings = { muteAudio?: boolean; disableChat?: boolean };

type SdkWindow = Window & { CrazyGames?: { SDK?: CgSdk } };

function sdkWindow() {
  return window as unknown as SdkWindow;
}

let loadPromise: Promise<CgSdk | null> | null = null;
let cached: CgSdk | null = null;
let adInProgress = false;

function hostWantsSdk() {
  if (typeof window === "undefined") return false;
  const host = window.location.hostname;
  if (host.includes("crazygames")) return true;
  if (new URLSearchParams(window.location.search).has("crazygames")) return true;
  return window.self !== window.top;
}

/** Loads and initialises the CrazyGames SDK v3 when the game runs on their platform or inside an iframe. */
export async function loadSdk(): Promise<CgSdk | null> {
  if (cached) return cached;
  if (loadPromise) return loadPromise;
  if (!hostWantsSdk()) return null;

  loadPromise = new Promise((resolve) => {
    let settled = false;
    const finish = async (candidate?: CgSdk) => {
      if (settled) return;
      settled = true;
      if (!candidate) return resolve(null);
      try {
        await candidate.init();
        cached = candidate;
        resolve(candidate);
      } catch {
        resolve(null);
      }
    };

    if (sdkWindow().CrazyGames?.SDK) {
      void finish(sdkWindow().CrazyGames?.SDK);
      return;
    }

    const script = document.createElement("script");
    script.src = "https://sdk.crazygames.com/crazygames-sdk-v3.js";
    script.async = true;
    script.onload = () => void finish(sdkWindow().CrazyGames?.SDK);
    script.onerror = () => resolve(null);
    document.head.appendChild(script);
    window.setTimeout(() => void finish(sdkWindow().CrazyGames?.SDK), 6000);
  });

  return loadPromise;
}

export async function getSdkUserName(): Promise<string | null> {
  const sdk = await loadSdk();
  if (!sdk?.user?.isUserAccountAvailable || !sdk.user.getUser) return null;
  try {
    const user = await sdk.user.getUser();
    return user?.username ? String(user.username).slice(0, 16).toUpperCase() : null;
  } catch {
    return null;
  }
}

/** Requests a midgame ad. Resolves when the ad is finished, skipped, unavailable, or errored. */
export async function requestMidgameAd(): Promise<void> {
  const sdk = await loadSdk();
  const request = sdk?.game?.requestAd;
  if (!sdk || !request || adInProgress) return;
  adInProgress = true;
  await new Promise<void>((resolve) => {
    let settled = false;
    const done = () => {
      if (settled) return;
      settled = true;
      adInProgress = false;
      resolve();
    };
    try {
      request("midgame", { adStarted: () => {}, adFinished: done, adError: done });
    } catch {
      done();
      return;
    }
    window.setTimeout(done, 45_000);
  });
}

export function isAdInProgress() {
  return adInProgress;
}

/** CrazyGames room identifiers use the same six-character code as our online rooms. */
export function sdkRoomCode(value: unknown): string | null {
  if (typeof value !== "string") return null;
  const code = value.trim().toUpperCase();
  return /^[A-HJ-NP-Z2-9]{6}$/.test(code) ? code : null;
}

/** True when CrazyGames wants this launch to go straight into a joinable multiplayer lobby. */
export async function isInstantMultiplayer(): Promise<boolean> {
  const sdk = await loadSdk();
  return sdk?.game.isInstantMultiplayer === true;
}

function roomFromParams(params: Record<string, string> | null | undefined): string | null {
  if (!params) return null;
  return sdkRoomCode(params.roomId) ?? sdkRoomCode(params.roomCode) ?? sdkRoomCode(params.room);
}

/** Reads the room supplied by a CrazyGames party/invite launch. */
export async function getSdkInviteRoom(): Promise<string | null> {
  const sdk = await loadSdk();
  if (!sdk) return null;
  const fromParams = roomFromParams(sdk.game.inviteParams);
  if (fromParams) return fromParams;
  try {
    return sdkRoomCode(sdk.game.getInviteParam?.("roomId")) ?? sdkRoomCode(sdk.game.getInviteParam?.("roomCode"));
  } catch {
    return null;
  }
}

/** Routes a friend joining from the CrazyGames friends drawer or a party notification. */
export async function subscribeSdkRoomJoin(listener: (roomId: string) => void): Promise<() => void> {
  const sdk = await loadSdk();
  if (!sdk?.game.addJoinRoomListener) return () => {};
  const handler = (params: Record<string, string>) => {
    const roomId = roomFromParams(params);
    if (roomId) listener(roomId);
  };
  try {
    sdk.game.addJoinRoomListener(handler);
  } catch {
    return () => {};
  }
  return () => {
    try {
      sdk.game.removeJoinRoomListener?.(handler);
    } catch {
      /* Best-effort cleanup. */
    }
  };
}

/** Publishes this lobby to the platform and closes it to new joins once the duel starts. */
export async function updateSdkRoom(roomId: string, isJoinable: boolean): Promise<void> {
  const sdk = await loadSdk();
  try {
    sdk?.game.updateRoom?.({ roomId, isJoinable, inviteParams: { roomId } });
  } catch {
    /* Room metadata is optional off-platform. */
  }
}

export async function leaveSdkRoom(): Promise<void> {
  const sdk = await loadSdk();
  try {
    sdk?.game.leftRoom?.();
  } catch {
    /* Best-effort cleanup. */
  }
}

/** Returns the platform-native party link, or null when the web fallback should be used. */
export async function getSdkInviteLink(roomId: string): Promise<string | null> {
  const sdk = await loadSdk();
  try {
    const link = sdk?.game.inviteLink?.({ roomId });
    return typeof link === "string" && link.length > 0 ? link : null;
  } catch {
    return null;
  }
}

/** Cloud-save storage provided by the CrazyGames Data module (falls back to localStorage for guests). */
export async function sdkGetData(key: string): Promise<string | null> {
  const sdk = await loadSdk();
  try {
    return sdk?.data?.getItem?.(key) ?? null;
  } catch {
    return null;
  }
}

export async function sdkSetData(key: string, value: string): Promise<boolean> {
  const sdk = await loadSdk();
  try {
    sdk?.data?.setItem?.(key, value);
    return Boolean(sdk?.data?.setItem);
  } catch {
    return false;
  }
}

/** JWT that identifies the signed-in CrazyGames user; verified by our backend. */
export async function getSdkUserToken(): Promise<string | null> {
  const sdk = await loadSdk();
  if (!sdk?.user?.getUserToken) return null;
  try {
    const token = await sdk.user.getUserToken();
    return typeof token === "string" && token.length > 20 ? token : null;
  } catch {
    return null;
  }
}

export async function reportProgress(percentage: number) {
  const sdk = await loadSdk();
  try {
    sdk?.game.reportGameCompletedPercentage?.(Math.max(0, Math.min(100, Math.round(percentage))));
  } catch {
    /* Best-effort. */
  }
}

/** Local QA switch, read at call time so it also works after client-side navigation. */
function wantsLocalMute(): boolean {
  if (typeof window === "undefined") return false;
  return new URLSearchParams(window.location.search).get("muteAudio") === "true";
}

let platformMuted = false;

export function isPlatformMuted() {
  return platformMuted || wantsLocalMute();
}

/** Subscribes to the CrazyGames audio setting. The platform mute always wins over the in-game toggle. */
export async function subscribeSdkSettings(listener: (settings: GameSettings) => void): Promise<() => void> {
  const sdk = await loadSdk();
  const apply = (settings: GameSettings | undefined) => {
    platformMuted = Boolean(settings?.muteAudio) || wantsLocalMute();
    listener({ ...settings, muteAudio: platformMuted });
  };
  if (!sdk) {
    apply(undefined);
    return () => {};
  }
  apply(sdk.game.settings);
  const handler = (settings: GameSettings) => apply(settings);
  try {
    sdk.game.addSettingsChangeListener?.(handler);
  } catch {
    /* Listener is optional. */
  }
  return () => {
    try {
      sdk.game.removeSettingsChangeListener?.(handler);
    } catch {
      /* Best-effort. */
    }
  };
}

/** Keeps the CrazyGames loading and gameplay lifecycle in sync with the local match phase. */
export function useGameSdk(phase: SdkPhase, won: boolean) {
  const previous = useRef<SdkPhase | null>(null);
  const wonRef = useRef(false);
  const phaseRef = useRef<SdkPhase>(phase);
  wonRef.current = won;
  phaseRef.current = phase;

  useEffect(() => {
    let active = true;
    (async () => {
      const sdk = await loadSdk();
      if (!sdk || !active) return;
      try {
        sdk.game.loadingStart?.();
        window.setTimeout(() => sdk.game.loadingStop?.(), 1200);
        if (phaseRef.current === "playing") sdk.game.gameplayStart?.();
      } catch {
        /* SDK lifecycle calls are best-effort. */
      }
    })();
    return () => { active = false; };
  }, []);

  useEffect(() => {
    let active = true;
    (async () => {
      const sdk = await loadSdk();
      if (!sdk || !active) return;
      try {
        if (phase === "playing") {
          if (previous.current !== "playing") sdk.game.gameplayStart?.();
        } else if (previous.current === "playing") {
          sdk.game.gameplayStop?.();
          if (phase === "finished" && wonRef.current) sdk.game.happytime?.();
        }
      } catch {
        /* Best-effort. */
      }
      previous.current = phase;
    })();
    return () => { active = false; };
  }, [phase, won]);
}


/** React binding for the CrazyGames mute setting so the in-game audio toggle can enforce it. */
export function useSdkMute(): { muted: boolean; platform: boolean } {
  const [settings, setSettings] = useState<GameSettings>({ muteAudio: false });
  const [available, setAvailable] = useState(false);

  useEffect(() => {
    let active = true;
    let unsubscribe: (() => void) | null = null;
    (async () => {
      const sdk = await loadSdk();
      if (!active) return;
      setAvailable(Boolean(sdk));
      setSettings({ muteAudio: Boolean(sdk?.game.settings?.muteAudio) || wantsLocalMute() });
      unsubscribe = await subscribeSdkSettings((next) => {
        if (active) setSettings(next);
      });
    })();
    return () => { active = false; unsubscribe?.(); };
  }, []);

  return { muted: Boolean(settings.muteAudio), platform: available };
}
