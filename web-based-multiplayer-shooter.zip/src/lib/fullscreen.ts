/** Shared fullscreen toggle used by the solo + online arenas (keyboard: F). */

export function isFullscreenActive(): boolean {
  if (typeof document === "undefined") return false;
  return document.fullscreenElement !== null;
}

/**
 * Toggles fullscreen on the given element (defaults to the page root).
 * Resolves with the new fullscreen state. Never throws — sandboxed iframes
 * without the fullscreen permission simply stay windowed.
 */
export async function toggleFullscreen(target?: Element | null): Promise<boolean> {
  if (typeof document === "undefined") return false;
  try {
    if (document.fullscreenElement) {
      await document.exitFullscreen();
      return false;
    }
    const node = target ?? document.documentElement;
    const request = node.requestFullscreen?.bind(node);
    if (!request) return false;
    await request();
    return true;
  } catch {
    return isFullscreenActive();
  }
}
