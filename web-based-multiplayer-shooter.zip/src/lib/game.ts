export const ARENA_WIDTH = 1200;
export const ARENA_HEIGHT = 720;
export const PLAYER_RADIUS = 18;
export const WIN_SCORE = 5;

export type PlayerSide = "alpha" | "bravo" | "charlie" | "delta";
export type WeaponKey = "pistol" | "smg" | "shotgun";
export type GamePhase = "waiting" | "playing" | "finished";
export type MatchMode = "duel" | "practice" | "squad";

export const SIDES: PlayerSide[] = ["alpha", "bravo", "charlie", "delta"];
export const SIDE_LABELS: Record<PlayerSide, string> = { alpha: "A", bravo: "B", charlie: "C", delta: "D" };
export const TEAM_WIN_SCORE = 8;

export function teamForSide(id: PlayerSide): 0 | 1 {
  return id === "alpha" || id === "charlie" ? 0 : 1;
}

export const WEAPONS: Record<WeaponKey, { name: string; mag: number; damage: number; interval: number; reload: number; speed: number; life: number; spread: number; pellets: number }> = {
  pistol: { name: "SIDEARM", mag: 12, damage: 24, interval: 260, reload: 1050, speed: 1050, life: 950, spread: 0.025, pellets: 1 },
  smg: { name: "VECT-9", mag: 30, damage: 11, interval: 95, reload: 1500, speed: 1000, life: 850, spread: 0.085, pellets: 1 },
  shotgun: { name: "BREACHER", mag: 6, damage: 12, interval: 650, reload: 1750, speed: 860, life: 490, spread: 0.31, pellets: 7 },
};

export type CoverDefinition = { id: string; x: number; y: number; w: number; h: number; kind: "wall" | "crate"; maxHp: number };

export const COVER: CoverDefinition[] = [
  { id: "wall-left", x: 365, y: 296, w: 42, h: 128, kind: "wall", maxHp: 9999 },
  { id: "wall-right", x: 793, y: 296, w: 42, h: 128, kind: "wall", maxHp: 9999 },
  { id: "wall-north", x: 527, y: 140, w: 146, h: 40, kind: "wall", maxHp: 9999 },
  { id: "wall-south", x: 527, y: 540, w: 146, h: 40, kind: "wall", maxHp: 9999 },
  { id: "wall-center", x: 551, y: 313, w: 98, h: 94, kind: "wall", maxHp: 9999 },
  { id: "crate-l-top", x: 191, y: 190, w: 116, h: 49, kind: "crate", maxHp: 110 },
  { id: "crate-l-bottom", x: 191, y: 481, w: 116, h: 49, kind: "crate", maxHp: 110 },
  { id: "crate-r-top", x: 893, y: 190, w: 116, h: 49, kind: "crate", maxHp: 110 },
  { id: "crate-r-bottom", x: 893, y: 481, w: 116, h: 49, kind: "crate", maxHp: 110 },
  { id: "crate-mid-nw", x: 458, y: 249, w: 73, h: 44, kind: "crate", maxHp: 85 },
  { id: "crate-mid-ne", x: 669, y: 249, w: 73, h: 44, kind: "crate", maxHp: 85 },
  { id: "crate-mid-sw", x: 458, y: 427, w: 73, h: 44, kind: "crate", maxHp: 85 },
  { id: "crate-mid-se", x: 669, y: 427, w: 73, h: 44, kind: "crate", maxHp: 85 },
];

export type MapDef = {
  id: string;
  name: string;
  cover: CoverDefinition[];
  spawns: Record<PlayerSide, { x: number; y: number }>;
  pickupSpots: { x: number; y: number }[];
};

export const MAPS: MapDef[] = [
  {
    id: "foundry",
    name: "THE FOUNDRY",
    cover: COVER,
    spawns: {
      alpha: { x: 108, y: 360 },
      bravo: { x: ARENA_WIDTH - 108, y: 360 },
      charlie: { x: 108, y: 200 },
      delta: { x: ARENA_WIDTH - 108, y: 520 },
    },
    pickupSpots: [
      { x: 600, y: 220 },
      { x: 600, y: 500 },
      { x: 250, y: 360 },
      { x: 950, y: 360 },
    ],
  },
  {
    id: "depot",
    name: "THE DEPOT",
    pickupSpots: [
      { x: 600, y: 230 },
      { x: 600, y: 490 },
      { x: 400, y: 360 },
      { x: 800, y: 360 },
    ],
    cover: [
      { id: "wall-v", x: 584, y: 270, w: 32, h: 180, kind: "wall", maxHp: 9999 },
      { id: "wall-h", x: 500, y: 344, w: 200, h: 32, kind: "wall", maxHp: 9999 },
      { id: "wall-top", x: 540, y: 110, w: 120, h: 36, kind: "wall", maxHp: 9999 },
      { id: "wall-bottom", x: 540, y: 574, w: 120, h: 36, kind: "wall", maxHp: 9999 },
      { id: "wall-west", x: 180, y: 320, w: 36, h: 80, kind: "wall", maxHp: 9999 },
      { id: "wall-east", x: 984, y: 320, w: 36, h: 80, kind: "wall", maxHp: 9999 },
      { id: "crate-mid-nw", x: 300, y: 180, w: 90, h: 44, kind: "crate", maxHp: 90 },
      { id: "crate-mid-ne", x: 810, y: 180, w: 90, h: 44, kind: "crate", maxHp: 90 },
      { id: "crate-mid-sw", x: 300, y: 496, w: 90, h: 44, kind: "crate", maxHp: 90 },
      { id: "crate-mid-se", x: 810, y: 496, w: 90, h: 44, kind: "crate", maxHp: 90 },
      { id: "crate-corner-nw", x: 120, y: 120, w: 100, h: 44, kind: "crate", maxHp: 110 },
      { id: "crate-corner-ne", x: 980, y: 120, w: 100, h: 44, kind: "crate", maxHp: 110 },
      { id: "crate-corner-sw", x: 120, y: 556, w: 100, h: 44, kind: "crate", maxHp: 110 },
      { id: "crate-corner-se", x: 980, y: 556, w: 100, h: 44, kind: "crate", maxHp: 110 },
    ],
    spawns: {
      alpha: { x: 108, y: 300 },
      bravo: { x: ARENA_WIDTH - 108, y: 420 },
      charlie: { x: 108, y: 420 },
      delta: { x: ARENA_WIDTH - 108, y: 300 },
    },
  },
  {
    id: "crossing",
    name: "THE CROSSING",
    pickupSpots: [
      { x: 600, y: 360 },
      { x: 320, y: 140 },
      { x: 880, y: 140 },
      { x: 600, y: 540 },
    ],
    cover: [
      { id: "wall-ring-n", x: 560, y: 240, w: 80, h: 32, kind: "wall", maxHp: 9999 },
      { id: "wall-ring-s", x: 560, y: 448, w: 80, h: 32, kind: "wall", maxHp: 9999 },
      { id: "wall-ring-w", x: 480, y: 304, w: 32, h: 112, kind: "wall", maxHp: 9999 },
      { id: "wall-ring-e", x: 688, y: 304, w: 32, h: 112, kind: "wall", maxHp: 9999 },
      { id: "wall-west", x: 150, y: 300, w: 40, h: 120, kind: "wall", maxHp: 9999 },
      { id: "wall-east", x: 1010, y: 300, w: 40, h: 120, kind: "wall", maxHp: 9999 },
      { id: "crate-nw", x: 250, y: 250, w: 80, h: 44, kind: "crate", maxHp: 90 },
      { id: "crate-ne", x: 870, y: 250, w: 80, h: 44, kind: "crate", maxHp: 90 },
      { id: "crate-sw", x: 250, y: 426, w: 80, h: 44, kind: "crate", maxHp: 90 },
      { id: "crate-se", x: 870, y: 426, w: 80, h: 44, kind: "crate", maxHp: 90 },
      { id: "crate-top", x: 560, y: 120, w: 80, h: 40, kind: "crate", maxHp: 90 },
      { id: "crate-bottom", x: 560, y: 560, w: 80, h: 40, kind: "crate", maxHp: 90 },
    ],
    spawns: {
      alpha: { x: 108, y: 300 },
      bravo: { x: ARENA_WIDTH - 108, y: 420 },
      charlie: { x: 108, y: 420 },
      delta: { x: ARENA_WIDTH - 108, y: 300 },
    },
  },
  {
    id: "pit",
    name: "THE PIT",
    cover: [
      { id: "wall-center", x: 560, y: 320, w: 80, h: 80, kind: "wall", maxHp: 9999 },
      { id: "wall-top", x: 520, y: 120, w: 160, h: 32, kind: "wall", maxHp: 9999 },
      { id: "wall-bottom", x: 520, y: 568, w: 160, h: 32, kind: "wall", maxHp: 9999 },
      { id: "pillar-nw", x: 350, y: 200, w: 44, h: 44, kind: "wall", maxHp: 9999 },
      { id: "pillar-ne", x: 806, y: 200, w: 44, h: 44, kind: "wall", maxHp: 9999 },
      { id: "pillar-sw", x: 350, y: 476, w: 44, h: 44, kind: "wall", maxHp: 9999 },
      { id: "pillar-se", x: 806, y: 476, w: 44, h: 44, kind: "wall", maxHp: 9999 },
      { id: "crate-w-top", x: 180, y: 250, w: 90, h: 44, kind: "crate", maxHp: 90 },
      { id: "crate-w-bottom", x: 180, y: 426, w: 90, h: 44, kind: "crate", maxHp: 90 },
      { id: "crate-e-top", x: 930, y: 250, w: 90, h: 44, kind: "crate", maxHp: 90 },
      { id: "crate-e-bottom", x: 930, y: 426, w: 90, h: 44, kind: "crate", maxHp: 90 },
    ],
    spawns: {
      alpha: { x: 108, y: 300 },
      bravo: { x: ARENA_WIDTH - 108, y: 420 },
      charlie: { x: 108, y: 420 },
      delta: { x: ARENA_WIDTH - 108, y: 300 },
    },
    pickupSpots: [
      { x: 600, y: 180 },
      { x: 600, y: 540 },
      { x: 320, y: 360 },
      { x: 880, y: 360 },
    ],
  },
  {
    id: "docks",
    name: "THE DOCKS",
    cover: [
      { id: "wall-west", x: 180, y: 310, w: 36, h: 100, kind: "wall", maxHp: 9999 },
      { id: "wall-east", x: 984, y: 310, w: 36, h: 100, kind: "wall", maxHp: 9999 },
      { id: "wall-center", x: 570, y: 320, w: 60, h: 80, kind: "wall", maxHp: 9999 },
      { id: "crate-nw", x: 280, y: 180, w: 110, h: 50, kind: "crate", maxHp: 110 },
      { id: "crate-ne", x: 810, y: 180, w: 110, h: 50, kind: "crate", maxHp: 110 },
      { id: "crate-n-mid", x: 545, y: 180, w: 110, h: 50, kind: "crate", maxHp: 90 },
      { id: "crate-sw", x: 280, y: 490, w: 110, h: 50, kind: "crate", maxHp: 110 },
      { id: "crate-se", x: 810, y: 490, w: 110, h: 50, kind: "crate", maxHp: 110 },
      { id: "crate-s-mid", x: 545, y: 490, w: 110, h: 50, kind: "crate", maxHp: 90 },
    ],
    spawns: {
      alpha: { x: 108, y: 300 },
      bravo: { x: ARENA_WIDTH - 108, y: 420 },
      charlie: { x: 108, y: 420 },
      delta: { x: ARENA_WIDTH - 108, y: 300 },
    },
    pickupSpots: [
      { x: 600, y: 120 },
      { x: 600, y: 600 },
      { x: 250, y: 470 },
      { x: 950, y: 250 },
    ],
  },
  {
    id: "reactor",
    name: "THE REACTOR",
    cover: [
      { id: "wall-core", x: 560, y: 310, w: 80, h: 100, kind: "wall", maxHp: 9999 },
      { id: "wall-diag-nw", x: 380, y: 180, w: 120, h: 32, kind: "wall", maxHp: 9999 },
      { id: "wall-diag-ne", x: 700, y: 180, w: 120, h: 32, kind: "wall", maxHp: 9999 },
      { id: "wall-diag-sw", x: 380, y: 508, w: 120, h: 32, kind: "wall", maxHp: 9999 },
      { id: "wall-diag-se", x: 700, y: 508, w: 120, h: 32, kind: "wall", maxHp: 9999 },
      { id: "pillar-nw", x: 200, y: 200, w: 40, h: 40, kind: "wall", maxHp: 9999 },
      { id: "pillar-ne", x: 960, y: 200, w: 40, h: 40, kind: "wall", maxHp: 9999 },
      { id: "pillar-sw", x: 200, y: 480, w: 40, h: 40, kind: "wall", maxHp: 9999 },
      { id: "pillar-se", x: 960, y: 480, w: 40, h: 40, kind: "wall", maxHp: 9999 },
      { id: "crate-sw", x: 420, y: 560, w: 90, h: 44, kind: "crate", maxHp: 90 },
      { id: "crate-se", x: 690, y: 560, w: 90, h: 44, kind: "crate", maxHp: 90 },
      { id: "crate-nw", x: 420, y: 116, w: 90, h: 44, kind: "crate", maxHp: 90 },
      { id: "crate-ne", x: 690, y: 116, w: 90, h: 44, kind: "crate", maxHp: 90 },
    ],
    spawns: {
      alpha: { x: 108, y: 300 },
      bravo: { x: ARENA_WIDTH - 108, y: 420 },
      charlie: { x: 108, y: 420 },
      delta: { x: ARENA_WIDTH - 108, y: 300 },
    },
    pickupSpots: [
      { x: 600, y: 180 },
      { x: 600, y: 540 },
      { x: 300, y: 360 },
      { x: 900, y: 360 },
    ],
  },
  {
    id: "outpost",
    name: "THE OUTPOST",
    cover: [
      { id: "wall-nw", x: 250, y: 150, w: 36, h: 110, kind: "wall", maxHp: 9999 },
      { id: "wall-ne", x: 914, y: 150, w: 36, h: 110, kind: "wall", maxHp: 9999 },
      { id: "wall-sw", x: 250, y: 460, w: 36, h: 110, kind: "wall", maxHp: 9999 },
      { id: "wall-se", x: 914, y: 460, w: 36, h: 110, kind: "wall", maxHp: 9999 },
      { id: "wall-mid-w", x: 150, y: 330, w: 120, h: 32, kind: "wall", maxHp: 9999 },
      { id: "wall-mid-e", x: 930, y: 358, w: 120, h: 32, kind: "wall", maxHp: 9999 },
      { id: "crate-nw", x: 400, y: 140, w: 100, h: 46, kind: "crate", maxHp: 90 },
      { id: "crate-ne", x: 700, y: 140, w: 100, h: 46, kind: "crate", maxHp: 90 },
      { id: "crate-sw", x: 400, y: 534, w: 100, h: 46, kind: "crate", maxHp: 90 },
      { id: "crate-se", x: 700, y: 534, w: 100, h: 46, kind: "crate", maxHp: 90 },
      { id: "crate-mid-w", x: 480, y: 337, w: 90, h: 46, kind: "crate", maxHp: 110 },
      { id: "crate-mid-e", x: 630, y: 337, w: 90, h: 46, kind: "crate", maxHp: 110 },
    ],
    spawns: {
      alpha: { x: 108, y: 300 },
      bravo: { x: ARENA_WIDTH - 108, y: 420 },
      charlie: { x: 108, y: 420 },
      delta: { x: ARENA_WIDTH - 108, y: 300 },
    },
    pickupSpots: [
      { x: 600, y: 220 },
      { x: 600, y: 500 },
      { x: 350, y: 600 },
      { x: 850, y: 120 },
    ],
  },
];

export function getMap(mapId: string): MapDef {
  return MAPS.find((map) => map.id === mapId) ?? MAPS[0];
}

export function mapCover(mapId: string): CoverDefinition[] {
  return getMap(mapId).cover;
}

export function spawnFor(mapId: string, side: PlayerSide): { x: number; y: number } {
  return getMap(mapId).spawns[side];
}

export type PlayerInput = {
  mx: number;
  my: number;
  aim: number;
  shoot: boolean;
  reload: boolean;
  dash: boolean;
};

export type PlayerState = {
  id: PlayerSide;
  team: 0 | 1;
  isBot: boolean;
  token: string;
  name: string;
  x: number;
  y: number;
  aim: number;
  hp: number;
  kills: number;
  deaths: number;
  weapon: WeaponKey;
  ammo: Record<WeaponKey, number>;
  input: PlayerInput;
  lastSeen: number;
  lastInputSeq: number;
  lastShotAt: number;
  reloadEndsAt: number;
  dashEndsAt: number;
  dashReadyAt: number;
  dashX: number;
  dashY: number;
  invulnerableUntil: number;
  respawnAt: number;
  streak: number;
  lastHitAt: number;
  rapidUntil: number;
};

export type PickupKind = "health" | "rapid";
export type Pickup = { id: number; kind: PickupKind; x: number; y: number; at: number };

export type Projectile = {
  id: number;
  owner: PlayerSide;
  x: number;
  y: number;
  vx: number;
  vy: number;
  damage: number;
  expiresAt: number;
};

export type GameEffect = { id: number; type: "spark" | "hit" | "blast" | "muzzle"; x: number; y: number; at: number; side?: PlayerSide };

export type FeedItem = { id: number; killer: string; victim: string; callout: string | null; at: number; side: PlayerSide };

export type RoomState = {
  roomId: string;
  mode: MatchMode;
  mapId: string;
  botSkill: 0 | 1 | 2;
  phase: GamePhase;
  players: PlayerState[];
  projectiles: Projectile[];
  effects: GameEffect[];
  feed: FeedItem[];
  pickups: Pickup[];
  nextPickupAt: number;
  coverHealth: Record<string, number>;
  coverRespawns: Record<string, number>;
  lastTick: number;
  nextId: number;
  startedAt: number;
  winner: PlayerSide | null;
  resultSaved?: boolean;
};

export type PublicPlayer = Omit<PlayerState, "token">;
export type PublicRoom = Omit<RoomState, "players"> & { players: PublicPlayer[] };

export function cleanName(value: unknown, fallback = "ROOKIE"): string {
  if (typeof value !== "string") return fallback;
  return value.replace(/[^a-zA-Z0-9 _-]/g, "").trim().replace(/\s+/g, " ").slice(0, 16).toUpperCase() || fallback;
}

export function freshAmmo(): Record<WeaponKey, number> {
  return { pistol: WEAPONS.pistol.mag, smg: WEAPONS.smg.mag, shotgun: WEAPONS.shotgun.mag };
}

export function createRoomState(roomId: string, now = Date.now(), mode: MatchMode = "duel", mapId = "foundry", botSkill: 0 | 1 | 2 = 1): RoomState {
  const map = getMap(mapId);
  return {
    roomId,
    mode,
    mapId: map.id,
    botSkill,
    phase: "waiting",
    players: [],
    projectiles: [],
    effects: [],
    feed: [],
    pickups: [],
    nextPickupAt: now + 9000,
    coverHealth: Object.fromEntries(map.cover.map((cover) => [cover.id, cover.maxHp])),
    coverRespawns: {},
    lastTick: now,
    nextId: 1,
    startedAt: 0,
    winner: null,
    resultSaved: false,
  };
}

export function createPlayer(id: PlayerSide, token: string, name: string, now = Date.now(), team?: 0 | 1, mapId = "foundry"): PlayerState {
  const spawn = spawnFor(mapId, id);
  return {
    id,
    team: team ?? teamForSide(id),
    isBot: false,
    token,
    name: cleanName(name, id === "alpha" ? "PLAYER ONE" : "PLAYER TWO"),
    x: spawn.x,
    y: spawn.y,
    aim: id === "alpha" ? 0 : Math.PI,
    hp: 100,
    kills: 0,
    deaths: 0,
    weapon: "pistol",
    ammo: freshAmmo(),
    input: { mx: 0, my: 0, aim: id === "alpha" ? 0 : Math.PI, shoot: false, reload: false, dash: false },
    lastSeen: now,
    lastInputSeq: 0,
    lastShotAt: 0,
    reloadEndsAt: 0,
    dashEndsAt: 0,
    dashReadyAt: 0,
    dashX: 0,
    dashY: 0,
    invulnerableUntil: 0,
    respawnAt: 0,
    streak: 0,
    lastHitAt: 0,
    rapidUntil: 0,
  };
}

export function teamScores(state: { players: readonly { team: 0 | 1; kills: number }[] }): [number, number] {
  let blue = 0;
  let red = 0;
  for (const player of state.players) {
    if (player.team === 0) blue += player.kills;
    else red += player.kills;
  }
  return [blue, red];
}

export function toPublicRoom(state: RoomState): PublicRoom {
  return {
    ...state,
    players: state.players.map((player) => {
      const { token: _token, ...safe } = player;
      void _token;
      return safe;
    }),
  };
}

export function isCoverActive(state: Pick<RoomState, "coverHealth">, cover: CoverDefinition): boolean {
  return cover.kind === "wall" || (state.coverHealth[cover.id] ?? cover.maxHp) > 0;
}

function circleRectOverlap(x: number, y: number, radius: number, rect: CoverDefinition): boolean {
  const nearX = Math.max(rect.x, Math.min(x, rect.x + rect.w));
  const nearY = Math.max(rect.y, Math.min(y, rect.y + rect.h));
  return (x - nearX) ** 2 + (y - nearY) ** 2 < radius ** 2;
}

export function moveWithCollisions(x: number, y: number, dx: number, dy: number, coverHealth: Record<string, number>, cover: CoverDefinition[] = COVER): { x: number; y: number } {
  const collides = (px: number, py: number) => cover.some((item) => (item.kind === "wall" || (coverHealth[item.id] ?? item.maxHp) > 0) && circleRectOverlap(px, py, PLAYER_RADIUS, item));
  const steps = Math.max(1, Math.ceil(Math.max(Math.abs(dx), Math.abs(dy)) / 8));
  for (let step = 0; step < steps; step++) {
    const nextX = Math.max(42, Math.min(ARENA_WIDTH - 42, x + dx / steps));
    if (!collides(nextX, y)) x = nextX;
    const nextY = Math.max(42, Math.min(ARENA_HEIGHT - 42, y + dy / steps));
    if (!collides(x, nextY)) y = nextY;
  }
  return { x, y };
}

function segmentRectT(x1: number, y1: number, x2: number, y2: number, rect: CoverDefinition): number | null {
  const dx = x2 - x1;
  const dy = y2 - y1;
  let tMin = 0;
  let tMax = 1;
  for (const [start, delta, min, max] of [[x1, dx, rect.x, rect.x + rect.w], [y1, dy, rect.y, rect.y + rect.h]]) {
    if (Math.abs(delta) < 0.00001) {
      if (start < min || start > max) return null;
    } else {
      const a = (min - start) / delta;
      const b = (max - start) / delta;
      tMin = Math.max(tMin, Math.min(a, b));
      tMax = Math.min(tMax, Math.max(a, b));
      if (tMin > tMax) return null;
    }
  }
  return tMin;
}

function segmentCircleT(x1: number, y1: number, x2: number, y2: number, cx: number, cy: number, radius: number): number | null {
  const dx = x2 - x1;
  const dy = y2 - y1;
  const fx = x1 - cx;
  const fy = y1 - cy;
  const a = dx * dx + dy * dy;
  if (a < 0.00001) return null;
  const b = 2 * (fx * dx + fy * dy);
  const c = fx * fx + fy * fy - radius * radius;
  const determinant = b * b - 4 * a * c;
  if (determinant < 0) return null;
  const t = (-b - Math.sqrt(determinant)) / (2 * a);
  return t >= 0 && t <= 1 ? t : null;
}

export function isPlayerInCover(player: PublicPlayer, enemy: PublicPlayer | undefined, state: PublicRoom): boolean {
  if (!enemy || player.hp <= 0) return false;
  return mapCover(state.mapId).some((cover) => {
    if (!isCoverActive(state, cover)) return false;
    const nearX = Math.max(cover.x, Math.min(player.x, cover.x + cover.w));
    const nearY = Math.max(cover.y, Math.min(player.y, cover.y + cover.h));
    const close = Math.hypot(player.x - nearX, player.y - nearY) < 62;
    return close && segmentRectT(enemy.x, enemy.y, player.x, player.y, cover) !== null;
  });
}

function addEffect(state: RoomState, type: GameEffect["type"], x: number, y: number, now: number, side?: PlayerSide) {
  state.effects.push({ id: state.nextId++, type, x, y, at: now, side });
}

function beginReload(player: PlayerState, now: number) {
  if (player.hp > 0 && !player.reloadEndsAt && player.ammo[player.weapon] < WEAPONS[player.weapon].mag) {
    player.reloadEndsAt = now + WEAPONS[player.weapon].reload;
  }
}

function fire(state: RoomState, player: PlayerState, now: number) {
  if (player.hp <= 0 || player.reloadEndsAt || state.phase !== "playing") return;
  const weapon = WEAPONS[player.weapon];
  if (player.ammo[player.weapon] <= 0) {
    beginReload(player, now);
    return;
  }
  const interval = player.rapidUntil > now ? weapon.interval / 2 : weapon.interval;
  if (now - player.lastShotAt < interval) return;
  player.lastShotAt = now;
  player.ammo[player.weapon]--;
  const muzzleX = player.x + Math.cos(player.aim) * 29;
  const muzzleY = player.y + Math.sin(player.aim) * 29;
  addEffect(state, "muzzle", muzzleX, muzzleY, now, player.id);
  for (let pellet = 0; pellet < weapon.pellets; pellet++) {
    const offset = weapon.pellets > 1 ? (pellet / (weapon.pellets - 1) - 0.5) * weapon.spread * 2 : (Math.random() - 0.5) * weapon.spread * 2;
    const angle = player.aim + offset + (Math.random() - 0.5) * weapon.spread * 0.17;
    state.projectiles.push({
      id: state.nextId++, owner: player.id, x: muzzleX, y: muzzleY,
      vx: Math.cos(angle) * weapon.speed, vy: Math.sin(angle) * weapon.speed,
      damage: weapon.damage, expiresAt: now + weapon.life,
    });
  }
  if (player.ammo[player.weapon] <= 0) beginReload(player, now);
}

export function applyPlayerInput(state: RoomState, player: PlayerState, raw: Partial<PlayerInput> & { weapon?: WeaponKey; name?: string }, now: number, sequence: number) {
  player.lastSeen = now;
  if (sequence <= player.lastInputSeq) return;
  player.lastInputSeq = sequence;
  if (raw.weapon && raw.weapon in WEAPONS && raw.weapon !== player.weapon) {
    player.weapon = raw.weapon;
    player.reloadEndsAt = 0;
  }
  const mx = typeof raw.mx === "number" && Number.isFinite(raw.mx) ? Math.max(-1, Math.min(1, raw.mx)) : 0;
  const my = typeof raw.my === "number" && Number.isFinite(raw.my) ? Math.max(-1, Math.min(1, raw.my)) : 0;
  const magnitude = Math.hypot(mx, my);
  const aim = typeof raw.aim === "number" && Number.isFinite(raw.aim) ? raw.aim : player.aim;
  const next: PlayerInput = {
    mx: magnitude > 1 ? mx / magnitude : mx,
    my: magnitude > 1 ? my / magnitude : my,
    aim,
    shoot: raw.shoot === true,
    reload: raw.reload === true,
    dash: raw.dash === true,
  };
  if (next.reload && !player.input.reload) beginReload(player, now);
  if (next.dash && !player.input.dash && now >= player.dashReadyAt && player.hp > 0) {
    const moveLength = Math.hypot(next.mx, next.my);
    player.dashX = moveLength > 0.1 ? next.mx / moveLength : Math.cos(aim);
    player.dashY = moveLength > 0.1 ? next.my / moveLength : Math.sin(aim);
    player.dashEndsAt = now + 185;
    player.dashReadyAt = now + 3200;
  }
  player.input = next;
  player.aim = aim;
  player.lastSeen = now;
  if (typeof raw.name === "string") player.name = cleanName(raw.name, player.name);
  if (next.shoot) fire(state, player, now);
}

const BOT_COLS = 28;
const BOT_ROWS = 16;
const BOT_NEIGHBORS = [[0, -1], [0, 1], [-1, 0], [1, 0]] as const;

function botWaypoint(state: RoomState, bot: PlayerState, target: PlayerState, cover: CoverDefinition[]): { x: number; y: number } | null {
  const total = BOT_COLS * BOT_ROWS;
  const walkable = new Uint8Array(total);
  let start = -1;
  let goal = -1;
  let startDistance = Infinity;
  let goalDistance = Infinity;

  for (let row = 0; row < BOT_ROWS; row++) {
    for (let col = 0; col < BOT_COLS; col++) {
      const index = row * BOT_COLS + col;
      const x = 60 + col * 40;
      const y = 60 + row * 40;
      if (cover.some((item) => isCoverActive(state, item) && circleRectOverlap(x, y, PLAYER_RADIUS + 4, item))) continue;
      walkable[index] = 1;
      const fromBot = (x - bot.x) ** 2 + (y - bot.y) ** 2;
      const fromTarget = (x - target.x) ** 2 + (y - target.y) ** 2;
      if (fromBot < startDistance) { startDistance = fromBot; start = index; }
      if (fromTarget < goalDistance) { goalDistance = fromTarget; goal = index; }
    }
  }
  if (start < 0 || goal < 0) return null;

  const distances = new Int16Array(total);
  distances.fill(-1);
  const queue = new Int16Array(total);
  queue[0] = goal;
  distances[goal] = 0;
  let head = 0;
  let tail = 1;
  while (head < tail && distances[start] < 0) {
    const current = queue[head++];
    const col = current % BOT_COLS;
    const row = Math.floor(current / BOT_COLS);
    for (const [dc, dr] of BOT_NEIGHBORS) {
      const nc = col + dc;
      const nr = row + dr;
      if (nc < 0 || nc >= BOT_COLS || nr < 0 || nr >= BOT_ROWS) continue;
      const next = nr * BOT_COLS + nc;
      if (!walkable[next] || distances[next] >= 0) continue;
      distances[next] = distances[current] + 1;
      queue[tail++] = next;
    }
  }
  if (distances[start] < 0) return null;
  const col = start % BOT_COLS;
  const row = Math.floor(start / BOT_COLS);
  let best = start;
  for (const [dc, dr] of BOT_NEIGHBORS) {
    const nc = col + dc;
    const nr = row + dr;
    if (nc < 0 || nc >= BOT_COLS || nr < 0 || nr >= BOT_ROWS) continue;
    const next = nr * BOT_COLS + nc;
    if (distances[next] >= 0 && distances[next] < distances[best]) best = next;
  }
  return best === start && start === goal
    ? { x: target.x, y: target.y }
    : { x: 60 + (best % BOT_COLS) * 40, y: 60 + Math.floor(best / BOT_COLS) * 40 };
}

const BOT_WOBBLE = [0.16, 0.105, 0.06];
const BOT_FIRE_GAP = [700, 520, 380];
const BOT_RANGE = [420, 500, 560];

function driveBot(state: RoomState, now: number) {
  const cover = mapCover(state.mapId);
  const skill = state.botSkill ?? 1;
  const wobble = BOT_WOBBLE[skill];
  const fireGap = BOT_FIRE_GAP[skill];
  const range = BOT_RANGE[skill];
  for (const bot of state.players.filter((player) => player.isBot)) {
    bot.lastSeen = now;
    let target: PlayerState | null = null;
    let targetDistance = Infinity;
    for (const enemy of state.players) {
      if (enemy.team === bot.team || enemy.hp <= 0) continue;
      const distance = Math.hypot(enemy.x - bot.x, enemy.y - bot.y);
      if (distance < targetDistance) { targetDistance = distance; target = enemy; }
    }
    if (bot.hp <= 0 || !target) {
      bot.input = { ...bot.input, mx: 0, my: 0, shoot: false };
      continue;
    }

    const dx = target.x - bot.x;
    const dy = target.y - bot.y;
    const distance = Math.max(1, Math.hypot(dx, dy));
    const visible = !cover.some((item) => isCoverActive(state, item) && segmentRectT(bot.x, bot.y, target.x, target.y, item) !== null);
    const aim = Math.atan2(dy, dx) + Math.sin(now / 430) * wobble;
    let mx = 0;
    let my = 0;
    if (!visible || distance > 250) {
      const waypoint = botWaypoint(state, bot, target, cover) ?? { x: target.x, y: target.y };
      const length = Math.hypot(waypoint.x - bot.x, waypoint.y - bot.y);
      if (length > 5) { mx = (waypoint.x - bot.x) / length; my = (waypoint.y - bot.y) / length; }
    } else if (distance < 140) {
      mx = -dx / distance;
      my = -dy / distance;
    } else {
      const direction = Math.sin(now / 2200) > 0 ? 1 : -1;
      mx = -dy / distance * direction * 0.45;
      my = dx / distance * direction * 0.45;
    }
    bot.aim = aim;
    bot.input = { mx, my, aim, shoot: visible && distance < range && now - bot.lastShotAt >= fireGap, reload: false, dash: false };
    if (bot.ammo[bot.weapon] <= 0) beginReload(bot, now);
  }
}

export function advanceGame(state: RoomState, now: number) {
  const dt = Math.max(0, Math.min((now - state.lastTick) / 1000, 0.16));
  state.lastTick = now;
  // Normalize rooms persisted before newer fields existed.
  if (!state.mapId) state.mapId = "foundry";
  if (!state.feed) state.feed = [];
  if (!state.pickups) state.pickups = [];
  if (!state.nextPickupAt) state.nextPickupAt = now + 9000;
  for (const player of state.players) {
    if (player.team === undefined) player.team = teamForSide(player.id);
    if (player.streak === undefined) player.streak = 0;
    if (player.lastHitAt === undefined) player.lastHitAt = 0;
    if (player.rapidUntil === undefined) player.rapidUntil = 0;
  }
  state.effects = state.effects.filter((effect) => now - effect.at < 650).slice(-40);
  state.feed = state.feed.filter((item) => now - item.at < 3600).slice(-3);
  if (state.phase !== "playing") return;

  const coverList = mapCover(state.mapId);

  for (const cover of coverList) {
    if (cover.kind === "crate" && state.coverHealth[cover.id] === 0 && (state.coverRespawns[cover.id] ?? Infinity) <= now) {
      if (state.players.some((player) => player.hp > 0 && circleRectOverlap(player.x, player.y, PLAYER_RADIUS + 4, cover))) {
        state.coverRespawns[cover.id] = now + 1000;
      } else {
        state.coverHealth[cover.id] = cover.maxHp;
        delete state.coverRespawns[cover.id];
        addEffect(state, "blast", cover.x + cover.w / 2, cover.y + cover.h / 2, now);
      }
    }
  }

  if (state.players.some((player) => player.isBot)) driveBot(state, now);

  for (const player of state.players) {
    if (player.hp <= 0) {
      if (player.respawnAt && now >= player.respawnAt) {
        const spawn = spawnFor(state.mapId, player.id);
        player.x = spawn.x;
        player.y = spawn.y;
        player.hp = 100;
        player.ammo = freshAmmo();
        player.reloadEndsAt = 0;
        player.respawnAt = 0;
        player.invulnerableUntil = now + 1050;
        player.input.shoot = false;
        addEffect(state, "blast", player.x, player.y, now, player.id);
      }
      continue;
    }
    if (player.reloadEndsAt && now >= player.reloadEndsAt) {
      player.ammo[player.weapon] = WEAPONS[player.weapon].mag;
      player.reloadEndsAt = 0;
    }
    if (now - player.lastSeen > 450) continue;
    const dashing = now < player.dashEndsAt;
    const dx = (dashing ? player.dashX * 760 : player.input.mx * 265) * dt;
    const dy = (dashing ? player.dashY * 760 : player.input.my * 265) * dt;
    const position = moveWithCollisions(player.x, player.y, dx, dy, state.coverHealth, coverList);
    player.x = position.x;
    player.y = position.y;
    if (player.input.shoot) fire(state, player, now);
  }

  if (now >= state.nextPickupAt) {
    state.nextPickupAt = now + 12000;
    const spots = getMap(state.mapId).pickupSpots;
    const free = spots.filter(
      (spot) =>
        !state.pickups.some((pickup) => Math.hypot(pickup.x - spot.x, pickup.y - spot.y) < 40) &&
        !state.players.some((player) => player.hp > 0 && Math.hypot(player.x - spot.x, player.y - spot.y) < 40),
    );
    if (free.length > 0 && state.pickups.length < 3) {
      const spot = free[Math.floor(Math.random() * free.length)];
      state.pickups.push({ id: state.nextId++, kind: Math.random() < 0.5 ? "health" : "rapid", x: spot.x, y: spot.y, at: now });
      addEffect(state, "spark", spot.x, spot.y, now);
    }
  }

  for (const player of state.players) {
    if (player.hp <= 0) continue;
    const taken = state.pickups.findIndex((pickup) => Math.hypot(pickup.x - player.x, pickup.y - player.y) < 30);
    if (taken >= 0) {
      const [pickup] = state.pickups.splice(taken, 1);
      if (pickup.kind === "health") player.hp = Math.min(100, player.hp + 50);
      else player.rapidUntil = now + 8000;
      addEffect(state, "blast", player.x, player.y, now, player.id);
    }
  }

  const survivors: Projectile[] = [];
  for (const projectile of state.projectiles) {
    if (now >= projectile.expiresAt) continue;
    const x2 = projectile.x + projectile.vx * dt;
    const y2 = projectile.y + projectile.vy * dt;
    if (x2 < 28 || x2 > ARENA_WIDTH - 28 || y2 < 28 || y2 > ARENA_HEIGHT - 28) continue;
    let firstT = 2;
    let hitCover: CoverDefinition | null = null;
    let hitPlayer: PlayerState | null = null;
    for (const cover of coverList) {
      if (!isCoverActive(state, cover)) continue;
      const t = segmentRectT(projectile.x, projectile.y, x2, y2, cover);
      if (t !== null && t < firstT) { firstT = t; hitCover = cover; hitPlayer = null; }
    }
    const owner = state.players.find((player) => player.id === projectile.owner);
    const ownerTeam = owner?.team;
    for (const player of state.players) {
      if (player.id === projectile.owner || player.hp <= 0 || now < player.invulnerableUntil) continue;
      if (ownerTeam !== undefined && player.team === ownerTeam) continue;
      const t = segmentCircleT(projectile.x, projectile.y, x2, y2, player.x, player.y, PLAYER_RADIUS);
      if (t !== null && t < firstT) { firstT = t; hitPlayer = player; hitCover = null; }
    }
    if (firstT <= 1) {
      const hitX = projectile.x + (x2 - projectile.x) * firstT;
      const hitY = projectile.y + (y2 - projectile.y) * firstT;
      if (hitCover) {
        addEffect(state, "spark", hitX, hitY, now);
        if (hitCover.kind === "crate") {
          state.coverHealth[hitCover.id] = Math.max(0, (state.coverHealth[hitCover.id] ?? hitCover.maxHp) - projectile.damage);
          if (state.coverHealth[hitCover.id] === 0) {
            state.coverRespawns[hitCover.id] = now + 12000;
            addEffect(state, "blast", hitCover.x + hitCover.w / 2, hitCover.y + hitCover.h / 2, now);
          }
        }
      }
      if (hitPlayer) {
        addEffect(state, "hit", hitX, hitY, now, hitPlayer.id);
        hitPlayer.hp = Math.max(0, hitPlayer.hp - projectile.damage);
        hitPlayer.lastHitAt = now;
        if (hitPlayer.hp === 0) {
          hitPlayer.deaths++;
          hitPlayer.streak = 0;
          hitPlayer.respawnAt = now + 1450;
          hitPlayer.input.shoot = false;
          const killer = state.players.find((player) => player.id === projectile.owner);
          if (killer) {
            killer.kills++;
            killer.streak++;
            const firstBlood = state.players.every((player) => player.kills + player.deaths <= 1);
            const callout = firstBlood
              ? "FIRST BLOOD"
              : killer.streak >= 4 ? "RAMPAGE" : killer.streak === 3 ? "TRIPLE KILL" : killer.streak === 2 ? "DOUBLE KILL" : null;
            state.feed.push({ id: state.nextId++, killer: killer.name, victim: hitPlayer.name, callout, at: now, side: killer.id });
            state.feed = state.feed.slice(-3);
            const teamKills = state.players.filter((player) => player.team === killer.team).reduce((sum, player) => sum + player.kills, 0);
            const won = state.mode === "squad" ? teamKills >= TEAM_WIN_SCORE : killer.kills >= WIN_SCORE;
            if (won) {
              state.phase = "finished";
              state.winner = killer.id;
            }
          }
          addEffect(state, "blast", hitPlayer.x, hitPlayer.y, now, hitPlayer.id);
          if (state.phase === "finished") {
            state.projectiles = [];
            return;
          }
        }
      }
    } else {
      projectile.x = x2;
      projectile.y = y2;
      survivors.push(projectile);
    }
  }
  state.projectiles = survivors.slice(-160);
}

export function resetMatch(state: RoomState, now = Date.now()) {
  state.phase = state.players.length >= 2 ? "playing" : "waiting";
  state.winner = null;
  state.resultSaved = false;
  state.startedAt = state.phase === "playing" ? now : 0;
  state.lastTick = now;
  state.projectiles = [];
  state.effects = [];
  state.feed = [];
  state.pickups = [];
  state.nextPickupAt = now + 9000;
  state.coverHealth = Object.fromEntries(mapCover(state.mapId).map((cover) => [cover.id, cover.maxHp]));
  state.coverRespawns = {};
  for (const player of state.players) {
    const fresh = createPlayer(player.id, player.token, player.name, now, player.team, state.mapId);
    fresh.isBot = player.isBot === true;
    Object.assign(player, fresh);
  }
}
