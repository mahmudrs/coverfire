"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { localStore, randomId } from "@/lib/browser";
import { getSdkUserToken, sdkGetData, sdkSetData } from "@/lib/crazygames";
import {
  PROGRESS_KEY,
  applyMatchResult,
  defaultProgress,
  mergeProgress,
  normalizeProgress,
  type MatchOutcome,
  type ProgressSave,
} from "@/lib/progress";

export type AccountInfo = { id: string; platform: string; username: string; verified: boolean };
export type ProgressStatus = "loading" | "saving" | "synced" | "local" | "error";
export type ProgressState = { progress: ProgressSave; account: AccountInfo | null; status: ProgressStatus };

const LOCAL_ID_KEY = "coverfire.localId";
const NAME_KEY = "coverfire:name";

function localId(): string {
  try {
    const existing = window.localStorage.getItem(LOCAL_ID_KEY);
    if (existing && /^[a-zA-Z0-9-]{8,64}$/.test(existing)) return existing;
  } catch {
    return randomId();
  }
  const created = randomId();
  try {
    window.localStorage.setItem(LOCAL_ID_KEY, created);
  } catch {
    /* Play on with an in-memory identity. */
  }
  return created;
}

function readLocalMirror(): ProgressSave | null {
  try {
    const raw = window.localStorage.getItem(PROGRESS_KEY);
    if (!raw) return null;
    return normalizeProgress(JSON.parse(raw), window.localStorage.getItem(NAME_KEY) ?? "ROOKIE");
  } catch {
    return null;
  }
}

function writeLocalMirror(progress: ProgressSave) {
  try {
    window.localStorage.setItem(PROGRESS_KEY, JSON.stringify(progress));
    window.localStorage.setItem(NAME_KEY, progress.callsign);
  } catch {
    /* Storage can be blocked in private mode. */
  }
}

async function readCloudMirror(): Promise<ProgressSave | null> {
  try {
    const raw = await sdkGetData(PROGRESS_KEY);
    return raw ? normalizeProgress(JSON.parse(raw)) : null;
  } catch {
    return null;
  }
}

async function writeCloudMirror(progress: ProgressSave): Promise<boolean> {
  return sdkSetData(PROGRESS_KEY, JSON.stringify(progress));
}

async function identityPayload(): Promise<Record<string, string>> {
  const token = await getSdkUserToken();
  if (token) return { token };
  return { localId: localId() };
}

async function accountRequest(action: "session" | "save", save?: ProgressSave, username?: string) {
  const identity = await identityPayload();
  const response = await fetch("/api/account", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    cache: "no-store",
    body: JSON.stringify({ action, ...identity, username, save }),
  });
  if (!response.ok) return null;
  return (await response.json()) as { account: AccountInfo | null; save: ProgressSave; merged?: boolean };
}

/** Loads the profile from the CrazyGames Data module, local storage and the linked backend account. */
export async function bootstrapProgress(): Promise<ProgressState> {
  const storedName = (() => {
    try {
      return window.localStorage.getItem(NAME_KEY) ?? undefined;
    } catch {
      return undefined;
    }
  })();

  const [local, cloud] = await Promise.all([Promise.resolve(readLocalMirror()), readCloudMirror()]);
  let combined = local && cloud ? mergeProgress(local, cloud) : local ?? cloud ?? defaultProgress(storedName ?? "ROOKIE");
  if (combined.callsign === "ROOKIE" && storedName) combined = { ...combined, callsign: storedName.slice(0, 16).toUpperCase() };

  try {
    const data = await accountRequest("session", combined, combined.callsign);
    if (!data) {
      writeLocalMirror(combined);
      return { progress: combined, account: null, status: "local" };
    }
    const save = normalizeProgress(data.save, combined.callsign);
    writeLocalMirror(save);
    await writeCloudMirror(save);
    return { progress: save, account: data.account, status: "synced" };
  } catch {
    writeLocalMirror(combined);
    return { progress: combined, account: null, status: "error" };
  }
}

/** Writes the profile to every mirror (SDK cloud data, localStorage, backend account). */
export async function persistProgress(progress: ProgressSave): Promise<ProgressSave | null> {
  writeLocalMirror(progress);
  const cloudOk = await writeCloudMirror(progress);
  try {
    const data = await accountRequest("save", progress, progress.callsign);
    if (data) {
      const merged = normalizeProgress(data.save, progress.callsign);
      writeLocalMirror(merged);
      await writeCloudMirror(merged);
      return merged;
    }
  } catch {
    /* Offline: the local and SDK mirrors still hold the save. */
  }
  return cloudOk ? progress : null;
}

export function useProgress() {
  const [state, setState] = useState<ProgressState>({ progress: defaultProgress("ROOKIE"), account: null, status: "loading" });
  const progressRef = useRef<ProgressSave>(state.progress);
  const characterRef = useRef<ProgressSave>(state.progress);

  useEffect(() => {
    let active = true;
    void bootstrapProgress().then((next) => {
      if (!active) return;
      progressRef.current = next.progress;
      setState(next);
    });
    return () => { active = false; };
  }, []);

  useEffect(() => {
    characterRef.current = state.progress;
  }, [state.progress]);

  const record = useCallback(async (outcome: MatchOutcome) => {
    const next = applyMatchResult(progressRef.current, outcome);
    progressRef.current = next;
    characterRef.current = next;
    setState((previous) => ({ ...previous, progress: next, status: "saving" }));
    const saved = await persistProgress(next);
    if (saved) {
      const merged = mergeProgress(next, saved);
      progressRef.current = merged;
      characterRef.current = merged;
      setState((previous) => ({ ...previous, progress: merged, status: "synced" }));
    } else {
      setState((previous) => ({ ...previous, status: "local" }));
    }
    return saved;
  }, []);

  const rename = useCallback((callsign: string) => {
    const cleaned = callsign.replace(/[^a-zA-Z0-9 _-]/g, "").trim().slice(0, 16).toUpperCase() || "ROOKIE";
    const next = { ...progressRef.current, callsign: cleaned, updatedAt: Date.now() };
    progressRef.current = next;
    characterRef.current = next;
    setState((previous) => ({ ...previous, progress: next }));
    void persistProgress(next);
  }, []);

  return { ...state, progress: state.progress, record, rename };
}
