import type { WeaponKey } from "@/lib/game";

export const PROGRESS_KEY = "coverfire.progress.v1";

export type ProgressSave = {
  version: 1;
  callsign: string;
  matches: number;
  wins: number;
  kills: number;
  deaths: number;
  bestKills: number;
  bestStreak: number;
  selectedWeapon: WeaponKey;
  totalPlayMs: number;
  updatedAt: number;
};

export type MatchOutcome = {
  kills: number;
  deaths: number;
  won: boolean;
  durationMs: number;
  weapon: WeaponKey;
  callsign: string;
};

const WEAPONS: WeaponKey[] = ["pistol", "smg", "shotgun"];
const clampInt = (value: unknown, max: number) => {
  const number = Math.round(Number(value));
  return Number.isFinite(number) ? Math.max(0, Math.min(max, number)) : 0;
};

export function defaultProgress(callsign = "ROOKIE"): ProgressSave {
  return {
    version: 1,
    callsign: callsign.slice(0, 16),
    matches: 0,
    wins: 0,
    kills: 0,
    deaths: 0,
    bestKills: 0,
    bestStreak: 0,
    selectedWeapon: "pistol",
    totalPlayMs: 0,
    updatedAt: 0,
  };
}

export function normalizeProgress(raw: unknown, fallbackCallsign = "ROOKIE"): ProgressSave {
  if (!raw || typeof raw !== "object") return defaultProgress(fallbackCallsign);
  const source = raw as Record<string, unknown>;
  const callsign = typeof source.callsign === "string" ? source.callsign.replace(/[^a-zA-Z0-9 _-]/g, "").trim().slice(0, 16).toUpperCase() : "";
  return {
    version: 1,
    callsign: callsign || fallbackCallsign.slice(0, 16).toUpperCase(),
    matches: clampInt(source.matches, 100000),
    wins: clampInt(source.wins, 100000),
    kills: clampInt(source.kills, 10_000_000),
    deaths: clampInt(source.deaths, 10_000_000),
    bestKills: clampInt(source.bestKills, 999),
    bestStreak: clampInt(source.bestStreak, 100000),
    selectedWeapon: WEAPONS.includes(source.selectedWeapon as WeaponKey) ? (source.selectedWeapon as WeaponKey) : "pistol",
    totalPlayMs: clampInt(source.totalPlayMs, 1_000_000_000),
    updatedAt: clampInt(source.updatedAt, Number.MAX_SAFE_INTEGER),
  };
}

/** Combines two mirrors of the same profile without ever losing earned progress. */
export function mergeProgress(a: ProgressSave, b: ProgressSave): ProgressSave {
  const newer = a.updatedAt >= b.updatedAt ? a : b;
  return {
    version: 1,
    callsign: newer.callsign || a.callsign || b.callsign,
    matches: Math.max(a.matches, b.matches),
    wins: Math.max(a.wins, b.wins),
    kills: Math.max(a.kills, b.kills),
    deaths: Math.max(a.deaths, b.deaths),
    bestKills: Math.max(a.bestKills, b.bestKills),
    bestStreak: Math.max(a.bestStreak, b.bestStreak),
    selectedWeapon: newer.selectedWeapon,
    totalPlayMs: Math.max(a.totalPlayMs, b.totalPlayMs),
    updatedAt: Math.max(a.updatedAt, b.updatedAt),
  };
}

export function applyMatchResult(progress: ProgressSave, outcome: MatchOutcome): ProgressSave {
  return {
    ...progress,
    callsign: outcome.callsign ? outcome.callsign.slice(0, 16).toUpperCase() : progress.callsign,
    matches: progress.matches + 1,
    wins: progress.wins + (outcome.won ? 1 : 0),
    kills: progress.kills + outcome.kills,
    deaths: progress.deaths + outcome.deaths,
    bestKills: Math.max(progress.bestKills, outcome.kills),
    bestStreak: outcome.won ? progress.bestStreak + 1 : 0,
    selectedWeapon: outcome.weapon,
    totalPlayMs: progress.totalPlayMs + Math.max(0, Math.min(3_600_000, outcome.durationMs)),
    updatedAt: Date.now(),
  };
}

export function winRateOf(progress: ProgressSave): number {
  return progress.matches > 0 ? Math.round((progress.wins / progress.matches) * 100) : 0;
}

export function rankOf(progress: ProgressSave): { label: string; next: number } {
  const score = progress.wins * 3 + progress.bestKills;
  const tiers: [number, string][] = [[0, "RECRUIT"], [6, "OPERATIVE"], [18, "VETERAN"], [40, "SPECIALIST"], [75, "ELITE"], [130, "LEGEND"]];
  let label = tiers[0][1];
  let next = tiers[1][0];
  for (let index = 0; index < tiers.length; index++) {
    if (score >= tiers[index][0]) {
      label = tiers[index][1];
      next = tiers[index + 1]?.[0] ?? tiers[index][0];
    }
  }
  return { label, next };
}
