import { ARENA_HEIGHT, ARENA_WIDTH, COVER, PLAYER_RADIUS, SIDES, SIDE_LABELS, getMap, type CoverDefinition, type PublicPlayer, type PublicRoom, type PlayerSide } from "@/lib/game";

export const SIDE_COLORS: Record<PlayerSide, string> = { alpha: "#9ce8db", bravo: "#ffa77d", charlie: "#8fb8ff", delta: "#ff8f9d" };
export const TEAM_COLORS = ["#9ce8db", "#ffa77d"];
export const ARENA_SCALE = 2;

let staticLayer: HTMLCanvasElement | null = null;
let staticMapId = "";

function rect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, radius = 0) {
  ctx.beginPath();
  if (typeof ctx.roundRect === "function") ctx.roundRect(x, y, w, h, radius);
  else ctx.rect(x, y, w, h);
}

function drawFloor(ctx: CanvasRenderingContext2D, mapName: string) {
  ctx.fillStyle = "#1b2728";
  ctx.fillRect(0, 0, ARENA_WIDTH, ARENA_HEIGHT);

  const glow = ctx.createRadialGradient(600, 350, 65, 600, 350, 740);
  glow.addColorStop(0, "#304041");
  glow.addColorStop(0.65, "#223031");
  glow.addColorStop(1, "#142021");
  ctx.fillStyle = glow;
  ctx.fillRect(0, 0, ARENA_WIDTH, ARENA_HEIGHT);

  for (let x = 0; x <= ARENA_WIDTH; x += 40) {
    ctx.strokeStyle = x % 200 === 0 ? "rgba(201,226,213,.085)" : "rgba(201,226,213,.035)";
    ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(x + 0.5, 0); ctx.lineTo(x + 0.5, ARENA_HEIGHT); ctx.stroke();
  }
  for (let y = 0; y <= ARENA_HEIGHT; y += 40) {
    ctx.strokeStyle = y % 200 === 0 ? "rgba(201,226,213,.085)" : "rgba(201,226,213,.035)";
    ctx.beginPath(); ctx.moveTo(0, y + 0.5); ctx.lineTo(ARENA_WIDTH, y + 0.5); ctx.stroke();
  }

  let seed = 83473;
  const random = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
  for (let i = 0; i < 1200; i++) {
    ctx.fillStyle = random() > 0.5 ? "rgba(235,225,197,.09)" : "rgba(3,8,9,.16)";
    ctx.fillRect(random() * ARENA_WIDTH, random() * ARENA_HEIGHT, random() * 3 + 1, random() * 2 + 1);
  }

  ctx.strokeStyle = "rgba(219,236,218,.18)";
  ctx.lineWidth = 2;
  ctx.strokeRect(25, 25, 1150, 670);
  ctx.strokeStyle = "rgba(219,236,218,.09)";
  ctx.strokeRect(32, 32, 1136, 656);
  ctx.setLineDash([9, 12]);
  ctx.strokeStyle = "rgba(232,221,184,.17)";
  ctx.beginPath(); ctx.moveTo(600, 36); ctx.lineTo(600, 684); ctx.stroke();
  ctx.setLineDash([]);

  ctx.save();
  ctx.translate(600, 360);
  ctx.strokeStyle = "rgba(233,209,157,.14)";
  ctx.lineWidth = 2;
  for (const radius of [125, 156, 184]) {
    ctx.beginPath(); ctx.arc(0, 0, radius, -0.5, 0.5); ctx.stroke();
    ctx.beginPath(); ctx.arc(0, 0, radius, Math.PI - 0.5, Math.PI + 0.5); ctx.stroke();
  }
  ctx.restore();

  ctx.font = "bold 12px monospace";
  ctx.textAlign = "left";
  ctx.fillStyle = "rgba(221,233,218,.23)";
  ctx.fillText("SECTOR 01 / THE FOUNDRY", 47, 68);
  ctx.fillText(mapName, 47, 671);
  ctx.textAlign = "right";
  ctx.fillText("NO SAFE ZONE", 1152, 68);
  ctx.fillText("// 1200 - 0720", 1152, 671);

  for (const x of [44, 1156]) {
    for (let y = 115; y < 610; y += 25) {
      ctx.fillStyle = "rgba(244,178,105,.18)";
      ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + (x < 600 ? 8 : -8), y + 10); ctx.lineTo(x, y + 13); ctx.fill();
    }
  }
}

function drawWall(ctx: CanvasRenderingContext2D, cover: CoverDefinition) {
  const { x, y, w, h } = cover;
  ctx.fillStyle = "rgba(2,10,11,.45)";
  rect(ctx, x + 5, y + 11, w, h, 6); ctx.fill();
  ctx.fillStyle = "#253d40";
  rect(ctx, x, y + 6, w, h, 5); ctx.fill();
  ctx.fillStyle = "#637b75";
  rect(ctx, x, y, w, h - 4, 5); ctx.fill();
  ctx.fillStyle = "#80978b";
  rect(ctx, x + 4, y + 4, w - 8, h - 13, 3); ctx.fill();
  ctx.fillStyle = "rgba(9,27,28,.22)";
  rect(ctx, x + 10, y + 11, w - 20, h - 27, 2); ctx.fill();
  ctx.strokeStyle = "rgba(205,229,208,.32)";
  ctx.lineWidth = 1;
  ctx.strokeRect(x + 8.5, y + 8.5, w - 17, h - 21);
  ctx.fillStyle = "#b7bc93";
  for (const px of [x + 8, x + w - 8]) for (const py of [y + 8, y + h - 17]) { ctx.beginPath(); ctx.arc(px, py, 2.1, 0, Math.PI * 2); ctx.fill(); }
  ctx.fillStyle = "rgba(19,39,39,.45)";
  if (w > h) ctx.fillRect(x + w / 2 - 13, y + 11, 26, h - 27);
  else ctx.fillRect(x + 11, y + h / 2 - 13, w - 22, 26);
}

function staticCanvas(mapId: string): HTMLCanvasElement {
  if (staticLayer && staticMapId === mapId) return staticLayer;
  const map = getMap(mapId);
  const canvas = document.createElement("canvas");
  canvas.width = ARENA_WIDTH * ARENA_SCALE;
  canvas.height = ARENA_HEIGHT * ARENA_SCALE;
  const ctx = canvas.getContext("2d")!;
  ctx.setTransform(ARENA_SCALE, 0, 0, ARENA_SCALE, 0, 0);
  drawFloor(ctx, map.name);
  for (const cover of map.cover) if (cover.kind === "wall") drawWall(ctx, cover);
  for (const side of SIDES) {
    const spawn = map.spawns[side];
    const color = SIDE_COLORS[side];
    ctx.strokeStyle = side === "alpha" || side === "charlie" ? "rgba(156,232,219,.19)" : "rgba(255,167,125,.19)";
    ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(spawn.x, spawn.y, 44, 0, Math.PI * 2); ctx.stroke();
    ctx.setLineDash([4, 8]);
    ctx.beginPath(); ctx.arc(spawn.x, spawn.y, 55, 0, Math.PI * 2); ctx.stroke();
    ctx.setLineDash([]);
    ctx.fillStyle = color === "#9ce8db" || color === "#8fb8ff" ? "rgba(156,232,219,.09)" : "rgba(255,167,125,.09)";
    ctx.font = "bold 40px Arial, sans-serif";
    ctx.textAlign = "center";
    ctx.fillText(SIDE_LABELS[side], spawn.x, spawn.y + 14);
  }
  staticLayer = canvas;
  staticMapId = mapId;
  return canvas;
}

function drawCrate(ctx: CanvasRenderingContext2D, cover: CoverDefinition, hp: number) {
  const { x, y, w, h } = cover;
  if (hp <= 0) {
    ctx.strokeStyle = "rgba(199,165,108,.18)";
    ctx.lineWidth = 2;
    ctx.setLineDash([5, 6]);
    ctx.strokeRect(x + 3, y + 3, w - 6, h - 6);
    ctx.setLineDash([]);
    for (let i = 0; i < 7; i++) {
      const px = x + 12 + ((i * 37) % (w - 20));
      const py = y + 8 + ((i * 19) % (h - 14));
      ctx.fillStyle = i % 2 ? "#665944" : "#978063";
      ctx.fillRect(px, py, 7 + i % 3, 3 + i % 4);
    }
    return;
  }
  ctx.fillStyle = "rgba(2,10,11,.45)";
  rect(ctx, x + 5, y + 11, w, h, 6); ctx.fill();
  ctx.fillStyle = "#533f32";
  rect(ctx, x, y + 6, w, h, 4); ctx.fill();
  ctx.fillStyle = "#a78259";
  rect(ctx, x, y, w, h - 5, 4); ctx.fill();
  ctx.fillStyle = "#b99568";
  rect(ctx, x + 5, y + 5, w - 10, h - 17, 2); ctx.fill();
  ctx.strokeStyle = "rgba(58,47,38,.55)";
  ctx.lineWidth = 4;
  ctx.strokeRect(x + 7, y + 7, w - 14, h - 19);
  ctx.beginPath(); ctx.moveTo(x + 9, y + 8); ctx.lineTo(x + w - 9, y + h - 14); ctx.moveTo(x + w - 9, y + 8); ctx.lineTo(x + 9, y + h - 14); ctx.stroke();
  ctx.fillStyle = "#d4bb86";
  ctx.fillRect(x + w / 2 - 7, y + 3, 14, h - 12);
  ctx.fillStyle = "#403c32";
  ctx.fillRect(x + w / 2 - 4, y + 5, 8, h - 16);
  if (hp < cover.maxHp * 0.55) {
    ctx.strokeStyle = "rgba(41,29,23,.75)";
    ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(x + w * .28, y + 4); ctx.lineTo(x + w * .39, y + h * .35); ctx.lineTo(x + w * .3, y + h * .58); ctx.stroke();
  }
  if (hp < cover.maxHp * 0.25) {
    ctx.beginPath(); ctx.moveTo(x + w * .75, y + 4); ctx.lineTo(x + w * .65, y + h * .5); ctx.lineTo(x + w * .79, y + h - 10); ctx.stroke();
  }
}

function drawEffects(ctx: CanvasRenderingContext2D, state: PublicRoom, now: number) {
  for (const effect of state.effects) {
    const life = effect.type === "blast" ? 600 : 350;
    const progress = (now - effect.at) / life;
    if (progress < 0 || progress >= 1) continue;
    ctx.globalAlpha = 1 - progress;
    if (effect.type === "blast") {
      ctx.strokeStyle = effect.side ? SIDE_COLORS[effect.side] : "#f8c178";
      ctx.lineWidth = 4 * (1 - progress) + 1;
      ctx.beginPath(); ctx.arc(effect.x, effect.y, 8 + progress * 63, 0, Math.PI * 2); ctx.stroke();
      ctx.strokeStyle = "rgba(255,243,202,.8)";
      ctx.beginPath(); ctx.arc(effect.x, effect.y, 4 + progress * 35, 0, Math.PI * 2); ctx.stroke();
    } else if (effect.type === "hit") {
      ctx.fillStyle = "#fff5dc";
      ctx.beginPath(); ctx.arc(effect.x, effect.y, (1 - progress) * 12, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = effect.side ? SIDE_COLORS[effect.side] : "#fff";
      ctx.lineWidth = 3;
      ctx.beginPath(); ctx.arc(effect.x, effect.y, 7 + progress * 20, 0, Math.PI * 2); ctx.stroke();
    } else {
      ctx.strokeStyle = effect.type === "muzzle" ? "#fff2bb" : "#f4c87e";
      ctx.lineWidth = effect.type === "muzzle" ? 3 : 2;
      for (let i = 0; i < 4; i++) {
        const angle = (i / 4) * Math.PI * 2 + effect.id * 1.4;
        const from = 3 + progress * 7;
        const to = (effect.type === "muzzle" ? 25 : 16) * (1 - progress * .45);
        ctx.beginPath();
        ctx.moveTo(effect.x + Math.cos(angle) * from, effect.y + Math.sin(angle) * from);
        ctx.lineTo(effect.x + Math.cos(angle) * to, effect.y + Math.sin(angle) * to);
        ctx.stroke();
      }
    }
  }
  ctx.globalAlpha = 1;
}

function drawPlayer(ctx: CanvasRenderingContext2D, player: PublicPlayer, local: boolean, now: number) {
  if (player.hp <= 0) return;
  const color = SIDE_COLORS[player.id];
  const moving = Math.hypot(player.input.mx, player.input.my) > .1;
  const step = moving ? Math.sin(now / 85) * 4 : 0;
  const dashing = player.dashEndsAt > now;

  ctx.save();
  ctx.translate(player.x, player.y);
  ctx.fillStyle = "rgba(0,4,7,.55)";
  ctx.beginPath(); ctx.ellipse(5, 11, 27, 16, 0, 0, Math.PI * 2); ctx.fill();
  if (local || dashing) {
    ctx.strokeStyle = dashing ? "rgba(255,239,177,.8)" : color;
    ctx.globalAlpha = dashing ? .72 : .32;
    ctx.lineWidth = dashing ? 3 : 1.5;
    ctx.beginPath(); ctx.arc(0, 0, dashing ? 31 : 29, 0, Math.PI * 2); ctx.stroke();
    ctx.globalAlpha = 1;
  }
  if (player.invulnerableUntil > now) {
    ctx.strokeStyle = color;
    ctx.globalAlpha = .34 + .2 * Math.sin(now / 75);
    ctx.lineWidth = 3;
    ctx.beginPath(); ctx.arc(0, 0, 34, 0, Math.PI * 2); ctx.stroke();
    ctx.globalAlpha = 1;
  }
  ctx.rotate(player.aim);
  ctx.fillStyle = "#152125";
  rect(ctx, -20, -15 + step, 13, 9, 3); ctx.fill();
  rect(ctx, -20, 6 - step, 13, 9, 3); ctx.fill();
  ctx.fillStyle = "#34464a";
  rect(ctx, -20, -15 + step, 10, 6, 2); ctx.fill();
  rect(ctx, -20, 6 - step, 10, 6, 2); ctx.fill();

  ctx.fillStyle = "#0d171a";
  rect(ctx, 5, -6, 35, 12, 2); ctx.fill();
  ctx.fillStyle = player.weapon === "shotgun" ? "#8c9a8c" : "#a5aba0";
  rect(ctx, 14, -3.5, player.weapon === "shotgun" ? 28 : 26, 7, 1); ctx.fill();
  ctx.fillStyle = "#273437";
  rect(ctx, 14, -1.5, 26, 3, 1); ctx.fill();
  if (player.weapon === "shotgun") { ctx.fillStyle = "#bb986b"; ctx.fillRect(19, -5, 9, 10); }

  ctx.fillStyle = "#26363a";
  rect(ctx, -17, -15, 30, 30, 9); ctx.fill();
  ctx.fillStyle = color;
  rect(ctx, -14, -13, 27, 26, 8); ctx.fill();
  ctx.fillStyle = "rgba(12,29,32,.34)";
  rect(ctx, -12, -10, 18, 20, 6); ctx.fill();
  ctx.fillStyle = "#314349";
  rect(ctx, 0, -18, 15, 8, 3); ctx.fill();
  rect(ctx, 0, 10, 15, 8, 3); ctx.fill();
  ctx.fillStyle = color;
  ctx.fillRect(5, -16, 7, 3);
  ctx.fillRect(5, 13, 7, 3);
  ctx.fillStyle = "#14272a";
  rect(ctx, -4, -11, 11, 22, 4); ctx.fill();
  ctx.fillStyle = "#dcebd4";
  rect(ctx, 3, -8, 5, 16, 2); ctx.fill();
  const muzzleAge = now - player.lastShotAt;
  if (muzzleAge >= 0 && muzzleAge < 90 && player.hp > 0) {
    const fade = 1 - muzzleAge / 90;
    const glow = ctx.createRadialGradient(42, 0, 2, 42, 0, 30);
    glow.addColorStop(0, `rgba(255,240,190,${0.85 * fade})`);
    glow.addColorStop(1, "rgba(255,240,190,0)");
    ctx.fillStyle = glow;
    ctx.beginPath(); ctx.arc(42, 0, 30, 0, Math.PI * 2); ctx.fill();
  }
  ctx.restore();

  const flashAge = now - (player.lastHitAt ?? 0);
  if (flashAge >= 0 && flashAge < 220) {
    ctx.save();
    ctx.globalAlpha = (1 - flashAge / 220) * 0.6;
    ctx.fillStyle = "#ffffff";
    ctx.beginPath(); ctx.arc(player.x, player.y, 30, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
  }

  ctx.save();
  ctx.textAlign = "center";
  ctx.font = "bold 11px Arial, sans-serif";
  ctx.fillStyle = "rgba(8,17,18,.83)";
  const nameWidth = Math.min(105, ctx.measureText(player.name).width + 20);
  rect(ctx, player.x - nameWidth / 2, player.y - 55, nameWidth, 18, 3); ctx.fill();
  ctx.fillStyle = color;
  ctx.fillText(player.name, player.x, player.y - 42);
  ctx.fillStyle = "rgba(4,11,12,.8)";
  rect(ctx, player.x - 25, player.y - 34, 50, 5, 2); ctx.fill();
  ctx.fillStyle = player.hp < 35 ? "#ff746a" : color;
  rect(ctx, player.x - 25, player.y - 34, 50 * player.hp / 100, 5, 2); ctx.fill();
  ctx.restore();
}

export type RenderOptions = {
  now?: number;
  localId?: PlayerSide;
  reticle?: { x: number; y: number } | null;
  /** Screen-shake trauma 0..1, driven by the local player's combat events. */
  shake?: number;
  /** Local player HP, used for the low-health warning vignette. */
  localHp?: number;
};

function drawFeed(ctx: CanvasRenderingContext2D, state: PublicRoom, now: number) {
  const visible = state.feed.filter((item) => now - item.at < 3600).slice(-2);
  visible.forEach((item, index) => {
    const age = now - item.at;
    const alpha = age < 250 ? age / 250 : age > 2900 ? Math.max(0, (3600 - age) / 700) : 1;
    const y = 108 + index * 52;
    const scale = age < 250 ? 0.8 + (age / 250) * 0.2 : 1;
    ctx.save();
    ctx.globalAlpha = Math.max(0, Math.min(1, alpha));
    ctx.translate(ARENA_WIDTH / 2, y);
    ctx.scale(scale, scale);
    ctx.textAlign = "center";
    ctx.fillStyle = "rgba(6,13,14,.72)";
    const line = item.callout ? `${item.callout}  ·  ${item.killer} > ${item.victim}` : `${item.killer} > ${item.victim}`;
    ctx.font = `800 ${item.callout ? 27 : 19}px 'Arial Narrow', Impact, sans-serif`;
    const width = Math.min(560, ctx.measureText(line).width + 44);
    ctx.fillRect(-width / 2, item.callout ? -30 : -22, width, item.callout ? 52 : 38);
    ctx.strokeStyle = item.side ? SIDE_COLORS[item.side] : "#f5ac66";
    ctx.lineWidth = 2;
    ctx.strokeRect(-width / 2, item.callout ? -30 : -22, width, item.callout ? 52 : 38);
    if (item.callout) {
      ctx.fillStyle = "#f5ac66";
      ctx.fillText(item.callout, 0, -6);
      ctx.font = "800 16px 'Arial Narrow', Impact, sans-serif";
      ctx.fillStyle = "#e8efe4";
      ctx.fillText(`${item.killer} > ${item.victim}`, 0, 15);
    } else {
      ctx.fillStyle = "#e8efe4";
      ctx.fillText(line, 0, 10);
    }
    ctx.restore();
  });
}

export function drawArena(ctx: CanvasRenderingContext2D, state: PublicRoom, options: RenderOptions = {}) {
  const now = options.now ?? Date.now();
  const trauma = Math.max(0, Math.min(1, options.shake ?? 0));
  const shakeMag = trauma * trauma * 13;
  ctx.clearRect(0, 0, ARENA_WIDTH, ARENA_HEIGHT);
  ctx.save();
  if (shakeMag > 0.2) ctx.translate((Math.random() * 2 - 1) * shakeMag, (Math.random() * 2 - 1) * shakeMag);
  ctx.drawImage(staticCanvas(state.mapId), 0, 0, ARENA_WIDTH, ARENA_HEIGHT);

  for (const cover of getMap(state.mapId).cover) {
    if (cover.kind === "crate") drawCrate(ctx, cover, state.coverHealth[cover.id] ?? cover.maxHp);
  }

  // Slow radar sweep breathing life into the arena floor.
  const sweep = (now / 2600) % (Math.PI * 2);
  ctx.save();
  ctx.translate(600, 360);
  ctx.rotate(sweep);
  const sweepGrad = ctx.createLinearGradient(0, 0, 200, 0);
  sweepGrad.addColorStop(0, "rgba(156,232,219,0)");
  sweepGrad.addColorStop(1, "rgba(156,232,219,.10)");
  ctx.fillStyle = sweepGrad;
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.arc(0, 0, 200, -0.07, 0.07);
  ctx.closePath();
  ctx.fill();
  ctx.restore();

  for (const pickup of state.pickups ?? []) {
    const bob = Math.sin(now / 300 + pickup.id) * 4;
    const pulse = 0.5 + 0.3 * Math.sin(now / 240 + pickup.id * 2);
    ctx.save();
    ctx.translate(pickup.x, pickup.y + bob);
    ctx.globalAlpha = 0.35 * pulse + 0.25;
    ctx.strokeStyle = pickup.kind === "health" ? "#7dffa8" : "#ffc46f";
    ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(0, 0, 20, 0, Math.PI * 2); ctx.stroke();
    ctx.globalAlpha = 1;
    ctx.fillStyle = "rgba(8,16,17,.88)";
    rect(ctx, -13, -13, 26, 26, 5); ctx.fill();
    ctx.strokeStyle = pickup.kind === "health" ? "#7dffa8" : "#ffc46f";
    ctx.lineWidth = 2;
    rect(ctx, -13, -13, 26, 26, 5); ctx.stroke();
    if (pickup.kind === "health") {
      ctx.fillStyle = "#7dffa8";
      ctx.fillRect(-3.5, -9, 7, 18);
      ctx.fillRect(-9, -3.5, 18, 7);
    } else {
      ctx.fillStyle = "#ffc46f";
      ctx.beginPath();
      ctx.moveTo(3, -10); ctx.lineTo(-5, 1); ctx.lineTo(0, 1); ctx.lineTo(-3, 10); ctx.lineTo(5, -1); ctx.lineTo(0, -1);
      ctx.closePath(); ctx.fill();
    }
    ctx.restore();
  }

  ctx.save();
  ctx.globalCompositeOperation = "lighter";
  for (const projectile of state.projectiles) {
    const color = SIDE_COLORS[projectile.owner];
    const angle = Math.atan2(projectile.vy, projectile.vx);
    const tailX = projectile.x - Math.cos(angle) * 22;
    const tailY = projectile.y - Math.sin(angle) * 22;
    ctx.strokeStyle = color;
    ctx.globalAlpha = .22;
    ctx.lineWidth = 9;
    ctx.lineCap = "round";
    ctx.beginPath(); ctx.moveTo(tailX, tailY); ctx.lineTo(projectile.x, projectile.y); ctx.stroke();
    ctx.globalAlpha = 1;
    ctx.lineWidth = 2.5;
    ctx.beginPath(); ctx.moveTo(tailX, tailY); ctx.lineTo(projectile.x, projectile.y); ctx.stroke();
    ctx.fillStyle = "#fff7dc";
    ctx.beginPath(); ctx.arc(projectile.x, projectile.y, 2.6, 0, Math.PI * 2); ctx.fill();
  }
  ctx.restore();

  for (const player of state.players) drawPlayer(ctx, player, player.id === options.localId, now);
  drawEffects(ctx, state, now);
  ctx.restore();

  drawFeed(ctx, state, now);

  if (options.localHp !== undefined && options.localHp > 0 && options.localHp <= 30) {
    ctx.save();
    ctx.globalAlpha = 0.28 + 0.16 * Math.sin(now / 170);
    ctx.strokeStyle = "#ff5a48";
    ctx.lineWidth = 12;
    ctx.strokeRect(8, 8, ARENA_WIDTH - 16, ARENA_HEIGHT - 16);
    ctx.restore();
  }

  if (options.reticle) {
    const { x, y } = options.reticle;
    ctx.strokeStyle = "rgba(247,245,220,.88)";
    ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(x, y, 9, 0, Math.PI * 2); ctx.stroke();
    for (let i = 0; i < 4; i++) {
      const a = i * Math.PI / 2;
      ctx.beginPath();
      ctx.moveTo(x + Math.cos(a) * 14, y + Math.sin(a) * 14);
      ctx.lineTo(x + Math.cos(a) * 21, y + Math.sin(a) * 21);
      ctx.stroke();
    }
    ctx.fillStyle = "#f7f5dc";
    ctx.beginPath(); ctx.arc(x, y, 1.8, 0, Math.PI * 2); ctx.fill();
  }

  ctx.strokeStyle = "rgba(243,221,169,.18)";
  ctx.lineWidth = 2;
  for (const [x, y, dx, dy] of [[32, 32, 17, 17], [1168, 32, -17, 17], [32, 688, 17, -17], [1168, 688, -17, -17]]) {
    ctx.beginPath(); ctx.moveTo(x + dx, y); ctx.lineTo(x, y); ctx.lineTo(x, y + dy); ctx.stroke();
  }
}

export function clearRenderCache() {
  staticLayer = null;
  staticMapId = "";
}

void PLAYER_RADIUS;

export type CosmeticParticle = {
  x: number; y: number; vx: number; vy: number;
  life: number; maxLife: number; size: number;
  color: string; drag: number; grav: number;
  glow: boolean; ring?: boolean;
};

/**
 * Client-side cosmetic effects derived from state diffs (shots, dashes,
 * deaths, pickups, broken crates). Purely visual — nothing here syncs over
 * the network, so it stays free at 60fps on every client.
 */
export class CosmeticFX {
  private particles: CosmeticParticle[] = [];
  private prevShots = new Map<PlayerSide, number>();
  private prevHp = new Map<PlayerSide, number>();
  private prevPickups = new Map<number, { x: number; y: number; kind: string }>();
  private prevCover = new Map<string, number>();

  private burst(x: number, y: number, count: number, color: string, speed: number, life: number, size: number, glow = false) {
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const velocity = speed * (0.35 + Math.random() * 0.65);
      this.particles.push({
        x, y,
        vx: Math.cos(angle) * velocity,
        vy: Math.sin(angle) * velocity,
        life: 0, maxLife: life * (0.6 + Math.random() * 0.4),
        size: size * (0.7 + Math.random() * 0.6),
        color, drag: 0.94, grav: 0, glow,
      });
    }
  }

  update(state: PublicRoom, now: number) {
    void now;
    for (const player of state.players) {
      if (player.lastShotAt > (this.prevShots.get(player.id) ?? 0) && player.hp > 0) {
        this.prevShots.set(player.id, player.lastShotAt);
        // Muzzle smoke + ejected shell casing.
        const mx = player.x + Math.cos(player.aim) * 36;
        const my = player.y + Math.sin(player.aim) * 36;
        this.burst(mx, my, 2, "rgba(207,216,204,.9)", 55, 380, 2.4);
        const sx = Math.cos(player.aim + Math.PI / 2);
        const sy = Math.sin(player.aim + Math.PI / 2);
        this.particles.push({
          x: player.x + Math.cos(player.aim) * 8, y: player.y + Math.sin(player.aim) * 8,
          vx: sx * 130 + (Math.random() - 0.5) * 70, vy: sy * 130 - 50,
          life: 0, maxLife: 550, size: 2.6, color: "#ffd98a",
          drag: 0.93, grav: 320, glow: false,
        });
      }
      const previousHp = this.prevHp.get(player.id);
      if (previousHp !== undefined && previousHp > 0 && player.hp <= 0) {
        // Death debris in the victim's color plus a white flash pop.
        this.burst(player.x, player.y, 14, SIDE_COLORS[player.id], 220, 750, 3.2);
        this.burst(player.x, player.y, 7, "#ffffff", 130, 420, 2.2, true);
      }
      this.prevHp.set(player.id, player.hp);
      if (player.dashEndsAt > now && player.hp > 0) {
        this.particles.push({
          x: player.x, y: player.y, vx: 0, vy: 0,
          life: 0, maxLife: 340, size: 22, color: SIDE_COLORS[player.id],
          drag: 1, grav: 0, glow: true, ring: true,
        });
      }
    }
    const current = new Map(state.pickups.map((pickup) => [pickup.id, pickup]));
    for (const [id, previous] of this.prevPickups) {
      if (!current.has(id)) this.burst(previous.x, previous.y, 10, previous.kind === "health" ? "#7dffa8" : "#ffc46f", 150, 520, 2.6, true);
    }
    this.prevPickups = new Map(state.pickups.map((pickup) => [pickup.id, { x: pickup.x, y: pickup.y, kind: pickup.kind }]));
    for (const cover of getMap(state.mapId).cover) {
      if (cover.kind !== "crate") continue;
      const hp = state.coverHealth[cover.id] ?? cover.maxHp;
      const previous = this.prevCover.get(cover.id);
      if (previous !== undefined && previous > 0 && hp <= 0) {
        for (let i = 0; i < 10; i++) {
          this.particles.push({
            x: cover.x + Math.random() * cover.w, y: cover.y + Math.random() * cover.h,
            vx: (Math.random() - 0.5) * 260, vy: -Math.random() * 200,
            life: 0, maxLife: 800, size: 3 + Math.random() * 3,
            color: i % 2 ? "#a78259" : "#6b543c", drag: 0.96, grav: 500, glow: false,
          });
        }
      }
      this.prevCover.set(cover.id, hp);
    }
    const dt = 1 / 60;
    for (const particle of this.particles) {
      particle.life += 1000 / 60;
      particle.x += particle.vx * dt;
      particle.y += particle.vy * dt;
      particle.vx *= particle.drag;
      particle.vy = particle.vy * particle.drag + particle.grav * dt;
    }
    this.particles = this.particles.filter((particle) => particle.life < particle.maxLife).slice(-140);
  }

  draw(ctx: CanvasRenderingContext2D) {
    if (this.particles.length === 0) return;
    ctx.save();
    for (const particle of this.particles) {
      const t = Math.max(0, 1 - particle.life / particle.maxLife);
      ctx.globalAlpha = t * (particle.glow ? 0.55 : 0.9);
      if (particle.glow) ctx.globalCompositeOperation = "lighter";
      if (particle.ring) {
        ctx.strokeStyle = particle.color;
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(particle.x, particle.y, Math.max(1, particle.size * (1.7 - t)), 0, Math.PI * 2);
        ctx.stroke();
      } else {
        ctx.fillStyle = particle.color;
        ctx.beginPath();
        ctx.arc(particle.x, particle.y, Math.max(0.5, particle.size * t), 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalCompositeOperation = "source-over";
    }
    ctx.restore();
  }
}
