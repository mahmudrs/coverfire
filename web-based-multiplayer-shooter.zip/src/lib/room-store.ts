import { randomBytes, randomUUID } from "node:crypto";
import { eq, lt, sql } from "drizzle-orm";
import { db } from "@/db";
import { matchResults, onlineRooms } from "@/db/schema";
import {
  SIDES,
  advanceGame,
  applyPlayerInput,
  cleanName,
  createPlayer,
  createRoomState,
  freshAmmo,
  resetMatch,
  spawnFor,
  teamForSide,
  toPublicRoom,
  type MatchMode,
  type PlayerInput,
  type PlayerSide,
  type PublicRoom,
  type RoomState,
  type WeaponKey,
} from "@/lib/game";

const SQUAD_BOT_NAMES: Record<PlayerSide, string> = { alpha: "HAVOC", bravo: "RIVET", charlie: "JOLT", delta: "GRIT" };

function humansOf(state: RoomState) {
  return state.players.filter((player) => !player.isBot);
}

type RoomEntry = {
  state: RoomState;
  ticker: ReturnType<typeof setInterval> | null;
  lastTouch: number;
  lastPersist: number;
};

type RoomStore = Map<string, RoomEntry>;

const globalForRooms = globalThis as typeof globalThis & { __coverfireOnlineRooms?: RoomStore };
const rooms: RoomStore = globalForRooms.__coverfireOnlineRooms ?? new Map<string, RoomEntry>();
globalForRooms.__coverfireOnlineRooms = rooms;

const CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
const IDLE_MS = 20 * 60 * 1000;
const PERSIST_EVERY_MS = 2500;

export type OnlineFailure = { ok: false; status: number; error: string };
export type OnlineSuccess = { ok: true; roomId: string; token: string; playerId: PlayerSide; state: PublicRoom };

function makeCode() {
  return Array.from(randomBytes(6), (byte) => CODE_ALPHABET[byte % CODE_ALPHABET.length]).join("");
}

async function persist(code: string, entry: RoomEntry) {
  entry.lastPersist = Date.now();
  try {
    await db.update(onlineRooms).set({ state: entry.state, updatedAt: new Date() }).where(eq(onlineRooms.id, code));
  } catch (error) {
    console.error("Persist room failed", code, error);
  }
}

function recordResults(entry: RoomEntry) {
  const state = entry.state;
  if (state.phase !== "finished" || state.resultSaved) return;
  state.resultSaved = true;
  const winningTeam = state.players.find((player) => player.id === state.winner)?.team;
  const durationMs = Math.max(0, Date.now() - state.startedAt);
  const rows = state.players
    .filter((player) => !player.isBot)
    .map((player) => ({ callsign: player.name, kills: player.kills, deaths: player.deaths, won: player.team === winningTeam, durationMs }));
  if (rows.length) void db.insert(matchResults).values(rows).catch((error) => console.error("Record online result failed", error));
}

function track(code: string, state: RoomState): RoomEntry {
  const entry: RoomEntry = { state, ticker: null, lastTouch: Date.now(), lastPersist: Date.now() };
  rooms.set(code, entry);

  const ticker = setInterval(() => {
    const now = Date.now();
    advanceGame(state, now);
    if (state.phase === "finished") recordResults(entry);
    if (now - entry.lastPersist > PERSIST_EVERY_MS) void persist(code, entry);
    const active = state.players.some((player) => now - player.lastSeen < 60_000);
    if (now - entry.lastTouch > IDLE_MS && !active) {
      clearInterval(ticker);
      entry.ticker = null;
      rooms.delete(code);
    }
  }, 1000 / 60);
  entry.ticker = ticker;
  return entry;
}

async function getEntry(code: string): Promise<RoomEntry | null> {
  const cached = rooms.get(code);
  if (cached) {
    cached.lastTouch = Date.now();
    return cached;
  }
  const [row] = await db.select().from(onlineRooms).where(eq(onlineRooms.id, code)).limit(1);
  if (!row) return null;
  return track(code, row.state);
}

function startIfReady(entry: RoomEntry) {
  const state = entry.state;
  const ready = state.mode === "squad" ? humansOf(state).length >= 1 : state.players.length === 2;
  if (ready && state.phase === "waiting") {
    const now = Date.now();
    state.phase = "playing";
    state.startedAt = now;
    state.lastTick = now;
    state.resultSaved = false;
  }
}

function attach(code: string, entry: RoomEntry, token: string, name: string): OnlineSuccess | OnlineFailure {
  const state = entry.state;
  const now = Date.now();
  let player = state.players.find((candidate) => candidate.token === token);

  if (!player) {
    if (state.mode === "squad") {
      const humans = humansOf(state);
      if (humans.length >= 4) return { ok: false, status: 409, error: "This squad is already full. Start a quick match instead." };
      const team0 = humans.filter((candidate) => candidate.team === 0).length;
      const team1 = humans.length - team0;
      const team: 0 | 1 = team0 <= team1 ? 0 : 1;
      const slot = state.players.find((candidate) => candidate.isBot && candidate.team === team) ?? state.players.find((candidate) => candidate.isBot);
      if (!slot) return { ok: false, status: 409, error: "This squad is already full. Start a quick match instead." };
      const spawn = spawnFor(state.mapId, slot.id);
      slot.isBot = false;
      slot.token = token;
      slot.name = cleanName(name, "ROOKIE");
      slot.x = spawn.x;
      slot.y = spawn.y;
      slot.aim = slot.id === "alpha" || slot.id === "charlie" ? 0 : Math.PI;
      slot.hp = 100;
      slot.ammo = freshAmmo();
      slot.rapidUntil = 0;
      slot.reloadEndsAt = 0;
      slot.respawnAt = 0;
      slot.invulnerableUntil = now + 1050;
      slot.lastSeen = now;
      slot.lastInputSeq = 0;
      slot.input = { mx: 0, my: 0, aim: slot.aim, shoot: false, reload: false, dash: false };
      player = slot;
    } else {
      if (state.players.length >= 2) return { ok: false, status: 409, error: "This match is already full. Start a quick match instead." };
      player = createPlayer("bravo", token, name, now, 1, state.mapId);
      state.players.push(player);
    }
  } else {
    player.name = cleanName(name, player.name);
    player.lastSeen = now;
    player.input = { ...player.input, mx: 0, my: 0, shoot: false, dash: false, reload: false };
  }
  entry.lastTouch = now;
  startIfReady(entry);
  if (!entry.ticker) track(code, state);
  void persist(code, entry);
  return { ok: true, roomId: code, token: player.token, playerId: player.id, state: toPublicRoom(state) };
}

export function roomStats() {
  let live = 0;
  let waiting = 0;
  for (const entry of rooms.values()) {
    if (entry.state.phase === "playing") live++;
    else if (entry.state.phase === "waiting" && entry.state.players.length === 1) waiting++;
  }
  return { live, waiting };
}

export async function createOnlineRoom(name: string, mode: MatchMode = "duel", mapId = "foundry", botSkill: 0 | 1 | 2 = 1): Promise<OnlineSuccess> {
  const token = randomUUID();
  void db.delete(onlineRooms).where(lt(onlineRooms.updatedAt, new Date(Date.now() - 24 * 60 * 60 * 1000))).catch(() => undefined);
  for (let attempt = 0; attempt < 6; attempt++) {
    const code = makeCode();
    if (rooms.has(code)) continue;
    const now = Date.now();
    const state = createRoomState(code, now, mode, mapId, botSkill);
    const player = createPlayer("alpha", token, name, now, 0, state.mapId);
    state.players.push(player);
    if (mode === "squad") {
      for (const side of SIDES) {
        if (side === "alpha") continue;
        const bot = createPlayer(side, randomUUID(), SQUAD_BOT_NAMES[side], now, teamForSide(side), state.mapId);
        bot.isBot = true;
        bot.weapon = "smg";
        state.players.push(bot);
      }
      state.phase = "playing";
      state.startedAt = now;
    }
    const inserted = await db.insert(onlineRooms).values({ id: code, state }).onConflictDoNothing().returning({ id: onlineRooms.id });
    if (!inserted.length) continue;
    track(code, state);
    return { ok: true, roomId: code, token, playerId: "alpha", state: toPublicRoom(state) };
  }
  throw new Error("Could not open an online arena. Please try again.");
}

export async function joinOnlineRoom(code: string, token: string, name: string): Promise<OnlineSuccess | OnlineFailure> {
  const entry = await getEntry(code);
  if (!entry) return { ok: false, status: 404, error: "That match link is invalid or the room has closed." };
  return attach(code, entry, token || randomUUID(), name);
}

async function findWaitingRoom(mode: MatchMode): Promise<string | null> {
  const now = Date.now();
  for (const [code, entry] of rooms) {
    const { state } = entry;
    if (now - entry.lastTouch > 5 * 60 * 1000) continue;
    if (mode === "squad") {
      if (state.mode === "squad" && state.phase === "playing" && humansOf(state).length < 4) return code;
    } else if (state.phase === "waiting" && state.players.length === 1 && state.mode === "duel") {
      return code;
    }
  }
  try {
    if (mode === "duel") {
      const rows = await db.execute(sql`
        select id from online_rooms
        where state->>'phase' = 'waiting'
          and jsonb_array_length(state->'players') = 1
          and updated_at > now() - interval '5 minutes'
        order by updated_at asc limit 1
      `);
      const row = (rows.rows as { id?: string }[])[0];
      if (row?.id) return row.id;
    } else {
      const rows = await db.execute(sql`
        select id from online_rooms
        where state->>'mode' = 'squad'
          and state->>'phase' = 'playing'
          and updated_at > now() - interval '15 minutes'
        order by updated_at desc limit 5
      `);
      for (const row of rows.rows as { id?: string }[]) {
        if (!row?.id || rooms.has(row.id)) {
          if (row?.id && rooms.has(row.id)) return row.id;
          continue;
        }
        const entry = await getEntry(row.id);
        if (entry && humansOf(entry.state).length < 4) return row.id;
      }
    }
  } catch (error) {
    console.error("Find waiting room failed", error);
  }
  return null;
}

export async function quickMatch(name: string, mode: MatchMode = "duel", mapId = "foundry", botSkill: 0 | 1 | 2 = 1): Promise<OnlineSuccess> {
  for (let attempt = 0; attempt < 3; attempt++) {
    const code = await findWaitingRoom(mode);
    if (!code) break;
    const entry = await getEntry(code);
    if (!entry) continue;
    if (mode === "duel" && entry.state.players.length >= 2) continue;
    if (mode === "squad" && humansOf(entry.state).length >= 4) continue;
    const result = await joinOnlineRoom(code, "", name);
    if (result.ok) return result;
  }
  return createOnlineRoom(name, mode, mapId, botSkill);
}

export async function syncOnline(code: string, token: string, seq: number, input: Partial<PlayerInput> & { weapon?: WeaponKey; name?: string }) {
  const entry = await getEntry(code);
  if (!entry) return { ok: false as const, status: 404, error: "This room has closed." };
  const state = entry.state;
  const player = state.players.find((candidate) => candidate.token === token);
  if (!player) return { ok: false as const, status: 403, error: "Your player slot is no longer available." };
  const now = Date.now();
  applyPlayerInput(state, player, input, now, Number.isFinite(seq) ? seq : player.lastInputSeq + 1);
  advanceGame(state, now);
  if (state.phase === "finished") {
    recordResults(entry);
    await persist(code, entry);
  }
  entry.lastTouch = now;
  return { ok: true as const, state: toPublicRoom(state), serverTime: now };
}

export async function rematchOnline(code: string, token: string) {
  const entry = await getEntry(code);
  if (!entry) return { ok: false as const, status: 404, error: "This room has closed." };
  if (!entry.state.players.some((player) => player.token === token)) return { ok: false as const, status: 403, error: "You are not in this match." };
  if (entry.state.players.length < 2) return { ok: false as const, status: 409, error: "Waiting for an opponent." };
  if (entry.state.phase !== "finished") return { ok: false as const, status: 409, error: "The match is still in progress." };
  resetMatch(entry.state);
  entry.lastTouch = Date.now();
  await persist(code, entry);
  return { ok: true as const, state: toPublicRoom(entry.state) };
}

export async function leaveOnline(code: string, token: string) {
  const entry = rooms.get(code);
  if (entry) {
    const player = entry.state.players.find((candidate) => candidate.token === token);
    if (player) {
      if (entry.state.mode === "squad" && !player.isBot) {
        player.isBot = true;
        player.token = randomUUID();
        player.name = SQUAD_BOT_NAMES[player.id];
        player.input = { mx: 0, my: 0, aim: player.aim, shoot: false, reload: false, dash: false };
      } else {
        player.lastSeen = 0;
      }
    }
    await persist(code, entry);
  }
  return { ok: true as const };
}
